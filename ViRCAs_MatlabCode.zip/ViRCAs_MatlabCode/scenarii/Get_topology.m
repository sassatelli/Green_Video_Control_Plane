function [WDM_linkTable, CPRI_linkTable,pathInfo,numCellSites,numFixPoints, nodeTable]=Get_topology(topology_name)

    cellSitesDensity = [10,3.5,0.15]; %sites per km^2
    numCellSites = [10,7,3];
    householdsDensity = [4000.0, 900.0, 300.0]; %households per km^2
    householdsPerFixPoint = 800;
    fixPointsDensity = householdsDensity./householdsPerFixPoint; %fix points per km^2
    numFixPoints = [5,2,8];
    area2 = numFixPoints./fixPointsDensity;%km^2
    sideLength = sqrt(area2); %km
    maxCPRIreach = [0.4,3,3];
    scen_index = 1; % dense urban
    
    if strcmp(topology_name,'FMC_tree'),
        numAggrNodesL2 = 4;
        numAggrNodesL1 = 2;
        [nodeTable,linkTable] = genTopology(numCellSites(scen_index), numFixPoints(scen_index), sideLength(scen_index), numAggrNodesL2, numAggrNodesL1);
        [srcPathTable,dstPathTable,linksPathTable] = computePaths_inTree(nodeTable,linkTable);
        [srcPathTable_CPRI, dstPathTable_CPRI, linksPathTable_CPRI] = computePaths_CPRI_inTree(nodeTable,linkTable,maxCPRIreach(scen_index));
        numCellSites=numCellSites(scen_index); numFixPoints=numFixPoints(scen_index);
    elseif strcmp(topology_name,'FMC_ringandspur'),
        numAggrNodesL2 = 4;
        numAggrNodesL1 = 2;
        [nodeTable,linkTable] = genTopology_FMC_RingAndSpur(numCellSites(scen_index), numFixPoints(scen_index), sideLength(scen_index), numAggrNodesL2, numAggrNodesL1);
        [pathInfo_L1] = computePathSet(linkTable,0);
        [pathInfo_CPRI] = computePathSet_CPRI(linkTable,maxCPRIreach(scen_index),0);
        srcPathTable=pathInfo_L1.bin_initNodes'; dstPathTable=pathInfo_L1.bin_endNodes'; linksPathTable=pathInfo_L1.bin_edgesInPath';
        srcPathTable_CPRI=pathInfo_CPRI.bin_initNodes'; dstPathTable_CPRI=pathInfo_CPRI.bin_endNodes'; linksPathTable_CPRI=pathInfo_CPRI.bin_edgesInPath';
        numCellSites=numCellSites(scen_index); numFixPoints=numFixPoints(scen_index);
    elseif strcmp(topology_name,'Mobile_backhaul'),
        nbof_module=2;
        flag_diversity=1;
        [nodeTable,linkTable,numCellSites,numFixPoints,numAggrNodesL3,numAggrNodesL2,numAggrNodesL1,nbof_module] = genTopology_Mobile_backhaul(sideLength(scen_index),nbof_module,flag_diversity);
        [pathInfo_L1] = computePathSet(linkTable,0);
        [pathInfo_CPRI] = computePathSet_CPRI(linkTable,maxCPRIreach(scen_index),0);
        srcPathTable=pathInfo_L1.bin_initNodes'; dstPathTable=pathInfo_L1.bin_endNodes'; linksPathTable=pathInfo_L1.bin_edgesInPath';
        srcPathTable_CPRI=pathInfo_CPRI.bin_initNodes'; dstPathTable_CPRI=pathInfo_CPRI.bin_endNodes'; linksPathTable_CPRI=pathInfo_CPRI.bin_edgesInPath';
    end;

    [WDM_linkTable] = computeCollapasedVirtualTopology(srcPathTable,dstPathTable);
%     [WDM_linkTable] = computeVirtualTopology(srcPathTable,dstPathTable,linksPathTable);
    loopback_paths=1;
    CPRI_linkTable = compute_CPRI_linkTable(nodeTable,srcPathTable_CPRI,dstPathTable_CPRI,linksPathTable_CPRI, loopback_paths);
    [pathInfo] = computePathSet (WDM_linkTable,loopback_paths);    
end
function CPRI_linkTable = compute_CPRI_linkTable(nodeTable,srcPathTable_CPRI,dstPathTable_CPRI,linksPathTable_CPRI, loopback_paths)
    
    %We filter all the paths not ending at a mobile node
    bin_mobEndNodes_ids=(nodeTable(:,3)==4); %mobile end nodes
    bin_CPRIpath_ids = any(dstPathTable_CPRI(:,bin_mobEndNodes_ids),2); %paths ending at mobile end nodes
    srcPathTable_CPRI(not(bin_CPRIpath_ids),:) = [];
    dstPathTable_CPRI(not(bin_CPRIpath_ids),:) = [];
    linksPathTable_CPRI(not(bin_CPRIpath_ids),:) = [];

    numCPRIlinks = size(linksPathTable_CPRI,1); %numPaths ending at a mobile end node = numPaths
    CPRI_linkTable = zeros(numCPRIlinks,2);
    for pathID =1:numCPRIlinks,
        pathSrc=find(srcPathTable_CPRI(pathID,:)==1);
        pathDst=find(dstPathTable_CPRI(pathID,:)==1);
        CPRI_linkTable(pathID,1) = pathSrc;
        CPRI_linkTable(pathID,2) = pathDst;
    end
    if loopback_paths,
        CPRI_linkTable = [find(bin_mobEndNodes_ids) find(bin_mobEndNodes_ids) ; CPRI_linkTable];
    end
    
end
function [virtuaLinkTable] = computeCollapasedVirtualTopology(srcPathTable,dstPathTable)
%     N = size(srcPathTable,2); %numNodes
%     numVirtLinks = N*(N-1); %numNodes*(numNodes-1) = numPaths
    virtAdjacencyMatrix = srcPathTable'*dstPathTable;
    numVirtLinks = nnz(virtAdjacencyMatrix);
    virtuaLinkTable = zeros(numVirtLinks,3); % 3 cols: src|dst|# links|
    [virtuaLinkTable(:,1), virtuaLinkTable(:,2), virtuaLinkTable(:,3)] =find(virtAdjacencyMatrix);
end
function [virtuaLinkTable] = computeVirtualTopology(srcPathTable,dstPathTable,linksPathTable)
    numVirtLinks = size(linksPathTable,1); %numVirtLinks = numPaths
    virtuaLinkTable = zeros(numVirtLinks,2);
    for pathID =1:numVirtLinks,
        pathSrc=find(srcPathTable(pathID,:)==1);
        pathDst=find(dstPathTable(pathID,:)==1);
        virtuaLinkTable(pathID,1) = pathSrc;
        virtuaLinkTable(pathID,2) = pathDst;
    end
end

function [srcPathTable_CPRI, dstPathTable_CPRI, linksPathTable_CPRI] = computePaths_CPRI_inTree(nodeTable,linkTable,CPRIreach)
    numNodes = size(nodeTable,1);
    numLinks = size(linkTable,1);
    
    numCellSites = sum(nodeTable(:,3)==4);
    numFixPoints = sum(nodeTable(:,3)==3);
    numAggrNodesL2 = sum(nodeTable(:,3)==2);
    numAggrNodesL1 = sum(nodeTable(:,3)==1);
    %For this aggreg topology, we know the max num Paths_CPRI  by construction : num(1-link paths) + num(2-link paths) + num(3-link paths), but not if they meet the CPRI requirement 
    max_numPaths_CPRI = 3*numCellSites;

    %Creating src node Path Table : num Paths x numNodes : rows = paths, cols=nodes --> 1, if path p starts at node n 
    srcPathTable_CPRI = zeros(max_numPaths_CPRI,numNodes); %households per km^2
    %Creating dst node Path Table : num Paths x numNodes : rows = paths, cols=nodes --> 1, if path p ends at node n 
    dstPathTable_CPRI = zeros(max_numPaths_CPRI,numNodes);%households per km^2
    %Creating links Path Table : num Paths x numLinks : : rows = paths, cols=links --> 1, if path p traverses link l
    linksPathTable_CPRI = zeros(max_numPaths_CPRI,numLinks);%households per km^2
    
    %we add the paths checking the CPRI reach
    pathCounter = 0; 
    for dst = 1+numAggrNodesL1+numAggrNodesL2+numFixPoints +1 : 1+numAggrNodesL1+numAggrNodesL2+numCellSites+numFixPoints,
        pathLength = 0;
            
        % 1-link path to dst : link_L2toE
        link_L2toE = (linkTable(:,2)==dst);
        if linkTable(link_L2toE,3)+pathLength > CPRIreach,
            continue
        end
        %otherwise, we add the 1-link path
        pathCounter=pathCounter+1;
        pathLength = pathLength + linkTable(link_L2toE,3);   
        L2node = linkTable(link_L2toE,1);
        srcPathTable_CPRI(pathCounter,L2node) = 1;
        dstPathTable_CPRI(pathCounter,dst) = 1;
        linksPathTable_CPRI(pathCounter,link_L2toE) = 1;
        
%         [L2node dst]
%         pathCounter
%         pause
        
        % 2-link path to dst : link_L1toL2 + link_L2toE
        link_L1toL2 = (linkTable(:,2)==L2node);
        if linkTable(link_L1toL2,3)+pathLength > CPRIreach,
            continue
        end
        %otherwise, we add the 2-link path
        pathCounter=pathCounter+1;
        pathLength = pathLength + linkTable(link_L1toL2,3);    
        L1node = linkTable(link_L1toL2,1);
        srcPathTable_CPRI(pathCounter,L1node) = 1;
        dstPathTable_CPRI(pathCounter,dst) = 1;
        linksPathTable_CPRI(pathCounter,link_L2toE) = 1;
        linksPathTable_CPRI(pathCounter,link_L1toL2) = 1;
        
%         [L1node L2node dst]
%         pathCounter
%         pause
         
        % 3-link path to dst : link_PoPtoL1 + link_L1toL2 + link_L2toE
        link_PoPtoL1 = (linkTable(:,2)==L1node);
        if linkTable(link_PoPtoL1,3)+pathLength > CPRIreach,
            continue
        end
        %otherwise, we add the 3-link path
        pathCounter=pathCounter+1;
        pathLength = pathLength + linkTable(link_PoPtoL1,3);    
        src = linkTable(link_PoPtoL1,1);
        srcPathTable_CPRI(pathCounter,src) = 1;
        dstPathTable_CPRI(pathCounter,dst) = 1;
        linksPathTable_CPRI(pathCounter,link_L2toE) = 1;
        linksPathTable_CPRI(pathCounter,link_L1toL2) = 1;
        linksPathTable_CPRI(pathCounter,link_PoPtoL1) = 1;
%         [src L1node L2node dst]
%         pathCounter
%         pause
    end

    %removing empty  rows
    pathsToRemove = find(sum(linksPathTable_CPRI,2)==0);
    srcPathTable_CPRI(pathsToRemove, : ) = [];
    dstPathTable_CPRI(pathsToRemove, : ) = [];
    linksPathTable_CPRI(pathsToRemove, : ) = [];     
end

function [srcPathTable,dstPathTable,linksPathTable] = computePaths_inTree(nodeTable,linkTable)
    numNodes = size(nodeTable,1);
    numLinks = size(linkTable,1);
    
    numCellSites = sum(nodeTable(:,3)==4);
    numFixPoints = sum(nodeTable(:,3)==3);
    numAggrNodesL2 = sum(nodeTable(:,3)==2);
    numAggrNodesL1 = sum(nodeTable(:,3)==1);
    %For this aggreg topology, we know the num Paths by construction : num(1-link paths) + num(2-link paths) + num(3-link paths)
    numPaths = numLinks + (numCellSites+numFixPoints+numAggrNodesL2) + (numCellSites+numFixPoints);
 
    %Creating src node Path Table : num Paths x numNodes : rows = paths, cols=nodes --> 1, if path p starts at node n 
    srcPathTable = zeros(numPaths,numNodes); %households per km^2
    %Creating dst node Path Table : num Paths x numNodes : rows = paths, cols=nodes --> 1, if path p ends at node n 
    dstPathTable = zeros(numPaths,numNodes);%households per km^2
    %Creating links Path Table : num Paths x numLinks : : rows = paths, cols=links --> 1, if path p traverses link l
    linksPathTable = zeros(numPaths,numLinks);%households per km^2
         
    % we add the 1-link paths : the first numLinks paths are the 1-link paths
    for l = 1:numLinks,
        src = linkTable(l,1);
        dst = linkTable(l,2);
        srcPathTable(l,src) = 1;
        dstPathTable(l,dst) = 1;
        linksPathTable(l,l) = 1;  
    end
    pathCounter = numLinks; 
    % we add the 2-link paths : 
    %       - first, the 2-link paths btw L1 aggreg nodes and the end points 
    for dst = 1+numAggrNodesL1+numAggrNodesL2 +1 : 1+numAggrNodesL1+numAggrNodesL2+numCellSites+numFixPoints,
        pathCounter=pathCounter+1;
        
        link_L2toE = (linkTable(:,2)==dst);
        L2node = linkTable(link_L2toE,1);
        link_L1toL2 = (linkTable(:,2)==L2node);
        src = linkTable(link_L1toL2,1);
        srcPathTable(pathCounter,src) = 1;
        dstPathTable(pathCounter,dst) = 1;
        linksPathTable(pathCounter,link_L2toE) = 1;
        linksPathTable(pathCounter,link_L1toL2) = 1;
     end
     %       - second, the 2-link paths btw PoP and the L2 aggreg nodes  
     for dst = 1+numAggrNodesL1 +1 : 1+numAggrNodesL1 + numAggrNodesL2,
        pathCounter=pathCounter+1;
        
        link_L1toL2 = (linkTable(:,2)==dst);
        L1node = linkTable(link_L1toL2,1);
        link_PoPtoL1 = (linkTable(:,2)==L1node);
        src = linkTable(link_PoPtoL1,1);            
        srcPathTable(pathCounter,src) = 1;
        dstPathTable(pathCounter,dst) = 1;
        linksPathTable(pathCounter,link_L1toL2) = 1;
        linksPathTable(pathCounter,link_PoPtoL1) = 1;
     end 
     % we add the 3-link paths : 
     for dst = 1+numAggrNodesL1+numAggrNodesL2 +1 : 1+numAggrNodesL1+numAggrNodesL2 + numCellSites+numFixPoints,
         pathCounter=pathCounter+1;
         
         link_L2toE = (linkTable(:,2)==dst);
         L2node = linkTable(link_L2toE,1);
         link_L1toL2 = (linkTable(:,2)==L2node);
         L1node = linkTable(link_L1toL2,1);
         link_PoPtoL1 = (linkTable(:,2)==L1node);
         src = linkTable(link_PoPtoL1,1);
         srcPathTable(pathCounter,src) = 1;
         dstPathTable(pathCounter,dst) = 1;
         linksPathTable(pathCounter,link_L2toE) = 1;
         linksPathTable(pathCounter,link_L1toL2) = 1;
         linksPathTable(pathCounter,link_PoPtoL1) = 1;
     end 
end

function [nodeTable,linkTable] = genTopology(numCellSites, numFixPoints, sideLength, numAggrNodesL2, numAggrNodesL1)
    numNodes = numCellSites +numFixPoints + numAggrNodesL2 + numAggrNodesL1 +1;
    cellSites=sideLength.*rand(numCellSites,2)-sideLength/2;
    fixPoints=sideLength.*rand(numFixPoints,2)-sideLength/2;
         
    points = [fixPoints; cellSites];
    [ids_aggrNodesL2, aggrNodesL2] = kmeans(points,numAggrNodesL2);
    [ids_aggrNodesL1, aggrNodesL1] = kmeans(aggrNodesL2, numAggrNodesL1);
    PoP = [0,0];
         
    %Creating Node Table : numNodes x 3 : (x, y, code)
    nodeTable_cellSites = [cellSites, 4*ones(numCellSites,1)];% code 4--> cell sites
    nodeTable_fixPoints = [fixPoints, 3*ones(numFixPoints, 1)];%code 3--> fix endpoints
    nodeTable_aggrNodesL2 = [aggrNodesL2,2*ones(numAggrNodesL2, 1)];% code 2--> aggr nodes L2
    nodeTable_aggrNodesL1 = [aggrNodesL1, ones(numAggrNodesL1, 1)]; % code 1--> aggr nodes L1
    nodeTable = [zeros(1, 3); nodeTable_aggrNodesL1; nodeTable_aggrNodesL2; nodeTable_fixPoints; nodeTable_cellSites ];% code 0--> PoP
 
    %Creating Link Table : num Links x 3 : (src id, dst id, dist_km)           
    % Links btw L2 aggreg nodes and End points
    firstEndnode = numAggrNodesL1+numAggrNodesL2+1+1;
    lastEndnode = firstEndnode+numCellSites+numFixPoints-1;
    dstID_L2toE = [firstEndnode:lastEndnode]';% End points (fix ones, first;  mobile ones, later)
    srcID_L2toE = reshape(1+numAggrNodesL1+ids_aggrNodesL2,[numCellSites+numFixPoints,1]); % L2 aggre nodes (as many as end points)
    dist_L2toE = sum((nodeTable(srcID_L2toE,1:2)-nodeTable(dstID_L2toE,1:2)).^2,2).^0.5; %euclidean distance
    linkTable_L2toE = [srcID_L2toE, dstID_L2toE, dist_L2toE];
    
     % Links btw L1 aggreg nodes and L2 aggreg nodes        
     firstL2node = numAggrNodesL1+1+1;
     lastL2node = firstL2node+numAggrNodesL2-1;
     dstID_L1toL2 = [firstL2node:lastL2node]'; % L2 aggre nodes 
     srcID_L1toL2 = reshape(1+ids_aggrNodesL1,[numAggrNodesL2,1]); % L1 aggre nodes
     dist_L1toL2 = sum((nodeTable(srcID_L1toL2,1:2)-nodeTable(dstID_L1toL2,1:2)).^2,2).^0.5; %euclidean distance
     linkTable_L1toL2 = [srcID_L1toL2, dstID_L1toL2, dist_L1toL2];
 
     %Links btw PoP and L1 aggreg nodes        
     dstID_PoPtoL1 = [1+1:numAggrNodesL1+1]'; % L1 aggre nodes       
     srcID_PoPtoL1 = ones(numAggrNodesL1,1); % L1 aggre nodes
     dist_PoPtoL1 = sum((nodeTable(srcID_PoPtoL1,1:2)-nodeTable(dstID_PoPtoL1,1:2)).^2,2).^0.5; %euclidean distance     
     linkTable_PoPtoL1 = [srcID_PoPtoL1, dstID_PoPtoL1, dist_PoPtoL1];
         
    %Joining all the tables
    linkTable = [linkTable_PoPtoL1;linkTable_L1toL2;linkTable_L2toE];
        
    %plotting netw 
    linkAdjacencyMatrix = zeros(numNodes, numNodes);
    linkAdjacencyMatrix(sub2ind([numNodes numNodes], linkTable(:,1), linkTable(:,2)))=1;
    %gplot(linkAdjacencyMatrix,nodeTable(:,1:2))
end

function [nodeTable,linkTable] = genTopology_FMC_RingAndSpur(numCellSites, numFixPoints, sideLength, numAggrNodesL2, numAggrNodesL1)
% % ring between aggregation L2 and PoP, no AggregNodesL1
numAggrNodesL1=0;

    numNodes = numCellSites +numFixPoints + numAggrNodesL2 + 1;
    cellSites=sideLength.*rand(numCellSites,2)-sideLength/2;
    fixPoints=sideLength.*rand(numFixPoints,2)-sideLength/2;

    points = [fixPoints; cellSites];
    [ids_aggrNodesL2, aggrNodesL2] = kmeans(points,numAggrNodesL2);
    PoP = [0.5,0];

    %Creating Node Table : numNodes x 3 : (x, y, code)
    nodeTable_cellSites = [cellSites, 4*ones(numCellSites,1)];% code 4--> cell sites
    nodeTable_fixPoints = [fixPoints, 3*ones(numFixPoints, 1)];%code 3--> fix endpoints
    nodeTable_aggrNodesL2 = [aggrNodesL2,2*ones(numAggrNodesL2, 1)];% code 2--> aggr nodes L2
    nodeTable = [zeros(1, 3); nodeTable_aggrNodesL2; nodeTable_fixPoints; nodeTable_cellSites ];% code 0--> PoP

    %Creating Link Table : num Links x 3 : (src id, dst id, dist_km)
    % Links btw L2 aggreg nodes and End points
    firstEndnode = numAggrNodesL1+numAggrNodesL2+1+1;
    lastEndnode = firstEndnode+numCellSites+numFixPoints-1;
    dstID_L2toE = [firstEndnode:lastEndnode]';% End points (fix ones, first;  mobile ones, later)
    srcID_L2toE = reshape(1+numAggrNodesL1+ids_aggrNodesL2,[numCellSites+numFixPoints,1]); % L2 aggre nodes (as many as end points)
    dist_L2toE = sum((nodeTable(srcID_L2toE,1:2)-nodeTable(dstID_L2toE,1:2)).^2,2).^0.5; %euclidean distance
    linkTable_L2toE = [srcID_L2toE, dstID_L2toE, dist_L2toE];

    % Links btw L2 aggreg nodes and PoP
    firstL2node = numAggrNodesL1+1+1;
    lastL2node = firstL2node+numAggrNodesL2-1;
    L2aggreg_nodes = [firstL2node:lastL2node]'; % L2 aggre nodes
    % % start from PoP and find iterate over all L2 nodes at closest dist
    yettoenterthering=L2aggreg_nodes;
    closestL2last=1;
    dist_from_PoP=sum((repmat(nodeTable(1,1:2),[length(yettoenterthering) 1])-nodeTable(yettoenterthering,1:2)).^2,2).^0.5;
    [dis,ind]=min(dist_from_PoP); closestL2=yettoenterthering(ind);
    % establish bi-directional link
    linkTable=[];
    linkTable=[linkTable;[closestL2last closestL2 dis];[closestL2 closestL2last dis]];
    yettoenterthering=yettoenterthering(logical(yettoenterthering~=closestL2));
    closestL2last=closestL2;
    while ~isempty(yettoenterthering),
        dist_from_lastL2=sum((repmat(nodeTable(closestL2last,1:2),[length(yettoenterthering) 1])-nodeTable(yettoenterthering,1:2)).^2,2).^0.5;
        [dis,ind]=min(dist_from_lastL2); closestL2=yettoenterthering(ind);
        % establish bi-directional link
        linkTable=[linkTable;[closestL2last closestL2 dis];[closestL2 closestL2last dis]];
        yettoenterthering=yettoenterthering(logical(yettoenterthering~=closestL2));
        closestL2last=closestL2;
    end;
    % closing the ring
    dis=sum((nodeTable(closestL2last,1:2)-nodeTable(1,1:2)).^2,2).^0.5;
    linkTable=[linkTable;[closestL2last 1 dis];[1 closestL2last dis]];
    
    %Joining all the tables
    linkTable = [linkTable;linkTable_L2toE];

    %plotting netw
    linkAdjacencyMatrix = zeros(numNodes, numNodes);
    linkAdjacencyMatrix(sub2ind([numNodes numNodes], linkTable(:,1), linkTable(:,2)))=1;
%     gplot(linkAdjacencyMatrix,nodeTable(:,1:2),'o-')
end

function [nodeTable,linkTable,numCellSites_total,numFixPoints,numAggrNodesL3_total,numAggrNodesL2_total,numAggrNodesL1_total,nbof_module] = genTopology_Mobile_backhaul(sideLength,nbof_module,flag_diversity)
% % from paper mobile_backhaul

    numFixPoints=0;
%     nbof_module=4; 
    numCellSites=5; numAggrNodesL3=4; numAggrNodesL2=3; numAggrNodesL1=2;
    numCellSites_total=numCellSites*nbof_module; numAggrNodesL3_total=numAggrNodesL3*nbof_module; numAggrNodesL2_total=numAggrNodesL2*nbof_module; numAggrNodesL1_total=numAggrNodesL1*nbof_module;
    
    nodeTable=[]; linkTable=[];
    PoP = [0,0];
    nodeTable=[[0 0 0];nodeTable];
    for module_ind=1:nbof_module,
        x0=sideLength/nbof_module*((1)*(module_ind==1)+(-1)*(module_ind==2)+(-1)*(module_ind==3)+(1)*(module_ind==4)); 
        y0=sideLength/nbof_module*((1)*(module_ind==1)+(1)*(module_ind==2)+(-1)*(module_ind==3)+(-1)*(module_ind==4));
        shiftx=sideLength/sqrt(nbof_module)*((0)*(module_ind==1)+(-1)*(module_ind==2)+(-1)*(module_ind==3)+(0)*(module_ind==4));
        shifty=sideLength/sqrt(nbof_module)*((0)*(module_ind==1)+(0)*(module_ind==2)+(-1)*(module_ind==3)+(-1)*(module_ind==4));
        cellSites=sideLength/sqrt(nbof_module).*rand(numCellSites,2)+[shiftx*ones(numCellSites,1) shifty*ones(numCellSites,1)];
        fixPoints=sideLength.*rand(numFixPoints,2)-sideLength/2;
        points = [fixPoints; cellSites];
        [ids_aggrNodesL3, aggrNodesL3] = kmeans(points,numAggrNodesL3);
        [ids_aggrNodesL2, aggrNodesL2] = kmeans(aggrNodesL3, numAggrNodesL2);
        [ids_aggrNodesL1, aggrNodesL1] = kmeans(aggrNodesL2, numAggrNodesL1);
        % Adding some noise to prevent co-localisation with this topology
        aggrNodesL3=aggrNodesL3+(sideLength/sqrt(nbof_module))/10*rand(size(aggrNodesL3)); 
        aggrNodesL3(:,1)=max(aggrNodesL3(:,1),x0-sideLength/nbof_module); aggrNodesL3(:,1)=min(aggrNodesL3(:,1),x0+sideLength/nbof_module);
        aggrNodesL3(:,2)=max(aggrNodesL3(:,2),y0-sideLength/nbof_module); aggrNodesL3(:,2)=min(aggrNodesL3(:,2),y0+sideLength/nbof_module);
        aggrNodesL2=aggrNodesL2+(sideLength/sqrt(nbof_module))/10*rand(size(aggrNodesL2)); 
        aggrNodesL2(:,1)=max(aggrNodesL2(:,1),x0-sideLength/nbof_module); aggrNodesL2(:,1)=min(aggrNodesL2(:,1),x0+sideLength/nbof_module);
        aggrNodesL2(:,2)=max(aggrNodesL2(:,2),y0-sideLength/nbof_module); aggrNodesL2(:,2)=min(aggrNodesL2(:,2),y0+sideLength/nbof_module);
        aggrNodesL1=aggrNodesL1+(sideLength/sqrt(nbof_module))/10*rand(size(aggrNodesL1)); 
        aggrNodesL1(:,1)=max(aggrNodesL1(:,1),x0-sideLength/nbof_module); aggrNodesL1(:,1)=min(aggrNodesL1(:,1),x0+sideLength/nbof_module);
        aggrNodesL1(:,2)=max(aggrNodesL1(:,2),y0-sideLength/nbof_module); aggrNodesL1(:,2)=min(aggrNodesL1(:,2),y0+sideLength/nbof_module);
        
        Pgw=[x0,y0];
        
        %Creating Node Table : numNodes x 3 : (x, y, code)
        nodeTable_cellSites = [cellSites, 4*ones(numCellSites,1)];% code 4--> cell sites
%         nodeTable_fixPoints = [fixPoints, 3*ones(numFixPoints, 1)];%code 3--> fix endpoints
        nodeTable_aggrNodesL3 = [aggrNodesL3,3*ones(numAggrNodesL3, 1)];% code 2--> aggr nodes L3
        nodeTable_aggrNodesL2 = [aggrNodesL2,2*ones(numAggrNodesL2, 1)];% code 2--> aggr nodes L2
        nodeTable_aggrNodesL1 = [aggrNodesL1, ones(numAggrNodesL1, 1)]; % code 1--> aggr nodes L1
        nodeTable = [nodeTable; [x0 y0 -module_ind]; nodeTable_aggrNodesL1; nodeTable_aggrNodesL2; nodeTable_aggrNodesL3; nodeTable_cellSites ];% code -module_ind--> Pgw of the module
        
        %Creating Link Table : num Links x 3 : (src id, dst id, dist_km)
        offset=(1+numAggrNodesL1+numAggrNodesL2+numAggrNodesL3+numCellSites)*(module_ind-1);
        % Links btw L3 aggreg nodes and End points
        firstEndnode = 1+numAggrNodesL1+numAggrNodesL2+numAggrNodesL3+offset+1+1;
        lastEndnode = firstEndnode+numCellSites-1;
        dstID_L3toE = [firstEndnode:lastEndnode]';% End points (fix ones, first;  mobile ones, later)
        srcID_L3toE = reshape(1+offset+1+numAggrNodesL1+numAggrNodesL2+ids_aggrNodesL3,[numCellSites+numFixPoints,1]); % L3 aggre nodes
        dist_L3toE = sum((nodeTable(srcID_L3toE,1:2)-nodeTable(dstID_L3toE,1:2)).^2,2).^0.5; %euclidean distance
        linkTable_L3toE = [srcID_L3toE, dstID_L3toE, dist_L3toE];
        
        % Links btw L2 aggreg nodes and L3 aggreg nodes
        firstL3node = 1+numAggrNodesL1+numAggrNodesL2+offset+1+1;
        lastL3node = firstL3node+numAggrNodesL3-1;
        dstID_L2toL3 = [firstL3node:lastL3node]'; % L3 aggre nodes
        srcID_L2toL3 = reshape(1+offset+1+numAggrNodesL1+ids_aggrNodesL2,[numAggrNodesL3,1]); % L2 aggre nodes
        dist_L2toL3 = sum((nodeTable(srcID_L2toL3,1:2)-nodeTable(dstID_L2toL3,1:2)).^2,2).^0.5; %euclidean distance
        linkTable_L2toL3 = [srcID_L2toL3, dstID_L2toL3, dist_L2toL3];
        
        % Links btw L1 aggreg nodes and L2 aggreg nodes
        firstL2node = 1+numAggrNodesL1+offset+1+1;
        lastL2node = firstL2node+numAggrNodesL2-1;
        dstID_L1toL2 = [firstL2node:lastL2node]'; % L2 aggre nodes
        srcID_L1toL2 = reshape(1+offset+1+ids_aggrNodesL1,[numAggrNodesL2,1]); % L1 aggre nodes
        dist_L1toL2 = sum((nodeTable(srcID_L1toL2,1:2)-nodeTable(dstID_L1toL2,1:2)).^2,2).^0.5; %euclidean distance
        linkTable_L1toL2 = [srcID_L1toL2, dstID_L1toL2, dist_L1toL2];
        
        %Links btw Pgw and L1 aggreg nodes
        dstID_PgwtoL1 = [1+offset+1+1:1+offset+1+numAggrNodesL1]'; % L1 aggre nodes
        srcID_PgwtoL1 = (1+offset+1)*ones(numAggrNodesL1,1); % L1 aggre nodes
        dist_PgwtoL1 = sum((nodeTable(srcID_PgwtoL1,1:2)-nodeTable(dstID_PgwtoL1,1:2)).^2,2).^0.5; %euclidean distance
        linkTable_PgwtoL1 = [srcID_PgwtoL1, dstID_PgwtoL1, dist_PgwtoL1];
        
        %Joining all the tables
        linkTable = [linkTable;linkTable_PgwtoL1;linkTable_L1toL2;linkTable_L2toL3;linkTable_L3toE];
        
        if flag_diversity==1,
            % Additional links L1->L2
            ind_aggrNodesL1=1+offset+1+1:1+offset+1+numAggrNodesL1;
            ind_aggrNodesL2=dstID_L1toL2';
            pairs= combvec(ind_aggrNodesL1,ind_aggrNodesL2);
            pairs= pairs';
            for i=1:size(pairs,1),
                if ~ismember(pairs(i,:),[srcID_L1toL2 dstID_L1toL2],'rows'), % if not yet added, we add the link
                    dis = sum((nodeTable(pairs(i,1),1:2)-nodeTable(pairs(i,2),1:2)).^2,2).^0.5; %euclidean distance
                    linkTable = [linkTable;[pairs(i,1),pairs(i,2), dis]];
                end;
            end;
            % Additional links L2->L3
            ind_aggrNodesL2=1+offset+1+numAggrNodesL1+1:1+offset+1+numAggrNodesL1+numAggrNodesL2;
            ind_aggrNodesL3=dstID_L2toL3';
            totalnboflinks=7;
            nblinks_L2L3=sum(linkTable(:,1)==ind_aggrNodesL2(1)|linkTable(:,1)==ind_aggrNodesL2(2)|linkTable(:,1)==ind_aggrNodesL2(3));
            if nblinks_L2L3<totalnboflinks,
                sumdistL2toL3=zeros(1,numAggrNodesL2);
                for i=1:numAggrNodesL2,
                    for j=1:numAggrNodesL3,
                        dis=sum((nodeTable(ind_aggrNodesL2(i),1:2)-nodeTable(ind_aggrNodesL3(j),1:2)).^2,2).^0.5; %euclidean distance
                        sumdistL2toL3(i)=sumdistL2toL3(i)+dis;
                    end;
                end;
                [di,node5]=min(sumdistL2toL3);
                node5=ind_aggrNodesL2(node5);
                n4n6=setdiff(ind_aggrNodesL2,node5);
                node4=n4n6(1); node6=n4n6(2);
                nblinks_from5=sum(linkTable(:,1)==node5);
                if nblinks_from5<numAggrNodesL3,
                    pairs= combvec(node5,ind_aggrNodesL3);
                    pairs= pairs';
                    for i=1:size(pairs,1),
                        if ~ismember(pairs(i,:),[srcID_L2toL3 dstID_L2toL3],'rows'), % if not yet added, we add the link
                            dis = sum((nodeTable(pairs(i,1),1:2)-nodeTable(pairs(i,2),1:2)).^2,2).^0.5; %euclidean distance
                            linkTable = [linkTable;[pairs(i,1),pairs(i,2), dis]];
                        end;
                    end;
                end;
                nblinks_from46=sum(linkTable(:,1)==node4|linkTable(:,1)==node6);
                if nblinks_from46<3,
                    nblinks_from4=sum(linkTable(:,1)==node4);
                    if nblinks_from4<2,
                        notlinkedto4=dstID_L2toL3(logical(srcID_L2toL3~=node4)); notlinkedto4=unique(notlinkedto4);
                        pairs= combvec(node4,notlinkedto4');
                        pairs= pairs';
                        for i=1:size(pairs,1),
                            if ~ismember(pairs(i,:),[srcID_L2toL3 dstID_L2toL3],'rows'), % if not yet added, we add the link
                                dis = sum((nodeTable(pairs(i,1),1:2)-nodeTable(pairs(i,2),1:2)).^2,2).^0.5; %euclidean distance
                                linkTable = [linkTable;[pairs(i,1),pairs(i,2), dis]];
                            end;
                            if sum(linkTable(:,1)==node4)>=2,
                                break;
                            end;
                        end;
                    end;
                    nblinks_from6=sum(linkTable(:,1)==node6);
                    if nblinks_from6<1,
                        notlinkedto6=dstID_L2toL3(logical(srcID_L2toL3~=node6)); notlinkedto4=unique(notlinkedto4);
                        pairs= combvec(node6,notlinkedto6');
                        pairs= pairs';
                        for i=1:size(pairs,1),
                            if ~ismember(pairs(i,:),[srcID_L2toL3 dstID_L2toL3],'rows'), % if not yet added, we add the link
                                dis = sum((nodeTable(pairs(i,1),1:2)-nodeTable(pairs(i,2),1:2)).^2,2).^0.5; %euclidean distance
                                linkTable = [linkTable;[pairs(i,1),pairs(i,2), dis]];
                            end;
                            if sum(linkTable(:,1)==node6)>=1,
                                break;
                            end;
                        end;
                    end;
                end;
            end;
            % Additional links L3->end nodes
            ind_aggrNodesL3=1+offset+1+numAggrNodesL1+numAggrNodesL2+1:1+offset+1+numAggrNodesL1+numAggrNodesL2+numAggrNodesL3;
            ind_EndNodes=dstID_L3toE';
            totalnboflinks=10;
            nblinks_L3E=sum(linkTable(:,1)==ind_aggrNodesL3(1)|linkTable(:,1)==ind_aggrNodesL3(2)|linkTable(:,1)==ind_aggrNodesL3(3));
            if nblinks_L3E<totalnboflinks,
                sumdistL3toE=zeros(1,numAggrNodesL3);
                for i=1:numAggrNodesL3,
                    for j=1:numCellSites,
                        dis=sum((nodeTable(ind_aggrNodesL3(i),1:2)-nodeTable(ind_EndNodes(j),1:2)).^2,2).^0.5; %euclidean distance
                        sumdistL3toE(i)=sumdistL3toE(i)+dis;
                    end;
                end;
                [di,node8]=min(sumdistL3toE);
                sumdistL3toE=sumdistL3toE([1:node8-1 node8+1:end]);
                node8=ind_aggrNodesL3(node8);
                [di,node9]=min(sumdistL3toE);
                node9=ind_aggrNodesL3(node9);
                n7n10=setdiff(ind_aggrNodesL3,[node8,node9]);
                node7=n7n10(1); node10=n7n10(2);
                nblinks_from8=sum(linkTable(:,1)==node8); nblinks_from9=sum(linkTable(:,1)==node9);
                if nblinks_from8+nblinks_from9<6,
                    pairs= combvec(node8,ind_EndNodes(1:3));
                    pairs= pairs';
                    for i=1:size(pairs,1),
                        if ~ismember(pairs(i,:),[srcID_L3toE dstID_L3toE],'rows'), % if not yet added, we add the link
                            dis = sum((nodeTable(pairs(i,1),1:2)-nodeTable(pairs(i,2),1:2)).^2,2).^0.5; %euclidean distance
                            linkTable = [linkTable;[pairs(i,1),pairs(i,2), dis]];
                        end;
                    end;
                    pairs= combvec(node9,ind_EndNodes(3:5));
                    pairs= pairs';
                    for i=1:size(pairs,1),
                        if ~ismember(pairs(i,:),[srcID_L3toE dstID_L3toE],'rows'), % if not yet added, we add the link
                            dis = sum((nodeTable(pairs(i,1),1:2)-nodeTable(pairs(i,2),1:2)).^2,2).^0.5; %euclidean distance
                            linkTable = [linkTable;[pairs(i,1),pairs(i,2), dis]];
                        end;
                    end;
                end;
                nblinks_from710=sum(linkTable(:,1)==node7|linkTable(:,1)==node10);
                if nblinks_from710<4,
                    nblinks_from7=sum(linkTable(:,1)==node7);
                    if nblinks_from7<2,
                        notlinkedto7=dstID_L3toE(logical(srcID_L3toE~=node7)); notlinkedto7=unique(notlinkedto7);
                        pairs= combvec(node7,notlinkedto7');
                        pairs= pairs';
                        for i=1:size(pairs,1),
                            if ~ismember(pairs(i,:),[srcID_L3toE dstID_L3toE],'rows'), % if not yet added, we add the link
                                dis = sum((nodeTable(pairs(i,1),1:2)-nodeTable(pairs(i,2),1:2)).^2,2).^0.5; %euclidean distance
                                linkTable = [linkTable;[pairs(i,1),pairs(i,2), dis]];
                            end;
                            if sum(linkTable(:,1)==node7)>=2,
                                break;
                            end;
                        end;
                    end;
                    nblinks_from10=sum(linkTable(:,1)==node10);
                    if nblinks_from10<2,
                        notlinkedto10=dstID_L3toE(logical(srcID_L3toE~=node10)); notlinkedto10=unique(notlinkedto10);
                        pairs= combvec(node10,notlinkedto10');
                        pairs= pairs';
                        for i=1:size(pairs,1),
                            if ~ismember(pairs(i,:),[srcID_L3toE dstID_L3toE],'rows'), % if not yet added, we add the link
                                dis = sum((nodeTable(pairs(i,1),1:2)-nodeTable(pairs(i,2),1:2)).^2,2).^0.5; %euclidean distance
                                linkTable = [linkTable;[pairs(i,1),pairs(i,2), dis]];
                            end;
                            if sum(linkTable(:,1)==node10)>=2,
                                break;
                            end;
                        end;
                    end;
                end;
            end;
            
        end;
    end;


    % Joining the Pgw's with a mesh
    if nbof_module>=2,
        pairs_of_Pgw=nchoosek(1:nbof_module,2);
        for i=1:size(pairs_of_Pgw,1),
            mod1=pairs_of_Pgw(i,1); mod2=pairs_of_Pgw(i,2);
            dist=sum((nodeTable(logical(nodeTable(:,3)==-mod1),1:2)-nodeTable(logical(nodeTable(:,3)==-mod2),1:2)).^2,2).^0.5; %euclidean distance
            Pgw1=(1+numAggrNodesL1+numAggrNodesL2+numAggrNodesL3+numCellSites)*(mod1-1)+1+1; Pgw2=(1+numAggrNodesL1+numAggrNodesL2+numAggrNodesL3+numCellSites)*(mod2-1)+1+1;
            %linkTable = [[Pgw1 Pgw2 dist];[Pgw2 Pgw1 dist];linkTable];
            linkTable = [[Pgw1 Pgw2 dist];linkTable];
        end;
    end;
    % Joining the PoP to half of the Pgw
    if nbof_module<=2,
        mod1=1; Pgw=(1+numAggrNodesL1+numAggrNodesL2+numAggrNodesL3+numCellSites)*(mod1-1)+1+1;
        dist=sum((nodeTable(logical(nodeTable(:,3)==-0),1:2)-nodeTable(logical(nodeTable(:,3)==-mod1),1:2)).^2,2).^0.5; %euclidean distance
        linkTable = [[1 Pgw dist];linkTable];
    elseif nbof_module==4,
        mod1=1; Pgw=(1+numAggrNodesL1+numAggrNodesL2+numAggrNodesL3+numCellSites)*(mod1-1)+1+1;
        dist=sum((nodeTable(logical(nodeTable(:,3)==-0),1:2)-nodeTable(logical(nodeTable(:,3)==-mod1),1:2)).^2,2).^0.5; %euclidean distance
        linkTable = [[1 Pgw dist];linkTable];
        mod1=2; Pgw=(1+numAggrNodesL1+numAggrNodesL2+numAggrNodesL3+numCellSites)*(mod1-1)+1+1;
        dist=sum((nodeTable(logical(nodeTable(:,3)==-0),1:2)-nodeTable(logical(nodeTable(:,3)==-mod1),1:2)).^2,2).^0.5; %euclidean distance
        linkTable = [[1 Pgw dist];linkTable];
    else,
        err('nb of module not handled');
    end;
    
    numNodes=1+(1+numAggrNodesL1+numAggrNodesL2+numAggrNodesL3+numCellSites)*nbof_module;
    
    %-- Changing node indices
    nodeIndex_old=1:numNodes;
    nbof_intnodespermod=1+numAggrNodesL1+numAggrNodesL2+numAggrNodesL3;
    old_ids=[1];
    for ind_mod=1:nbof_module,
        offset=1+(nbof_intnodespermod+numCellSites)*(ind_mod-1);
        old_ids=[old_ids;(offset+1:offset+nbof_intnodespermod)'];
    end;
    for ind_mod=1:nbof_module,
        offset=1+(nbof_intnodespermod+numCellSites)*(ind_mod-1);
        old_ids=[old_ids;(offset+nbof_intnodespermod+1:offset+nbof_intnodespermod+numCellSites)'];
    end;
    nodeTable=nodeTable(old_ids,:);
    for i=1:size(linkTable,1),
        oldid=linkTable(i,1);
        newid=find(old_ids==oldid);
        linkTable(i,1)=newid;
        oldid=linkTable(i,2);
        newid=find(old_ids==oldid);
        linkTable(i,2)=newid;
    end;
    
    %plotting netw
    linkAdjacencyMatrix = zeros(numNodes, numNodes);
    linkAdjacencyMatrix(sub2ind([numNodes numNodes], linkTable(:,1), linkTable(:,2)))=1;
%     gplot(linkAdjacencyMatrix,nodeTable(:,1:2),'o-')
end
