function Generate_scen_forcurves(scenario_ind,topology_name,load)

totalrequests=1e4;
nbof_contentpercatalog=1e4;

switch scenario_ind
    %--- same load over time = 0.5:0.5:3, for Pareto (catalog compression recorded)
    case 1
        if nargin<3,
            error('an argument missing for Scen 1');
        end;
        [WDM_linkTable, CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes, nodeTable]=Get_topology(topology_name);
        nbof_catalog=1; catalog_share=1; % not active in this case
        [alpha,bmin,bmax,d_tc,vems,wdems,mat_content,mat_trace]=Get_traffic(nbof_mobendnodes,nbof_fixedendnodes,nbof_contentpercatalog,load,totalrequests,nbof_catalog,catalog_share);
        [infrastructuredata]=Get_Infrastructure(CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes);
        filename=['../simpoints/topo_traffic_scen1_',topology_name,'_L',num2str(load),'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
        Write_data(infrastructuredata,WDM_linkTable,CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes,nodeTable,...
            load,alpha,bmin,bmax,d_tc,wdems,vems,mat_content,mat_trace,filename);
    %--- constant load for simu
    case 2
        [WDM_linkTable, CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes, nodeTable]=Get_topology(topology_name);
        [infrastructuredata]=Get_Infrastructure(CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes);
        nbof_parts=1;
        load=1*ones(2,1);
        totalrequests=2e4;
        nbof_catalog=1; catalog_share=1; % not active in this case
        [alpha,bmin,bmax,d_tc,vems,wdems,mat_content,mat_trace]=Get_traffic_diffloads(nbof_mobendnodes,nbof_fixedendnodes,nbof_contentpercatalog,load,...
            totalrequests,nbof_catalog,catalog_share,nbof_parts);
        filename=['../simpoints/topo_traffic_scen2_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
        Write_data(infrastructuredata,WDM_linkTable,CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes,nodeTable,...
            load,alpha,bmin,bmax,d_tc,vems,wdems,mat_content,mat_trace,filename);
    %--- different loads over time and space
    case 22
        [WDM_linkTable, CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes, nodeTable]=Get_topology(topology_name);
        [infrastructuredata]=Get_Infrastructure(CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes);
        nbof_parts=4;
        load=0.05*[1 20 1 1;1 1 20 1]; %[1 5 1 1;1 1 5 1];
        nbof_catalog=1; catalog_share=1; % not active in this case
        [alpha,bmin,bmax,d_tc,vems,wdems,mat_content,mat_trace]=Get_traffic_diffloads(nbof_mobendnodes,nbof_fixedendnodes,nbof_contentpercatalog,load,...
            totalrequests,nbof_catalog,catalog_share,nbof_parts);
        filename=['../simpoints/topo_traffic_scen22_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
        Write_data(infrastructuredata,WDM_linkTable,CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes,nodeTable,...
            load,alpha,bmin,bmax,d_tc,vems,wdems,mat_content,mat_trace,filename);
    %--- different catalogs over time and space
    case 3
        [WDM_linkTable, CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes, nodeTable]=Get_topology(topology_name);
        [infrastructuredata]=Get_Infrastructure(CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes);
        nbof_parts=4;
        load=0.05*[1 1 1 1;1 1 1 1];
        nbof_catalog=2;
        catalog_share=[1 1 0.8 0;1 0.8 0 0];
        [alpha,bmin,bmax,d_tc,vems,wdems,mat_content,mat_trace]=Get_traffic_diffloads(nbof_mobendnodes,nbof_fixedendnodes,nbof_contentpercatalog,load,...
            totalrequests,nbof_catalog,catalog_share,nbof_parts);
        filename=['../simpoints/topo_traffic_scen3_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
        Write_data(infrastructuredata,WDM_linkTable,CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes,nodeTable,...
            load,alpha,bmin,bmax,d_tc,vems,wdems,mat_content,mat_trace,filename);
end

end

function Write_data(infrastructuredata,WDM_linkTable,CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes,nodeTable,...
    load,alpha,bmin,bmax,d_tc,vems,wdems,mat_content,mat_trace,filename)

topologydata=struct();
topologydata.WDM_linkTable = WDM_linkTable;
topologydata.CPRI_linkTable=CPRI_linkTable;
topologydata.pathInfo=pathInfo;
topologydata.nbof_mobendnodes=nbof_mobendnodes;
topologydata.nbof_fixedendnodes=nbof_fixedendnodes;
topologydata.nodeTable = nodeTable;
videodata=struct();
videodata.load=load;
videodata.alpha=alpha;
videodata.bmin=bmin;
videodata.bmax=bmax;
videodata.d_tc=d_tc;
videodata.vems=vems;
videodata.wdems=wdems;
videodata.mat_content=mat_content;
videodata.mat_trace=mat_trace;
beta=0.5;
videodata.beta=beta;

%background traffic
N = size(pathInfo.bin_nodesInPath,1);
backgroundTraff = sparse(N,1);

save(filename,'topologydata','videodata','infrastructuredata','backgroundTraff');

end

function [alpha,bmin_ms,bmax_ms,d_tc,vems,wdems,mat_content,mat_trace]=Get_traffic_diffloads(nbof_mobendnodes,nbof_fixedendnodes,nbof_contentpercatalog,load,...
    totalrqsts,nbof_catalog,catalog_share,nbof_parts)

[alpha,bmin_ms,bmax_ms,d_tc]=Get_alphas_d();
nbof_videotype=size(alpha,1);
nbof_resol=size(alpha,2);

nbof_content=nbof_contentpercatalog;

nbof_endnodes=nbof_mobendnodes+nbof_fixedendnodes;

if size(load,1)~=2||size(load,2)~=nbof_parts,
    error('load does not have the right size');
end;
lambda=0.4*load;
% lambda=lambda*ones(1,nbof_endnodes);

Zipf_param=0.8;

vec_videodur=[4 15 60]; % in min
vec_watchdur=[0.72 0.65 1.00]; % fraction
vec_type=[1 2 3]; % 1: toon, 2: movie, 3: sport

dist_videodur_fix=[0.5,0.3,0.2]; % fraction
thresh_pop=0.1;
dist_videodur_mob_highpop=[0.66 0.24 0.1];
dist_videodur_mob_lowpop=[0.5 0.3 0.2];

if nbof_catalog==1,
    
    mat_pop_fix=zeros(4,nbof_content);
    for m=1:nbof_content,
        %-- video id
        mat_pop_fix(1,m)=m;
        %-- video type
        mat_pop_fix(2,m)=randi(nbof_videotype,1);
        %-- video duration
        ra=rand(1); a=cumsum(dist_videodur_fix)>ra; mat_pop_fix(3,m)=vec_videodur(find(cumsum(a)==1));
        %-- video freq in fix end nodes
        mat_pop_fix(4,m)=1/m^Zipf_param;
    end;
    mat_pop_fix(4,:)=mat_pop_fix(4,:)/sum(mat_pop_fix(4,:)); cdffreq_fix=cumsum(mat_pop_fix(4,:));
    
    mat_pop_mob=zeros(4,nbof_content);
    contentnotyetmob=mat_pop_fix(1,:);
    for indcontentmob=1:nbof_content,
        m=contentnotyetmob(1);
        if mat_pop_fix(4,m)>thresh_pop,
            ra=rand(1); a=cumsum(dist_videodur_mob_highpop)>ra; durpicked=vec_videodur(find(cumsum(a)==1));
        else
            ra=rand(1); a=cumsum(dist_videodur_mob_lowpop)>ra; durpicked=vec_videodur(find(cumsum(a)==1));
        end;
        if mat_pop_fix(3,m)==durpicked,
            mat_pop_mob(:,indcontentmob)=mat_pop_fix(:,m);
        else
            v=find(mat_pop_fix(3,contentnotyetmob)==durpicked);
            if ~isempty(v),
                m=contentnotyetmob(v(1));
            else
                m=contentnotyetmob(1);
            end;
            mat_pop_mob(:,indcontentmob)=mat_pop_fix(:,m);
        end
        v=1-(contentnotyetmob==m);
        contentnotyetmob=contentnotyetmob(logical(v));
    end
    for indcontentmob=1:nbof_content,
        %-- video freq in mobile end nodes
        mat_pop_mob(4,indcontentmob)=1/indcontentmob^Zipf_param;
    end;
    mat_pop_mob(4,:)=mat_pop_mob(4,:)/sum(mat_pop_mob(4,:)); cdffreq_mob=cumsum(mat_pop_mob(4,:));
    dist_resol_fix=[0.3 0.3 0.3 0.1]; % for 360|720|1080|2160
    dist_resol_mob=[0.4 0.4 0.2 0];
    
    %-- bw last hop in Mbps
    bw_fix_modes=[5 15 30 40 60 80];
    bw_mob_modes=[2 5 10 15 20 25];
    
    mat_trace=[];
    rqst_time=zeros(1,nbof_endnodes);
    t=0;
    for endnode_index=1:nbof_endnodes,
        %-- 1st half of fixed or mobile end nodes
        if (endnode_index<=nbof_fixedendnodes && endnode_index<=nbof_fixedendnodes/2)...
                || (endnode_index>nbof_fixedendnodes && endnode_index<=nbof_endnodes && endnode_index<=nbof_fixedendnodes+nbof_mobendnodes/2),
            rqst_time(endnode_index)=t+exprand(1/lambda(1,1));
            
        %-- 2nd half of fixed or mobile end nodes
        else,
            rqst_time(endnode_index)=t+exprand(1/lambda(2,1));
        end;
    end;
    [t,endnode_index]=min(rqst_time);
    while(size(mat_trace,1)<totalrqsts) % (t<totaltime)
        part_ind=ceil((size(mat_trace,1)+1)/totalrqsts*nbof_parts);
        if endnode_index>nbof_fixedendnodes&&endnode_index<=nbof_endnodes,
            %-- Choice of content--
            ra=rand(1); a=cdffreq_mob>ra; m=mat_pop_mob(1,find(cumsum(a)==1));
            %-- Choice of resol--
            ra=rand(1); a=cumsum(dist_resol_mob)>ra; s=find(cumsum(a)==1);
            %-- Choice of bw last hop--
            bwlasthop=bw_mob_modes(randi(length(bw_mob_modes),1));
        else,
            %-- Choice of content--
            ra=rand(1); a=cdffreq_fix>ra; m=mat_pop_fix(1,find(cumsum(a)==1));
            %-- Choice of resol--
            ra=rand(1); a=cumsum(dist_resol_fix)>ra; s=find(cumsum(a)==1);
            %-- Choice of bw last hop--
            bwlasthop=bw_fix_modes(randi(length(bw_fix_modes),1));
        end;
        type=mat_pop_fix(2,m); dur=mat_pop_fix(3,m);
        %-- video size
        siz=2.1*bmax_ms(type,max(3,s))/8*dur*60; % % in MB. x2.1 from iProxy repr. We store 1080p by default, 4K if needed
        %-- Choice of watching duration--
        watchingdur=vec_watchdur(randi(length(vec_watchdur),1))*dur;
        
        mat_trace=[mat_trace;[t endnode_index m s type siz watchingdur bwlasthop dur]];
        %-- 1st half of fixed or mobile end nodes
        if (endnode_index<=nbof_fixedendnodes && endnode_index<=nbof_fixedendnodes/2)...
                || (endnode_index>nbof_fixedendnodes && endnode_index<=nbof_endnodes && endnode_index<=nbof_fixedendnodes+nbof_mobendnodes/2),
            rqst_time(endnode_index)=t+exprand(1/lambda(1,part_ind));
            
        %-- 2nd half of fixed or mobile end nodes
        else,
            rqst_time(endnode_index)=t+exprand(1/lambda(2,part_ind));
        end;
        [t,endnode_index]=min(rqst_time);
    end;
    
elseif nbof_catalog==2,
    if size(catalog_share,1)~=2||size(catalog_share,2)~=nbof_parts,
        error('catalog_share does not have the right size');
    end;
    for catalog_ind=1:nbof_catalog,
        mat_pop_fix=zeros(4,nbof_content);
        for m=1:nbof_content,
            %-- video id
            mat_pop_fix(1,m)=m;
            %-- video type
            mat_pop_fix(2,m)=randi(nbof_videotype,1);
            %-- video duration
            ra=rand(1); a=cumsum(dist_videodur_fix)>ra; mat_pop_fix(3,m)=vec_videodur(find(cumsum(a)==1));
            %-- video freq in fix end nodes
            mat_pop_fix(4,m)=1/m^Zipf_param;
        end;
        mat_pop_fix(4,:)=mat_pop_fix(4,:)/sum(mat_pop_fix(4,:)); cdffreq_fix=cumsum(mat_pop_fix(4,:));
        
        mat_pop_mob=zeros(4,nbof_content);
        contentnotyetmob=mat_pop_fix(1,:);
        for indcontentmob=1:nbof_content,
            m=contentnotyetmob(1);
            if mat_pop_fix(4,m)>thresh_pop,
                ra=rand(1); a=cumsum(dist_videodur_mob_highpop)>ra; durpicked=vec_videodur(find(cumsum(a)==1));
            else
                ra=rand(1); a=cumsum(dist_videodur_mob_lowpop)>ra; durpicked=vec_videodur(find(cumsum(a)==1));
            end;
            if mat_pop_fix(3,m)==durpicked,
                mat_pop_mob(:,indcontentmob)=mat_pop_fix(:,m);
            else
                v=find(mat_pop_fix(3,contentnotyetmob)==durpicked);
                if ~isempty(v),
                    m=contentnotyetmob(v(1));
                else
                    m=contentnotyetmob(1);
                end;
                mat_pop_mob(:,indcontentmob)=mat_pop_fix(:,m);
            end
            v=1-(contentnotyetmob==m);
            contentnotyetmob=contentnotyetmob(logical(v));
        end
        for indcontentmob=1:nbof_content,
            %-- video freq in mobile end nodes
            mat_pop_mob(4,indcontentmob)=1/indcontentmob^Zipf_param;
        end;
        mat_pop_mob(4,:)=mat_pop_mob(4,:)/sum(mat_pop_mob(4,:)); cdffreq_mob=cumsum(mat_pop_mob(4,:));
        
        if catalog_ind==1, 
            mat_pop_fix_tens=mat_pop_fix; cdffreq_fix_tens=cdffreq_fix; mat_pop_mob_tens=mat_pop_mob; cdffreq_mob_tens=cdffreq_mob;
        elseif catalog_ind==2, 
            mat_pop_fix(1,:)=mat_pop_fix(1,:)+nbof_content; mat_pop_mob(1,:)=mat_pop_mob(1,:)+nbof_content;
            mat_pop_fix_tens(:,:,2)=mat_pop_fix; cdffreq_fix_tens(:,:,2)=cdffreq_fix; mat_pop_mob_tens(:,:,2)=mat_pop_mob; cdffreq_mob_tens(:,:,2)=cdffreq_mob;
        end;
    end;
    
    dist_resol_fix=[0.3 0.3 0.3 0.1]; % for 360|720|1080|2160
    dist_resol_mob=[0.4 0.4 0.2 0];
    
    %-- bw last hop in Mbps
    bw_fix_modes=[5 15 30 40 60 80];
    bw_mob_modes=[2 5 10 15 20 25];
    
    % % 1st half of mob and fix end nodes take 80% from catalog 1, 20% from
    % catalg 2, other way around for the 2nd half of nodes
%     catalog_share=0.8;
    
    mat_trace=[];
    rqst_time=zeros(1,nbof_endnodes);
    t=0;
    for endnode_index=1:nbof_endnodes,
        %-- 1st half of fixed or mobile end nodes
        if (endnode_index<=nbof_fixedendnodes && endnode_index<=nbof_fixedendnodes/2)...
                || (endnode_index>nbof_fixedendnodes && endnode_index<=nbof_endnodes && endnode_index<=nbof_fixedendnodes+nbof_mobendnodes/2),
            rqst_time(endnode_index)=t+exprand(1/lambda(1,1));
            
        %-- 2nd half of fixed or mobile end nodes
        else,
            rqst_time(endnode_index)=t+exprand(1/lambda(2,1));
        end;
    end;
    [t,endnode_index]=min(rqst_time);
    while(size(mat_trace,1)<totalrqsts) % (t<totaltime)
        part_ind=ceil((size(mat_trace,1)+1)/totalrqsts*nbof_parts);
        if endnode_index>nbof_fixedendnodes&&endnode_index<=nbof_endnodes,  % % mobile
            %-- Choice of catalog--
            if endnode_index<=nbof_fixedendnodes+nbof_mobendnodes/2,
                ra=rand(1); catalog_ind=1*(ra<=catalog_share(1,part_ind))+2*(ra>catalog_share(1,part_ind));
            else
                ra=rand(1); catalog_ind=1*(ra<=catalog_share(2,part_ind))+2*(ra>catalog_share(2,part_ind));
            end;
            %-- Choice of content--
            ra=rand(1); a=cdffreq_mob_tens(:,:,catalog_ind)>ra; m=mat_pop_mob_tens(1,find(cumsum(a)==1),catalog_ind);
            %-- Choice of resol--
            ra=rand(1); a=cumsum(dist_resol_mob)>ra; s=find(cumsum(a)==1);
            %-- Choice of bw last hop--
            bwlasthop=bw_mob_modes(randi(length(bw_mob_modes),1));
        else   % % fixed
            %-- Choice of catalog--
            if endnode_index<=nbof_fixedendnodes/2,
                ra=rand(1); catalog_ind=1*(ra<=catalog_share(1,part_ind))+2*(ra>catalog_share(1,part_ind));
            else
                ra=rand(1); catalog_ind=1*(ra<=catalog_share(2,part_ind))+2*(ra>catalog_share(2,part_ind));
            end;
            %-- Choice of content--
            ra=rand(1); a=cdffreq_fix_tens(:,:,catalog_ind)>ra; m=mat_pop_fix_tens(1,find(cumsum(a)==1),catalog_ind);
            %-- Choice of resol--
            ra=rand(1); a=cumsum(dist_resol_fix)>ra; s=find(cumsum(a)==1);
            %-- Choice of bw last hop--
            bwlasthop=bw_fix_modes(randi(length(bw_fix_modes),1));
        end;
        mind=m-(catalog_ind-1)*nbof_content;
        type=mat_pop_fix_tens(2,mind,catalog_ind); dur=mat_pop_fix_tens(3,mind,catalog_ind);
        %-- video size
        siz=2.1*bmax_ms(type,max(3,s))/8*dur*60; % % in MB. x2.1 from iProxy repr. We store 1080p by default, 4K if needed
        %-- Choice of watching duration--
        watchingdur=vec_watchdur(randi(length(vec_watchdur),1))*dur;
        
        mat_trace=[mat_trace;[t endnode_index m s type siz watchingdur bwlasthop dur]];
        
        %-- 1st half of fixed or mobile end nodes
        if (endnode_index<=nbof_fixedendnodes && endnode_index<=nbof_fixedendnodes/2)...
                || (endnode_index>nbof_fixedendnodes && endnode_index<=nbof_endnodes && endnode_index<=nbof_fixedendnodes+nbof_mobendnodes/2),
            rqst_time(endnode_index)=t+exprand(1/lambda(1,part_ind));
            
        %-- 2nd half of fixed or mobile end nodes
        else,
            rqst_time(endnode_index)=t+exprand(1/lambda(2,part_ind));
        end;
        [t,endnode_index]=min(rqst_time);
    end;
    
else,
    err('nbof_catalog has a wrong value');
end;

%-- Build mat_content(:,i)=[m type dur siz flag4K]'
nbof_content2=nbof_catalog*nbof_content;
lt=size(mat_trace,1); mat_content=[];
for trace_ind=1:lt,
    m=mat_trace(trace_ind,3); s=mat_trace(trace_ind,4); type=mat_trace(trace_ind,5); siz=mat_trace(trace_ind,6); dur=mat_trace(trace_ind,9);
    if s==4,
        flag4K=1;
        id=m+nbof_content2;
        mat_trace(trace_ind,3)=id;
    else,
        flag4K=0;
        id=m;
    end;
    if size(mat_content,2)==0,
        mat_content=[mat_content,[id type dur siz flag4K]'];
    elseif sum(mat_content(1,:)==id)==0,
        mat_content=[mat_content,[id type dur siz flag4K]'];
    end;
end;
mat_trace=mat_trace(:,1:8);

% % Update content ids with only those appearing in the trace
nbof_content2=size(mat_content,2);
new_ids=1:nbof_content2;
old_ids=mat_content(1,:);
mat_content(1,:)=new_ids;
for i=1:size(mat_trace,1),
    oldid=mat_trace(i,3);
    newid=find(old_ids==oldid);
    mat_trace(i,3)=newid;
end;

%--- Computation of vems (number of parallel requests)--
vems=sparse(1,nbof_endnodes*nbof_content2*nbof_resol);
wdems=sparse(1,nbof_endnodes*nbof_content2*nbof_resol);
occur_ems=sparse(1,nbof_endnodes*nbof_content2*nbof_resol);
trace_time=mat_trace(:,1);
for trace_ind=1:size(mat_trace,1),
    e=mat_trace(trace_ind,2); m=mat_trace(trace_ind,3); s=mat_trace(trace_ind,4);
    ind_ems=(e-1)*nbof_content2*nbof_resol+(m-1)*nbof_resol+s;
    vems(ind_ems)=vems(ind_ems)+mat_trace(trace_ind,7)*60/trace_time(end);
    wdems(ind_ems)=wdems(ind_ems)+mat_trace(trace_ind,7)*60;
    occur_ems(ind_ems)=occur_ems(ind_ems)+1;
end;
wdems(occur_ems>0)=wdems(occur_ems>0)./occur_ems(occur_ems>0);
%----

end

