function [alpha,bmin,bmax,d_tc]=Get_alphas_d()

%% - We consider 3 video types (toon/Bosphorus in 4K, movie/jockey in 4K, sport/readysetgo in 4K).
%% - We re-compute for 4K the QoE in the same way as done for MMSyS15 for lower resol. We obtain (1-VQMnorm) for 4K.
%% - For each resol and type, we take the line from QoE(bmin) to QoE(b)=0.96, and bmax=QoE^-1(0.98)
%% - Then QoE=alpha b+ beta

%% outputs size nbof_videotype x nbof_resol [types: toon, movie, sport]
%% [resol: 360, 720, 1080, 4K]

%% The code commented below serves to find the values used from line 62 once and for all.

% % bitrate4K=[2:2:30]*1000;
% % VQM4K=[3.1,2.4,1.9,1.5,1.3,1.2,1.15,1.1,1.0,0.98,0.96,0.94,0.925,0.91,0.9;
% %     6.3,4.8,3.9,3.2,2.65,2.1,1.95,1.8,1.65,1.5,1.4,1.33,1.27,1.24,1.22;
% %     8.7,6.5,5.2,4.3,3.7,3.0,2.5,2.2,2.0,1.8,1.6,1.45,1.4,1.35,1.3];
% % 
% % VQM4K=VQM4K-repmat(min(VQM4K,[],2),1,size(VQM4K,2));
% % VQM4K=VQM4K./repmat(max(VQM4K,[],2),1,size(VQM4K,2));
% % VQM4K=1-VQM4K;
% % 
% % fBos = fit(bitrate4K',VQM4K(1,:)','power2');
% % fJok = fit(bitrate4K',VQM4K(2,:)','power2');
% % fRSG = fit(bitrate4K',VQM4K(3,:)','power2');
% % % plot(bitrate4K,VQM4K(1,:),'or',bitrate4K,VQM4K(2,:),'og',bitrate4K,VQM4K(3,:),'ob');
% % rate=(2:0.5:30)*1000;
% % % hold on;
% % cBos=coeffvalues(fBos); cJok=coeffvalues(fJok); cRSG=coeffvalues(fRSG);
% % % plot(rate,cBos(1)*rate.^cBos(2)+cBos(3),'-r'); plot(rate,cJok(1)*rate.^cJok(2)+cJok(3),'-g'); plot(rate,cRSG(1)*rate.^cRSG(2)+cRSG(3),'-b'); 

nbof_videotype=3;
nbof_resol=4;
% % a = [-48.287172,-1425.351349,-244.124234;-56.653398,-775052.6002,-44331.0262;-26.016439,-17.593112,-57.3322];
% % a=[a,[cBos(1);cJok(1);cRSG(1)]];
% % b = [-1.169053,-1.501161,-1.144599;-0.893399, -2.118902, -1.599378;-0.606764, -0.421462, -0.546566];
% % b=[b,[cBos(2);cJok(2);cRSG(2)]];
% % c = [1,1,1.01;1.06,1.01,1.02;1.21,1.4,1.4];
% % c=[c,[cBos(3);cJok(3);cRSG(3)]];
% % 
% % %codeRates=[200:200:8500]; % % kbps
% % codeRates=(0.2:0.5:30)*1000;
% % scr=length(codeRates);
% % qoe=repmat(a,[1 1 scr]).*repmat(reshape(codeRates,[1,1,scr]),[nbof_videotype nbof_resol 1]).^repmat(b,[1 1 scr])+repmat(c,[1 1 scr]);
% % qoe(qoe>1)=1;
% % qoe(qoe<0)=0; %0.6 from MMSyS data, 0 for 4K data
% % 
% % upperthresh=0.96;
% % upperthresh_bmax=0.98;
% % for ind_videotype=1:nbof_videotype,
% %     for ind_resol=1:nbof_resol,
% %         indvec=find(qoe(ind_videotype,ind_resol,:)>0); ind_bmin=indvec(1);
% %         %[mi,ind_bmin]=min(abs(qoe(ind_videotype,ind_resol,:)-0));
% %         [mi,ind_al]=min(abs(qoe(ind_videotype,ind_resol,ind_bmin:end)-upperthresh));
% %         [mi,ind_bmax]=min(abs(qoe(ind_videotype,ind_resol,ind_bmin:end)-upperthresh_bmax));
% %         ind_al=ind_al+ind_bmin-1; ind_bmax=ind_bmax+ind_bmin-1; 
% %         bmin(ind_videotype,ind_resol)=codeRates(ind_bmin);
% %         bmax(ind_videotype,ind_resol)=codeRates(ind_bmax);
% %         alpha(ind_videotype,ind_resol)=(qoe(ind_videotype,ind_resol,ind_al)-qoe(ind_videotype,ind_resol,ind_bmin))/(codeRates(ind_al)-codeRates(ind_bmin));
% %     end;
% % end;

alpha=[0.1516    0.4668    0.3456    0.0499;
    0.3978    0.3421    0.1336    0.0466;
    0.4005    0.1216    0.1238    0.0443];
bmin=1.0e-03 * [ 200         200         200        2200;
         200         700        1200        2200;
         200         700        1200        2200];
bmax=1.0e-03 * [ 700        1700        2700       22700;
        1700        3200        6200       24200;
        2200        7200        8200       24700];

%-- d_tc is 2(only 1080 and 4K in cache possibly) x nbof_resol x nbof_type
% % starting from 1080
d_tc=zeros(2,nbof_resol,nbof_videotype);

CPU_MMSyS15(1,4,1)=0; CPU_MMSyS15(1,3,1)=1.56; CPU_MMSyS15(1,2,1)=1.38; CPU_MMSyS15(1,1,1)=0.85;
CPU_MMSyS15(1,4,2)=0; CPU_MMSyS15(1,3,2)=2.21; CPU_MMSyS15(1,2,2)=1.78; CPU_MMSyS15(1,1,2)=1.35;
CPU_MMSyS15(1,4,3)=0; CPU_MMSyS15(1,3,3)=2.74; CPU_MMSyS15(1,2,3)=2.24; CPU_MMSyS15(1,1,3)=1.25;
max_PassMark_1080=2000;

d_tc(1,:,:)=2000/max(CPU_MMSyS15(:))*CPU_MMSyS15;
d_tc(2,4,:)=4*d_tc(1,3,:);

%  Physical server (Intel(R) Xeon(R) CPU E5-2630 2.3GHz 12 cores): 8915
%  passmarks, then, 8915/12 passmarks per core
d_tc = d_tc./(8915/12); % # VMs (cores) per transcoding 
