function [infrastructureData]=Get_Infrastructure(CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes)

% Dimensions
E_M = nbof_mobendnodes; % numMobileEndNodes;
E_F = nbof_fixedendnodes; % numFixEndNodes;
E = E_M+E_F;  % numEndNodes;
N = size(pathInfo.bin_nodesInPath,1);
L = size(pathInfo.bin_edgesInPath,1);
% 
% M = size(videoInfo.videosPerFixPoint_byContDev,1);%     numContents;
% S = size(videoInfo.videosPerFixPoint_byContDev,2);%     numResols(=numDevices);
% P = pathInfo.P;
% pathInfo = struct('P',P, 'bin_nodePairs',sparse(N^2,P) ,'bin_initNodes',sparse(N,P), 'bin_endNodes',sparse(N,P), 'bin_nodesInPath', sparse(N,P), 'bin_edgesInPath', sparse(L,P));        

   
%Number of VMsrequired to perform the BBU operations corresponding to base station node e_m 
% using the DIGITAL BASEBAND PROCESSING MODEL in debaillie2015powBS

% Table SCALING EXPONENTS FOR DIGITAL SUB-COMPONENTS: subcomponent c by
% input parameter i. 
% subcomponent = {Subcomponent 		Predistortion 		Filtering 		Up/Down-sampling 		TD non-ideal. est./comp. 		FFT/IFFT, FD non-ideal. 		MIMO precoding 		Synchronization 		Channel est. & interp. 		Equalizer computation 		Equalization 		OFDM Mod./Demod. 		Mapping/Demapping 		Channel coding 		Control 		Network 	}
% input parameter = {BW 	S. E. 	Ant. 	Load 	Streams 	Q }
s_ci =	[	1	0	1	0	0	1.2 ; 
            1	0	1	0	0	1.2 ; 
			1	0	1	0	0	1.2 ;
			1	0	1	0	0	1.2 ;
            1.2 0	1	0	0	1.2 ;
        	1	0	1	1	1	1.2 ;
			0	0	1	0	0	1.2 ;
            1	0	1	.5 	1	1.2 ;
            1	0	3	1	0	1.2 ;
            1	0	2	1	0	1.2 ;
            1	0	1	.5 	0	1.2 ;
            1	1.5 	0	1	1	1.2; 
            1	1	0	1	1	1.2 ;
			0	0	.5 	0	.2 	.2 ;
			1	1	0	1	0	0;];                  
%REFERENCE COMPLEXITY OF DIGITAL COMPONENTS FOR SISO, 20 MHZ, 6 BPS/HZ
%(64-QAM, CODING RATE 1). Downlink (GOPS)
gops_c = [10.7 		6.7 		2		1.3 		4		1.3 		0		0		0		0		1.3 		1.3 		1.3 		2.7 		8	];        

% reference scenario: 20 MHz single-antenna operation, full load (frequency-domain), spectral efficiency 6 bps/Hz (e.g. 64-QAM, coding rate 1) and 24-bit quantization.
i_ref = [20 6 1 1 1 24];
% paper scenario : 3 sectors with 20 MHz bandwidth and 2?2 MIMO configuration (6 antennas), full load (frequency-domain: we use all te RBs and all the subcarriers in each RB), spectral efficiency 4.5234 bps/Hz (CQI index 13 64-QAM, coding rate 0.75) and 24-bit quantization 
i_act = [20 4.5234 6 1 6 24];
gops = 0; %gops required to perform the BBU operations corresponding to base station node e_m 
for c = 1:size(s_ci,1),
    gops = gops + gops_c(c)*prod((i_act./i_ref).^s_ci(c,:));
end

%Considerig that a data center node is composed by G machines type Intel
%Xeon e5-2630 with K=12 cores 
%data from: https://asteroidsathome.net/boinc/cpu_list.php
%CPU model                                                     Number of computers	Avg. cores/computer	GFLOPS/core	GFLOPs/computer
%Intel(R) Xeon(R) CPU E5-2630 0 @ 2.30GHz [Family 6 Model 45 Stepping 7]	23	11.43	2.55	29.19
%https://setiathome.berkeley.edu/cpu_list.php
% Intel(R) Xeon(R) CPU E5-2630 0 @ 2.30GHz [Family 6 Model 45 Stepping 7]	54	15.39	2.49	38.37
%%Considering Peak FLOPS = Number of Cores * Average Frequency * Operations
%%per Cycle (12*2.3*?) ? = 8/16
% 2.5 GFLOPS/core
infrastructureData.d_bbu_e = (gops/2.5)*ones(E_M,1); %Number of VMs required to perform the BBU operations corresponding to base station node e_m 

BigM = 1e6;
% Network Transport Capacities
infrastructureData.LTEcap = 455.62;% Mbps
infrastructureData.WDMcap = 10*1e3;% Mbps
infrastructureData.IPRcap = 560*1e3;% Mbps
infrastructureData.EGScap = 320*1e3;% Mbps
% Storage Capacities
infrastructureData.nodeStorage = 500*1000*ones(N,1); %Mbytes
% Data Center (Intel(R) Xeon(R) CPU E5-2630)
infrastructureData.G_n = 16*ones(N,1);%  max num physical servers per node
infrastructureData.K = 12;%  max num VMs per physical server, This is T in the paper
% Poer consumption elements        
infrastructureData.IPRpower = 4550; %Watts
infrastructureData.EGSpower = 2020; %Watts
infrastructureData.SRVpower = 106.4; %Watts (Intel(R) Xeon(R) CPU E5-2630)
infrastructureData.VMpower = 10.417; %Watts (Intel(R) Xeon(R) CPU E5-2630)

end
