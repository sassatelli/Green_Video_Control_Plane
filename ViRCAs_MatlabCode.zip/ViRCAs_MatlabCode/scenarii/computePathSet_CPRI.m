% loopback_paths = 1 ---> path coming out from and going into the same node
function [pathInfo] = computePathSet_CPRI (linkTable,maxCPRIreach,loopback_paths)

    N=max(max(linkTable));% numNodes
    L=size(linkTable,1); %numLinks
    
    % A path is a sequence of traversed link ids.
    cellOfPathsAsSeqLinks = cell (0,1);
    cellOfPathsAsSeqNodes = cell (0,1);
    
    listOfPathsAsSeqLinks = cell (1,1);
    listOfPathsAsSeqNodes = cell (1,1);

    outgoingLinksFromNode = cell(1,N);
    incomingLinksToNode = cell(1,N);
    for n = 1:N,
        outgoingLinksFromNode{n} = find(linkTable(:,1) == n);
        incomingLinksToNode{n} = find(linkTable(:,2) == n);
    end
    % calculate the  paths of one hop
    linkIdsOfPaths = []; 
    for linkID = 1:L,
        linkIdsOfPaths = [linkIdsOfPaths linkID];
    end 
    linkIdsOfPaths = reshape (linkIdsOfPaths , numel (linkIdsOfPaths) , 1);
    listOfPathsAsSeqLinks{1,1} = linkIdsOfPaths;  % one row for each path 
    listOfPathsAsSeqNodes{1,1} = linkTable(linkIdsOfPaths,1:2);  % one row for each path 
    
    a=listOfPathsAsSeqLinks{1,1+0};
    b=linkTable(a,3);
    c=reshape(b,size(a));
    distofpaths=sum(c,2);
    listOfPathsAsSeqLinks{1,1+0}=a(distofpaths<maxCPRIreach,:);
    a=listOfPathsAsSeqNodes{1,1+0};
    listOfPathsAsSeqNodes{1,1+0}=a(distofpaths<maxCPRIreach,:);
    
    cellOfPathsAsSeqLinks = [cellOfPathsAsSeqLinks; mat2cell(listOfPathsAsSeqLinks{1,1},ones(size(listOfPathsAsSeqLinks{1,1},1),1))];
    cellOfPathsAsSeqNodes = [cellOfPathsAsSeqNodes; mat2cell(listOfPathsAsSeqNodes{1,1},ones(size(listOfPathsAsSeqNodes{1,1},1),1))];

    % calculate the paths for increasing number of hops
    thereIsMorepaths = 1;
    numTravNodes = 0;
    while thereIsMorepaths == 1, 
        numTravNodes = numTravNodes + 1;   
        listOfPathsAsSeqLinks{1,1+numTravNodes} = zeros (0,numTravNodes+1); % one row per path = seq of traversed links 
        listOfPathsAsSeqNodes{1,1+numTravNodes} = zeros (0,numTravNodes+2); % one row per path = seq of traversed nodes 

        pathsOfOneHopLessAsSeqLinks = listOfPathsAsSeqLinks{1,numTravNodes};
        pathsOfOneHopLessAsSeqNodes = listOfPathsAsSeqNodes{1,numTravNodes};

        numberPathsOneHopLess = size(pathsOfOneHopLessAsSeqLinks,1);
        for idPathToExtend=1:numberPathsOneHopLess

            pathToExtendAsSequenceOfLinks = pathsOfOneHopLessAsSeqLinks (idPathToExtend,:);
            pathToExtendAsSequenceOfNodes = pathsOfOneHopLessAsSeqNodes (idPathToExtend,:);
            lastNode = pathToExtendAsSequenceOfNodes(end);
            
            for linkID=outgoingLinksFromNode{lastNode}',
                if (ismember (linkTable(linkID,2) , pathToExtendAsSequenceOfNodes)), continue; end % to avoid cycles (passing twice in the same node)             
                listOfPathsAsSeqLinks{1,1+numTravNodes} = [listOfPathsAsSeqLinks{1,1+numTravNodes} ; pathToExtendAsSequenceOfLinks linkID];
                listOfPathsAsSeqNodes{1,1+numTravNodes} = [listOfPathsAsSeqNodes{1,1+numTravNodes} ; pathToExtendAsSequenceOfNodes linkTable(linkID,2)];
            end
        end
        
        a=listOfPathsAsSeqLinks{1,1+numTravNodes};
        b=linkTable(a,3);
        c=reshape(b,size(a));
        distofpaths=sum(c,2);
        listOfPathsAsSeqLinks{1,1+numTravNodes}=a(distofpaths<maxCPRIreach,:);
        a=listOfPathsAsSeqNodes{1,1+numTravNodes};
        listOfPathsAsSeqNodes{1,1+numTravNodes}=a(distofpaths<maxCPRIreach,:);
    
        cellOfPathsAsSeqLinks = [cellOfPathsAsSeqLinks; mat2cell(listOfPathsAsSeqLinks{1,1+numTravNodes}, ones(size(listOfPathsAsSeqLinks{1,1+numTravNodes} ,1),1))];
        cellOfPathsAsSeqNodes = [cellOfPathsAsSeqNodes; mat2cell(listOfPathsAsSeqNodes{1,1+numTravNodes}, ones(size(listOfPathsAsSeqNodes{1,1+numTravNodes} ,1),1))];

        if size(listOfPathsAsSeqLinks{1,1+numTravNodes}, 1) == 0 , thereIsMorepaths = 0; end %stop criterion
    end
    
    cellOfPaths = cell(length(cellOfPathsAsSeqLinks),2);    
    cellOfPaths(:,1) = cellOfPathsAsSeqLinks;
    cellOfPaths(:,2) = cellOfPathsAsSeqNodes;
    pathInfo = path_cell2struct (linkTable, cellOfPaths, loopback_paths);
end

function pathInfo = path_cell2struct (linkTable, cellOfPaths, loopback_paths)

    L = size (linkTable , 1);
    N = max(max(linkTable));
    P = length(cellOfPaths);
    
   % pathInfo = struct('P',P, 'bin_nodePairs',sparse(N^2,P) ,'bin_initNodes',sparse(N,P), 'bin_endNodes',sparse(N,P), 'bin_nodesInPath', sparse(N,P), 'bin_edgesInPath', sparse(L,P));        
    bin_nodePairs = sparse(N^2,P);
    bin_initNodes = sparse(N,P);
    bin_endNodes = sparse(N,P);
    bin_nodesInPath = sparse(N,P);
    bin_edgesInPath = sparse(L,P);
                
    for pId=1:P,
        sequenceOfLinkIdsPath = cellOfPaths{pId,1};
        sequenceOfNodeIdsPath = cellOfPaths{pId,2};
        path_initNode = linkTable(sequenceOfLinkIdsPath(1),1);
        path_endNode = linkTable(sequenceOfLinkIdsPath(end),2);
%         pId
%         path_initNode
%         path_endNode
%         sequenceOfLinkIdsPath
%         sequenceOfNodeIdsPath
%         pause    
        if (path_initNode ~= sequenceOfNodeIdsPath(1))
            error('path_initNode ~= sequenceOfNodeIdsPath(1)')
        end
        if (path_endNode ~= sequenceOfNodeIdsPath(end))
            error('path_endNode ~= sequenceOfNodeIdsPath(end)')
        end
        bin_nodePairs((path_initNode-1)*N + path_endNode ,pId)=1;
        bin_initNodes(path_initNode,pId)=1;
        bin_endNodes(path_endNode,pId)=1;
        bin_nodesInPath(sequenceOfNodeIdsPath,pId)=1;
        bin_edgesInPath(sequenceOfLinkIdsPath,pId)=1;
%         pathInfo.bin_edgesInPath(:,pId)
%         pause
    end
    
    % We add the N "virtual" paths before the "real" paths.
    % A virtual path is a path coming out from and going into the same
    % node, that is, a local looppack path. We consider that such a path does not
    % traverse any link at the link table.

    if loopback_paths,
        loopback_bin_nodePairs = sparse(N^2,N);
        loopback_bin_nodePairs(sub2ind([N^2 N], 1:N+1:N^2, 1:N)) = 1;
        loopback_bin_initNodes = speye(N); 
        loopback_bin_endNodes = speye(N); 
        loopback_bin_nodesInPath = speye(N);
        loopback_bin_edgesInPath = sparse(L,N);

        pathInfo.P = N+P;
        pathInfo.bin_nodePairs = [loopback_bin_nodePairs bin_nodePairs];
        pathInfo.bin_initNodes = [loopback_bin_initNodes bin_initNodes];
        pathInfo.bin_endNodes = [loopback_bin_endNodes bin_endNodes];
        pathInfo.bin_nodesInPath = [loopback_bin_nodesInPath bin_nodesInPath];
        pathInfo.bin_edgesInPath = [loopback_bin_edgesInPath bin_edgesInPath];         

    else
        pathInfo.P = P;
        pathInfo.bin_nodePairs = bin_nodePairs;
        pathInfo.bin_initNodes = bin_initNodes;
        pathInfo.bin_endNodes = bin_endNodes;
        pathInfo.bin_nodesInPath =bin_nodesInPath;
        pathInfo.bin_edgesInPath =bin_edgesInPath;  
    end
end
