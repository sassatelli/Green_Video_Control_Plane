function Generate_topology_traffic(...
    topology_name,nbof_contentpercatalog,nbof_catalog,load,totalrequests)

%-- sizes ---
%-- topology_name = 'FMC_tree' or 'FMC_ringandspur' or 'Mobile_backhaul'
%-- CPRI_linkTable: nb of CPRI links x 2
%-- pathInfo: struct from topology generation
%-- nbof_mobendnodes, nbof_fixedendnodes: scalars
%-- alpha, bmin, bmax: nbof_videotype x nbof_resol
%-- d_tc: 2 x nbof_resol x nbof_type (2 because only 1080 and 4K in cache possibly)
%-- vems: sparse vector of full length nbof_endnodes x nbof_content2 xnbof_resol (nbof_content2 is the number of contents when the 4K requests have been assigned another id)
%-- mat_content: 5 x nbof_content2 (row1: m, row2: type, row3: duration, row4: size; row5: flag4K)
%-- mat_trace: totalrequests x 8 (columns: timestamp|e|m|s|type|siz|watchingdur|bwlasthop)
%-- -
catalog_share=0.8;
[WDM_linkTable, CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes, nodeTable]=Get_topology(topology_name);
[alpha,bmin,bmax,d_tc,vems,wdems,mat_content,mat_trace]=Get_traffic(nbof_mobendnodes,nbof_fixedendnodes,nbof_contentpercatalog,load,totalrequests,nbof_catalog,catalog_share);
[infrastructuredata]=Get_Infrastructure(CPRI_linkTable,pathInfo,nbof_mobendnodes,nbof_fixedendnodes);

topologydata=struct();
topologydata.WDM_linkTable = WDM_linkTable;
topologydata.CPRI_linkTable=CPRI_linkTable;
topologydata.pathInfo=pathInfo;
topologydata.nbof_mobendnodes=nbof_mobendnodes;
topologydata.nbof_fixedendnodes=nbof_fixedendnodes;
topologydata.nodeTable = nodeTable;
videodata=struct();
videodata.load=load;
videodata.alpha=alpha;
videodata.bmin=bmin;
videodata.bmax=bmax;
videodata.d_tc=d_tc;
videodata.vems=vems;
videodata.wdems=wdems;
videodata.mat_content=mat_content;
videodata.mat_trace=mat_trace;
beta=0.5;
videodata.beta=beta;

%background traffic
N = size(pathInfo.bin_nodesInPath,1);
backgroundTraff = sparse(N,1);

filename=['../simpoints/topo_traffic_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_L',num2str(load),'_TR',num2str(totalrequests),'.mat'];
save(filename,'topologydata','videodata','infrastructuredata','backgroundTraff');


