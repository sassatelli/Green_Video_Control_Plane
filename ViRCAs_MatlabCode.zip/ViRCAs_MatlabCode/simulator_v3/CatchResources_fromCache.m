function [bwserved,budget_link,budget_PoP_ir,queue_activereq,CPUload_pernode]=CatchResources_fromCache(budg_fromcache,bwlasthop,bmax,budget_link,...
    budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr,queue_activereq,watchingdur,ir,e,s,CPUload_pernode,d_VTC,preload_time,...
    m,type,mtrue,flag_servedas_unk)

%-- Catch bw resources cache->end node
bwserved=min([budg_fromcache,bwlasthop,bmax]);
[budget_link,budget_PoP_ir]=UpdateBudgetonCatch(budget_link,budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr);
%----
%-- Enqueue the request in the queue of active requests
queue_activereq=[queue_activereq,[max(watchingdur*60,preload_time);bwserved;ir;e;pr;s;m;type;mtrue;flag_servedas_unk]];
%----
%-- Catch CPU resources
CPUload_pernode(ir)=CPUload_pernode(ir)+d_VTC(1+(s>3),s,type);
%----