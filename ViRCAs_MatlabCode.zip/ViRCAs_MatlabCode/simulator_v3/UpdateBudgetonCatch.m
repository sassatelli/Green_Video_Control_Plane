function [budget_link,budget_PoP_ir]=UpdateBudgetonCatch(budget_link,budget_PoP_ir,bwserved,...
    linkIPpath_table,srcIPpath_table,pr)

%-- from the IP path utilized for that much bw (bwserved), updates bugets from PoP and from each cache

budget_link(logical(linkIPpath_table(pr,:)))=budget_link(logical(linkIPpath_table(pr,:)))-bwserved;
budg_linksofpath=linkIPpath_table.*repmat(budget_link,size(linkIPpath_table,1),1);
%-- update budget from PoP --
PoP=1;
ind_pathsfromPoP=logical(srcIPpath_table(:,PoP));
bw_tmp=1e4*ones(size(linkIPpath_table));
bw_tmp(logical(linkIPpath_table))=budg_linksofpath(logical(linkIPpath_table));
bw_perpath=sparse(min(bw_tmp,[],2));
budget_PoP_ir(ind_pathsfromPoP)=bw_perpath(ind_pathsfromPoP);
%--
