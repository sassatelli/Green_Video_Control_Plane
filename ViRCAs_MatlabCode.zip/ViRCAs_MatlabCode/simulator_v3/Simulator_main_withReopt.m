function [array_usedbudgets,array_QoE,array_CPU_load,array_optimoutput]=Simulator_main_withReopt(topo_traffic_filename,...
    T_sample,T_reconfInfra,T_reconfRoutCach,T_optimini,gamma,beta,max_ems_p,flag_compresscatalog,full_model,partial_model,model)

load(['../simpoints/' topo_traffic_filename]); %--> topologydata, videodata and infrastructuredata
videodata.beta=beta;
trafload=videodata.load; alpha=videodata.alpha; bmin_ms=videodata.bmin; bmax_ms=videodata.bmax; d_VTC=videodata.d_tc; 
mat_trace=videodata.mat_trace(1:end,:);%% timestamp|e|m|s|type|siz|watchingdur|bwlasthop
nbof_resol=size(alpha,2); trace_time=mat_trace(:,1); trace_endnode=mat_trace(:,2); trace_contentID=mat_trace(:,3);
trace_resol=mat_trace(:,4); trace_type=mat_trace(:,5); trace_siz=mat_trace(:,6); trace_watchingdur=mat_trace(:,7); trace_bwlasthop=mat_trace(:,8);

%--- Nodes numbering from Get_topology: PoP | intermediate nodes | fixed end nodes | mobile end nodes

nbof_mobendnodes=topologydata.nbof_mobendnodes;
nbof_fixedendnodes=topologydata.nbof_fixedendnodes;
nbof_endnodes=nbof_mobendnodes+nbof_fixedendnodes;
nbof_nodes=size(topologydata.pathInfo.bin_initNodes,1);
nbof_IPpaths=topologydata.pathInfo.P;
srcIPpath_table=topologydata.pathInfo.bin_initNodes; srcIPpath_table=srcIPpath_table';
dstIPpath_table=topologydata.pathInfo.bin_endNodes; dstIPpath_table=dstIPpath_table';
linkIPpath_table=topologydata.pathInfo.bin_edgesInPath; linkIPpath_table=linkIPpath_table';
nbof_links=size(linkIPpath_table,2);

%---- Set additional parameters
inital_buf=15/60; % 15s, in min
bgtraffic=backgroundTraff;
vec_cacheSizes=infrastructuredata.nodeStorage;
capa_perlink=infrastructuredata.WDMcap*ones(1,nbof_links);
nbof_CPUspernode=infrastructuredata.K*infrastructuredata.G_n;
%-----

%--- Solve optim and get relevant quantities----
current_time=0;
ind1=find(trace_time>current_time); ind1=ind1(1); ind2=find(trace_time>=current_time+T_optimini); if isempty(ind2), ind2=length(trace_time); else, ind2=ind2(1); end;
%-- Create content for optim (clustering seen content)
videodata_foroptim=make_videodataforoptim(topologydata,videodata,infrastructuredata,flag_compresscatalog,max_ems_p,ind1,ind2);
%vems=videodata_foroptim.vems; mat_content=videodata_foroptim.mat_content; 
nbof_content=size(videodata_foroptim.mat_content,2);
[gamma_central,maxpower,maxQoE]=get_gammacentral(topo_traffic_filename,model,videodata_foroptim);
gamma.value=gamma.factor*gamma_central;
[ViRCA_sol, ViRCA_slack] =full_model(topologydata,videodata_foroptim,infrastructuredata,gamma.value); %backgroundTraff
start_RCA_sol = [];
RCA_prevSlack = ViRCA_slack;
feasible=ismember(ViRCA_sol.statusnum,[101 102 105 107]);
lastobj=ViRCA_sol.obj;
f_emsi=sparse(ViRCA_sol.f_emsi);
vf_eusi=sparse(ViRCA_sol.vf_eusi);
x_ems_p=sparse(ViRCA_sol.x_ems_p);
x_eus_p=sparse(ViRCA_sol.x_eus_p);
y_p=sparse(ViRCA_sol.y_p);
z_ej=ViRCA_sol.z_ej;
g_egs_i=ViRCA_sol.g_egs_i;
t_bbu_i=ViRCA_sol.t_bbu_i;
t_vtc_i=ViRCA_sol.t_vtc_i;

%clear ViRCA_sol;
ViRCA_sol2=struct();
ViRCA_sol2.power=ViRCA_sol.power; ViRCA_sol2.QoE=ViRCA_sol.QoE;
ViRCA_sol2.g_ipr_i=ViRCA_sol.g_ipr_i; ViRCA_sol2.g_egs_i=g_egs_i; ViRCA_sol2.g_srv_i=ViRCA_sol.g_srv_i; 
ViRCA_sol2.t_bbu_i=ViRCA_sol.t_bbu_i; ViRCA_sol2.t_vtc_i=ViRCA_sol.t_vtc_i; ViRCA_sol2.z_ej=ViRCA_sol.z_ej; 
ViRCA_sol2.z_j=sum(reshape(ViRCA_sol.z_ej,nbof_nodes,nbof_mobendnodes),2);
ViRCA_sol=ViRCA_sol2; clear ViRCA_sol2;

array_g=g_egs_i;
t_bbu_i_former=t_bbu_i;
array_z=reshape(z_ej,nbof_nodes,nbof_mobendnodes);
array_x_p=sparse(reshape(x_ems_p,nbof_IPpaths,nbof_endnodes*nbof_content*nbof_resol));
array_xu_p=sparse(reshape(x_eus_p,nbof_IPpaths,nbof_endnodes*nbof_resol));
array_x_p=merge_unk(array_x_p,array_xu_p,nbof_IPpaths,nbof_endnodes,nbof_content,nbof_resol);
clear x_ems_p x_eus_p array_xu_p;
%sol=ViRCA_sol;
%------

%--- Intializing budgets
[budget_path,budget_PoP_ir,capa_perpath,budget_link]=Initialize_budgets(nbof_nodes,nbof_IPpaths,nbof_endnodes,nbof_content,nbof_resol,capa_perlink,nbof_mobendnodes,...
    nbof_fixedendnodes,array_z,array_x_p,y_p,srcIPpath_table,dstIPpath_table,linkIPpath_table,ViRCA_sol.g_ipr_i,topologydata.pathInfo.bin_nodesInPath);
budget_path_initial=budget_path; budget_PoP_ir_initial=budget_PoP_ir;
clear array_x_p y_p;

%-- Queue of active requests
queue_activereq=[]; %row1: time left, row2: bwserved, row3-7: ir,er,pr,strue,m - sorted in ascending order of time left
queue_activefromPoP=[]; %row1: time left, row2: bwserved, row3-4: ir,pr
%-- CPU loads
CPUload_pernode=t_bbu_i'; %zeros(1,nbof_nodes);
%-- Caches' entries
caches_entries=cell(1,nbof_nodes);
for i=1:nbof_nodes, caches_entries{i}=[]; end;   %row1: contentID, row2: C_hit, row3: C_stay, row4: size s_m  - sorted in ascending order of score
%-- Requests rejected
rqst_rejected=sparse(zeros(size(trace_time,1),1));
reason_rej=sparse(zeros(size(trace_time,1),1));
%-- Startup delay
startup_delay=zeros(size(trace_time,1),1);
%-- Record performance metrics
relativerate_served=zeros(size(trace_time,1),1);
array_CPU_load=repmat(t_bbu_i',size(trace_time,1),1);% zeros(size(trace_time,1),nbof_nodes);
array_optimoutput=cell(1,7);
ind_optim=1;
array_usedbudgets=cell(1,2);

% % save optim's output
array_optimoutput{ind_optim,1}=0; array_optimoutput{ind_optim,2}=1;
array_optimoutput{ind_optim,3}=ViRCA_sol.power; array_optimoutput{ind_optim,4}=ViRCA_sol.g_ipr_i; array_optimoutput{ind_optim,5}=ViRCA_sol.g_egs_i;
array_optimoutput{ind_optim,6}=ViRCA_sol.t_bbu_i; array_optimoutput{ind_optim,7}=ViRCA_sol.t_vtc_i;
ind_optim=ind_optim+1;

%--- Variables for re-optimization
%-- to save memory
% maxnbof_ems_overTsample=10*trafload*0.4*nbof_endnodes*T_sample;
% maxnbof_ems_overTreconfInfra=10*trafload*0.4*nbof_endnodes*T_reconfInfra;
%--

vecsamples_CPUload=zeros(ceil(T_reconfInfra/T_sample),nbof_nodes);
vecsamples_vf_monitor=sparse(ceil(T_reconfInfra/T_sample),nbof_nodes*nbof_endnodes*size(videodata_foroptim.mat_content,2)*nbof_resol); % % emsi
vecsamples_vfu_monitor=sparse(ceil(T_reconfInfra/T_sample),nbof_nodes*nbof_endnodes*nbof_resol); % % eusi
time_lastsample=0;
sample_index=1;
indtrace_insample=1;
time_last_infra=0;
time_last_routcach=0;

current_time=0;
ind1=find(trace_time>current_time); if isempty(ind1), ind1=length(trace_time); else, ind1=ind1(1); end;
ind2=find(trace_time>=current_time+T_sample); if isempty(ind2), ind2=length(trace_time); else, ind2=ind2(1); end;
nbof_indinsample=length((ind1:ind2));
array_nbofrqst_pernode=sparse(nbof_indinsample,nbof_nodes*nbof_endnodes*nbof_content*nbof_resol); % % emsi
array_videodur_rejrqst=sparse(nbof_indinsample,nbof_endnodes*nbof_content*nbof_resol); % % ems
array_nbofrqst_pernode_unk=sparse(nbof_indinsample,nbof_nodes*nbof_endnodes*nbof_resol); % % eusi

mindur_toredirect=0;% redirect when cache to be shut down // not used
%----

%--- Parsing the trace
rowtrace_max=size(trace_time,1);
for rowtrace_index=1:rowtrace_max,
    
    current_time=trace_time(rowtrace_index);
    e=trace_endnode(rowtrace_index); mtrue=trace_contentID(rowtrace_index); s=trace_resol(rowtrace_index); type=trace_type(rowtrace_index);
    bwlasthop=trace_bwlasthop(rowtrace_index); watchingdur=trace_watchingdur(rowtrace_index); siz=trace_siz(rowtrace_index); dur=videodata.mat_content(3,mtrue);
    
    vec_rqst=[type;watchingdur;siz;(s>3);e;mtrue];
    if flag_compresscatalog==1, m=find_centroid(videodata_foroptim,vec_rqst); end;
    
    if rowtrace_index>=2,
        laststepduration=current_time-trace_time(rowtrace_index-1);
    end;
    %-- Dequeue the request from the queue of active requests and release the resources
    if size(queue_activereq,2)>0,
        queue_activereq(1,:)=queue_activereq(1,:)-laststepduration;
        [q,ind]=sort(queue_activereq(1,:),'ascend');
        queue_activereq=queue_activereq(:,ind);
        queueoffinished=queue_activereq(:,queue_activereq(1,:)<=0);
        for r=1:size(queueoffinished,2),
            bwserved=queueoffinished(2,r); ir=queueoffinished(3,r); er=queueoffinished(4,r); pr=queueoffinished(5,r); strue=queueoffinished(6,r); type_r=queueoffinished(8,r);
            %-- Release bw resources
            [budget_link,budget_PoP_ir]=UpdateBudgetonRelease(budget_link,budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr);
            %-- Release CPU resources
            CPUload_pernode(ir)=CPUload_pernode(ir)-d_VTC(1+(strue>3),strue,type_r);
        end;
        %-- Dequeue
        queue_activereq=queue_activereq(:,queue_activereq(1,:)>0);
    end;
    %----
    %--- Do the same for transmissions from PoP to caches
    if size(queue_activefromPoP,2)>0,
        queue_activefromPoP(1,:)=queue_activefromPoP(1,:)-laststepduration;
        [q,ind]=sort(queue_activefromPoP(1,:),'ascend');
        queue_activefromPoP=queue_activefromPoP(:,ind);
        queueoffinishedfromPoP=queue_activefromPoP(:,queue_activefromPoP(1,:)<=0);
        for r=1:size(queueoffinishedfromPoP,2),
            bwserved=queueoffinishedfromPoP(2,r); ir=queueoffinishedfromPoP(3,r); pr=queueoffinishedfromPoP(4,r);
            %-- Release bw resources
            [budget_link,budget_PoP_ir]=UpdateBudgetonRelease(budget_link,budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr);
        end;
        %-- Dequeue
        queue_activefromPoP=queue_activefromPoP(:,queue_activefromPoP(1,:)>0);
    end;
    %----
    
    %--- Assign request to resources
    [budget_link,budget_PoP_ir,queue_activefromPoP,caches_entries,queue_activereq,...
        CPUload_pernode,rqst_rejected,reason_rej,startup_delay,relativerate_served,ir,pr]=Accommodate_rsqt(...
        watchingdur,dur,e,s,m,mtrue,type,bwlasthop,siz,...
        d_VTC,nbof_content,nbof_resol,array_z,vec_cacheSizes,...
        bmin_ms,bmax_ms,inital_buf,nbof_fixedendnodes,srcIPpath_table,dstIPpath_table,linkIPpath_table,...
        budget_link,budget_path,budget_PoP_ir,queue_activefromPoP,caches_entries,queue_activereq,CPUload_pernode,...
        rqst_rejected,reason_rej,startup_delay,relativerate_served,rowtrace_index,t_bbu_i,t_vtc_i);
    %----
    
    
    %--- Recording of end metrics and rejected requests
    array_CPU_load(rowtrace_index,:)=CPUload_pernode;
    %array_usedbudgets{rowtrace_index,1}=budget_path_initial-budget_path; array_usedbudgets{rowtrace_index,2}=budget_PoP_ir_initial-budget_PoP_ir;
    %-- Update bw_perpath
    budg_linksofpath=linkIPpath_table.*repmat(budget_link,size(linkIPpath_table,1),1);
    bw_tmp=1e4*ones(size(linkIPpath_table));
    bw_tmp(logical(linkIPpath_table))=budg_linksofpath(logical(linkIPpath_table));
    bw_perpath=sparse(min(bw_tmp,[],2));
    %--
    array_usedbudgets{rowtrace_index,1}=capa_perpath-bw_perpath;
    if ~isempty(ir) && ~isempty(pr),
        array_usedbudgets{rowtrace_index,2}=[ir,pr,e]; %capa_perpath-bw_perpath;
    end;
    
    if rqst_rejected(rowtrace_index)==1,
        ind_ems=(e-1)*nbof_content*nbof_resol+(m-1)*nbof_resol+s;
        array_videodur_rejrqst(indtrace_insample,ind_ems)=watchingdur;
    end;
    
    for activereq_ind=1:size(queue_activereq,2),
        flag_servedas_unk=queue_activereq(10,activereq_ind);
        i=queue_activereq(3,activereq_ind); e=queue_activereq(4,activereq_ind); m=queue_activereq(7,activereq_ind); s=queue_activereq(6,activereq_ind);
        if flag_servedas_unk==0,
            ind_emsi=(e-1)*nbof_content*nbof_resol*nbof_nodes+(m-1)*nbof_resol*nbof_nodes+(s-1)*nbof_nodes+i;
            array_nbofrqst_pernode(indtrace_insample,ind_emsi)=array_nbofrqst_pernode(indtrace_insample,ind_emsi)+1;
        else,
            ind_eusi=(e-1)*nbof_resol*nbof_nodes+(s-1)*nbof_nodes+i;
            array_nbofrqst_pernode_unk(indtrace_insample,ind_eusi)=array_nbofrqst_pernode_unk(indtrace_insample,ind_eusi)+1;
        end;
    end;
    for activereq_ind=1:size(queue_activefromPoP,2),
        flag_fromPoPorrej=queue_activefromPoP(9,activereq_ind); i=queue_activefromPoP(3,activereq_ind);
        if flag_fromPoPorrej==1&&i==1,
            e=queue_activefromPoP(5,activereq_ind); m=queue_activefromPoP(6,activereq_ind); s=queue_activefromPoP(7,activereq_ind);
            ind_emsi=(e-1)*nbof_content*nbof_resol*nbof_nodes+(m-1)*nbof_resol*nbof_nodes+(s-1)*nbof_nodes+i;
            array_nbofrqst_pernode(indtrace_insample,ind_emsi)=array_nbofrqst_pernode(indtrace_insample,ind_emsi)+1;
        end;
    end;
    %----
    
    %--- Update samples to decide re-opt
    if current_time>=time_lastsample+T_sample,
        indtrace=find(trace_time(1:rowtrace_index)>=time_lastsample);
        steps=trace_time(indtrace(2:end))-trace_time(indtrace(1:end-1));
        indtrace=indtrace(1:end-1);
        vecsamples_CPUload(sample_index,:)=(array_CPU_load(indtrace,:)'*steps)'/sum(steps);
        
        array_nbofrqst_pernode=array_nbofrqst_pernode(1:length(indtrace),:);
        array_videodur_rejrqst=array_videodur_rejrqst(1:length(indtrace),:);
        array_nbofrqst_pernode_unk=array_nbofrqst_pernode_unk(1:length(indtrace),:);
        
        vecsamples_vf_monitor(sample_index,:)=(array_nbofrqst_pernode'*steps/sum(steps))';
        onnodes=(array_g>0);
        vecsamples_vf_monitor(sample_index,:)=vecsamples_vf_monitor(sample_index,:)+...
            kron(min(sum(array_videodur_rejrqst,1),sum(steps))/sum(onnodes),onnodes');
        
        vecsamples_vfu_monitor(sample_index,:)=(array_nbofrqst_pernode_unk'*steps/sum(steps))';
        
        %-- re-initializing variables for in-sample counting
        ind1=find(trace_time>=current_time); ind2=find(trace_time>=current_time+T_sample);
        if isempty(ind1),
            ind1=length(trace_time); ind2=ind1;
        elseif isempty(ind2),
            ind2=length(trace_time);
        else,
            ind1=ind1(1); ind2=ind2(1);
        end;
        nbof_indinsample=length((ind1:ind2));
        array_nbofrqst_pernode=sparse(zeros(nbof_indinsample,nbof_nodes*nbof_endnodes*size(videodata_foroptim.mat_content,2)*nbof_resol)); % % emsi
        array_videodur_rejrqst=sparse(zeros(nbof_indinsample,nbof_endnodes*size(videodata_foroptim.mat_content,2)*nbof_resol)); % % ems
        array_nbofrqst_pernode_unk=sparse(zeros(nbof_indinsample,nbof_nodes*nbof_endnodes*nbof_resol)); % % eusi
        %--
        
        indtrace_insample=1;
        sample_index=sample_index+1;
        time_lastsample=current_time;
    else,
        indtrace_insample=indtrace_insample+1;
    end;
    %----
    
    %--- Possible triggering or re-opt infra (to save energy)
    flag_reopt_infra=0; flag_reopt_routcachonly=0; feasible=1;
    if current_time>=time_last_infra+T_reconfInfra,
        maxCPUload=max(sum(vecsamples_CPUload,2));
        onnodes=(array_g>0);
        if maxCPUload<=sum(t_bbu_i)+sum(t_vtc_i)-nbof_CPUspernode(1), % downscale resources
            flag_reopt_infra=1;
            t_bbu_i_former=t_bbu_i;
            %--- Solve optim and get relevant quantities----
            disp('Entering reopt ViRCA');
            time_lastopt=current_time-T_reconfInfra;
            ind1=find(trace_time>time_lastopt); ind1=ind1(1); ind2=rowtrace_index;
            videodata_foroptim=make_videodataforoptim(topologydata,videodata,infrastructuredata,flag_compresscatalog,max_ems_p,ind1,ind2);
            nbof_content=size(videodata_foroptim.mat_content,2);
            [gamma_central,maxpower,maxQoE]=get_gammacentral(topo_traffic_filename,model,videodata_foroptim);
            gamma.value=gamma.factor*gamma_central;
            [ViRCA_sol, ViRCA_slack] =full_model(topologydata,videodata_foroptim,infrastructuredata,gamma.value);
            start_RCA_sol = [];
            RCA_prevSlack = ViRCA_slack;
            feasible=ismember(ViRCA_sol.statusnum,[101 102 105 107]);
            lastobj=ViRCA_sol.obj;
            f_emsi=sparse(ViRCA_sol.f_emsi);
            vf_eusi=sparse(ViRCA_sol.vf_eusi);
            x_ems_p=sparse(ViRCA_sol.x_ems_p);
            x_eus_p=sparse(ViRCA_sol.x_eus_p);
            y_p=sparse(ViRCA_sol.y_p);
            z_ej=ViRCA_sol.z_ej;
            g_egs_i=ViRCA_sol.g_egs_i;
            t_bbu_i=ViRCA_sol.t_bbu_i;
            t_vtc_i=ViRCA_sol.t_vtc_i;
            %clear ViRCA_sol;
            %-- Store the optim's output
            array_optimoutput{ind_optim,1}=current_time; array_optimoutput{ind_optim,2}=rowtrace_index;
            array_optimoutput{ind_optim,3}=ViRCA_sol.power; array_optimoutput{ind_optim,4}=ViRCA_sol.g_ipr_i; array_optimoutput{ind_optim,5}=ViRCA_sol.g_egs_i;
            array_optimoutput{ind_optim,6}=ViRCA_sol.t_bbu_i; array_optimoutput{ind_optim,7}=ViRCA_sol.t_vtc_i;
            ind_optim=ind_optim+1;
            ViRCA_sol2=struct();
            ViRCA_sol.power=ViRCA_sol.power; ViRCA_sol.QoE=ViRCA_sol.QoE;
            ViRCA_sol2.g_ipr_i=ViRCA_sol.g_ipr_i; ViRCA_sol2.g_egs_i=g_egs_i; ViRCA_sol2.g_srv_i=ViRCA_sol.g_srv_i;
            ViRCA_sol2.t_bbu_i=ViRCA_sol.t_bbu_i; ViRCA_sol2.t_vtc_i=ViRCA_sol.t_vtc_i; ViRCA_sol2.z_ej=ViRCA_sol.z_ej;
            ViRCA_sol2.z_j=sum(reshape(ViRCA_sol.z_ej,nbof_nodes,nbof_mobendnodes),2);
            ViRCA_sol=ViRCA_sol2; clear ViRCA_sol2;
            
            array_g=g_egs_i;
            array_z=reshape(z_ej,nbof_nodes,nbof_mobendnodes);
            array_x_p=sparse(reshape(x_ems_p,nbof_IPpaths,nbof_endnodes*nbof_content*nbof_resol));
            array_xu_p=sparse(reshape(x_eus_p,nbof_IPpaths,nbof_endnodes*nbof_resol));
            array_x_p=merge_unk(array_x_p,array_xu_p,nbof_IPpaths,nbof_endnodes,nbof_content,nbof_resol);
            clear x_ems_p x_eus_p array_xu_p;
            %------
            
        end;
        vecsamples_vf_monitor=sparse(ceil(max(T_reconfInfra,T_reconfRoutCach)/T_sample),nbof_nodes*nbof_endnodes*size(videodata_foroptim.mat_content,2)*nbof_resol); % % emsi
        %-- re-initializing variables for in-sample counting
        ind1=find(trace_time>=current_time); ind2=find(trace_time>=current_time+T_sample);
        if isempty(ind1),
            ind1=length(trace_time); ind2=ind1;
        elseif isempty(ind2),
            ind2=length(trace_time);
        else,
            ind1=ind1(1); ind2=ind2(1);
        end;
        nbof_indinsample=length((ind1:ind2));
        array_nbofrqst_pernode=sparse(zeros(nbof_indinsample,nbof_nodes*nbof_endnodes*size(videodata_foroptim.mat_content,2)*nbof_resol)); % % emsi
        array_videodur_rejrqst=sparse(zeros(nbof_indinsample,nbof_endnodes*size(videodata_foroptim.mat_content,2)*nbof_resol)); % % ems
        array_nbofrqst_pernode_unk=sparse(zeros(nbof_indinsample,nbof_nodes*nbof_endnodes*nbof_resol)); % % eusi
        %--
        
        indtrace_insample=1;
        sample_index=1;
        time_last_infra=current_time;
        time_lastsample=current_time;
        %--- Possible triggering or re-opt routing-caching
    elseif current_time>=time_last_routcach+T_reconfRoutCach,
        maxvf_monitor=max(vecsamples_vf_monitor,[],1); % emsi
        maxvfu_monitor=max(vecsamples_vfu_monitor,[],1); % eusi
        measures_delta.vf_emsi = maxvf_monitor' - kron(videodata_foroptim.vems',ones(nbof_nodes,1)).*f_emsi;
        measures_delta.vf_eusi=maxvfu_monitor'- vf_eusi;
        
        %--- Solve optim and get relevant quantities----
        disp('Entering reopt RCA');
        time_lastopt=current_time-T_reconfRoutCach;%max(time_last_routcach,time_last_infra);
        ind1=find(trace_time>time_lastopt); ind1=ind1(1); ind2=rowtrace_index;
        videodata_foroptim_tmp=make_videodataforoptim(topologydata,videodata,infrastructuredata,flag_compresscatalog,max_ems_p,ind1,ind2);
        [RCA_sol, RCA_slack,reoptimFlag] = partial_model(ViRCA_sol,topologydata,videodata_foroptim_tmp,videodata_foroptim,infrastructuredata, start_RCA_sol, RCA_prevSlack, measures_delta);
        
        flag_reopt_routcachonly=reoptimFlag;
        if reoptimFlag,
            videodata_foroptim=videodata_foroptim_tmp;
            nbof_content=size(videodata_foroptim.mat_content,2);
            start_RCA_sol = RCA_sol;
            RCA_prevSlack = RCA_slack;
            feasible=ismember(RCA_sol.statusnum,[1]);
            if feasible==1,
                [gamma_central,maxpower,maxQoE]=get_gammacentral(topo_traffic_filename,model,videodata_foroptim_tmp);
                QoEnotmet=(RCA_sol.obj/maxQoE<0.8);
                if QoEnotmet,
                    feasible=0;
                end;
                lastobj=RCA_sol.obj;
                f_emsi=sparse(RCA_sol.f_emsi);
                vf_eusi=sparse(RCA_sol.vf_eusi);
                x_ems_p=sparse(RCA_sol.x_ems_p);
                x_eus_p=sparse(RCA_sol.x_eus_p);
                y_p=sparse(RCA_sol.y_p);
                clear RCA_sol;
                
                array_x_p=sparse(reshape(x_ems_p,nbof_IPpaths,nbof_endnodes*nbof_content*nbof_resol));
                array_xu_p=sparse(reshape(x_eus_p,nbof_IPpaths,nbof_endnodes*nbof_resol));
                array_x_p=merge_unk(array_x_p,array_xu_p,nbof_IPpaths,nbof_endnodes,nbof_content,nbof_resol);
                clear x_ems_p x_eus_p array_xu_p;
                % sol=RCA_sol;
            end;
            clear videodata_foroptim_tmp;
        end;
        %------
        if feasible==0,
            flag_reopt_infra=1;
            array_g_former=array_g;
            t_bbu_i_former=t_bbu_i;
            %--- Solve optim and get relevant quantities----
            disp('Entering reopt ViRCA because RCA failed');
            [gamma_central,maxpower,maxQoE]=get_gammacentral(topo_traffic_filename,model,videodata_foroptim);
            gamma.value=gamma.factor*gamma_central;
            [ViRCA_sol, ViRCA_slack] =full_model(topologydata,videodata_foroptim,infrastructuredata, gamma.value);
            start_RCA_sol = [];
            RCA_prevSlack = ViRCA_slack;
            feasible=ismember(ViRCA_sol.statusnum,[101 102 105 107]);
            lastobj=ViRCA_sol.obj;
            f_emsi=sparse(ViRCA_sol.f_emsi);
            vf_eusi=sparse(ViRCA_sol.vf_eusi);
            x_ems_p=sparse(ViRCA_sol.x_ems_p);
            x_eus_p=sparse(ViRCA_sol.x_eus_p);
            y_p=sparse(ViRCA_sol.y_p);
            z_ej=ViRCA_sol.z_ej;
            g_egs_i=ViRCA_sol.g_egs_i;
            t_bbu_i=ViRCA_sol.t_bbu_i;
            t_vtc_i=ViRCA_sol.t_vtc_i;
            %clear ViRCA_sol;
            %-- Store the optim's output
            array_optimoutput{ind_optim,1}=current_time; array_optimoutput{ind_optim,2}=rowtrace_index;
            array_optimoutput{ind_optim,3}=ViRCA_sol.power; array_optimoutput{ind_optim,4}=ViRCA_sol.g_ipr_i; array_optimoutput{ind_optim,5}=ViRCA_sol.g_egs_i;
            array_optimoutput{ind_optim,6}=ViRCA_sol.t_bbu_i; array_optimoutput{ind_optim,7}=ViRCA_sol.t_vtc_i;
            ind_optim=ind_optim+1;
            ViRCA_sol2=struct();
            ViRCA_sol.power=ViRCA_sol.power; ViRCA_sol.QoE=ViRCA_sol.QoE;
            ViRCA_sol2.g_ipr_i=ViRCA_sol.g_ipr_i; ViRCA_sol2.g_egs_i=g_egs_i; ViRCA_sol2.g_srv_i=ViRCA_sol.g_srv_i;
            ViRCA_sol2.t_bbu_i=ViRCA_sol.t_bbu_i; ViRCA_sol2.t_vtc_i=ViRCA_sol.t_vtc_i; ViRCA_sol2.z_ej=ViRCA_sol.z_ej;
            ViRCA_sol2.z_j=sum(reshape(ViRCA_sol.z_ej,nbof_nodes,nbof_mobendnodes),2);
            ViRCA_sol=ViRCA_sol2; clear ViRCA_sol2;

            array_g=g_egs_i;
            array_z=reshape(z_ej,nbof_nodes,nbof_mobendnodes);
            array_x_p=sparse(reshape(x_ems_p,nbof_IPpaths,nbof_endnodes*nbof_content*nbof_resol));
            array_xu_p=sparse(reshape(x_eus_p,nbof_IPpaths,nbof_endnodes*nbof_resol));
            array_x_p=merge_unk(array_x_p,array_xu_p,nbof_IPpaths,nbof_endnodes,nbof_content,nbof_resol);
            clear x_ems_p x_eus_p array_xu_p;
            % sol=ViRCA_sol;
        end;
        
        if feasible==0,
            error('Last ViRCA infeasible: program paused for debug');
            pause
        end;
        vecsamples_vf_monitor=sparse(ceil(max(T_reconfInfra,T_reconfRoutCach)/T_sample),nbof_nodes*nbof_endnodes*size(videodata_foroptim.mat_content,2)*nbof_resol); % % emsi
        %-- re-initializing variables for in-sample counting
        ind1=find(trace_time>=current_time); ind2=find(trace_time>=current_time+T_sample);
        if isempty(ind1),
            ind1=length(trace_time); ind2=ind1;
        elseif isempty(ind2),
            ind2=length(trace_time);
        else,
            ind1=ind1(1); ind2=ind2(1);
        end;
        nbof_indinsample=length((ind1:ind2));
        array_nbofrqst_pernode=sparse(zeros(nbof_indinsample,nbof_nodes*nbof_endnodes*size(videodata_foroptim.mat_content,2)*nbof_resol)); % % emsi
        array_videodur_rejrqst=sparse(zeros(nbof_indinsample,nbof_endnodes*size(videodata_foroptim.mat_content,2)*nbof_resol)); % % ems
        array_nbofrqst_pernode_unk=sparse(zeros(nbof_indinsample,nbof_nodes*nbof_endnodes*nbof_resol)); % % eusi
        %--
        
        indtrace_insample=1;
        sample_index=1;
        time_last_routcach=current_time;
        time_lastsample=current_time;
    end;
    %----
    
    %--- States' updates after re-optimization
    
    if flag_reopt_routcachonly==1||flag_reopt_infra==1,
        
        %-- Intialize and update budgets
        [budget_path,budget_PoP_ir,capa_perpath,budget_link]=Initialize_budgets(nbof_nodes,nbof_IPpaths,nbof_endnodes,nbof_content,nbof_resol,capa_perlink,nbof_mobendnodes,...
            nbof_fixedendnodes,array_z,array_x_p,y_p,srcIPpath_table,dstIPpath_table,linkIPpath_table,ViRCA_sol.g_ipr_i,topologydata.pathInfo.bin_nodesInPath);
        budget_path_initial=budget_path; budget_PoP_ir_initial=budget_PoP_ir;
        clear array_x_p;
        
        usedbw_perpath=array_usedbudgets{rowtrace_index,1};
        CPUload_pernode=CPUload_pernode-t_bbu_i_former'+t_bbu_i';
        
        %-- If for at least 1 path, the used bugdet exceeds the available budget: re-route all requests - includes the case when a node shuts down
        if sum(usedbw_perpath(nbof_nodes+1:nbof_IPpaths)>capa_perpath(nbof_nodes+1:nbof_IPpaths)),
            queue_activereq_old=queue_activereq;
            %-- Remove from queue
            queue_activereq=[];
            queue_activefromPoP=[];
            CPUload_pernode=t_bbu_i';
            %-- Add in queue by re-assigning the rqst to resources
            for r=1:size(queue_activereq_old,2),
                watchingdur=queue_activereq_old(1,r); e=queue_activereq_old(4,r); s=queue_activereq_old(6,r); m=queue_activereq_old(7,r);
                type=queue_activereq_old(8,r); bwlasthop=queue_activereq_old(2,r); 
                mtrue=queue_activereq_old(9,r);
                siz=videodata.mat_content(4,mtrue); dur=videodata.mat_content(3,mtrue);
                vec_rqst=[type;watchingdur;siz;(s>3);e;mtrue];
                if flag_compresscatalog==1, m=find_centroid(videodata_foroptim,vec_rqst); end;
                [budget_link,budget_PoP_ir,queue_activefromPoP,caches_entries,queue_activereq,CPUload_pernode,...
                    rqst_rejected2,reason_rej2,startup_delay2,relativerate_served2,ir,pr]=Accommodate_rsqt(...
                    watchingdur,dur,e,s,m,mtrue,type,bwlasthop,siz,...
                    d_VTC,nbof_content,nbof_resol,array_z,vec_cacheSizes,...
                    bmin_ms,bmax_ms,inital_buf,nbof_fixedendnodes,srcIPpath_table,dstIPpath_table,linkIPpath_table,...
                    budget_link,budget_path,budget_PoP_ir,queue_activefromPoP,caches_entries,queue_activereq,CPUload_pernode,...
                    rqst_rejected,reason_rej,startup_delay,relativerate_served,rowtrace_index,t_bbu_i,t_vtc_i);
            end;
            %-- We free the used bw from the PoP because we do not handle
            %the changes of configuration
            queueoffinishedfromPoP=queue_activefromPoP;
            for r=1:size(queueoffinishedfromPoP,2),
                bwserved=queueoffinishedfromPoP(2,r); ir=queueoffinishedfromPoP(3,r); pr=queueoffinishedfromPoP(4,r);
                %-- Release bw resources
                [budget_link,budget_PoP_ir]=UpdateBudgetonRelease(budget_link,budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr);
            end;
            %-- Dequeue
            queue_activefromPoP=[];
        else,
            CPUload_pernode=t_bbu_i';
            %-- Re-catch resources after initialize above
            for activereq_ind=1:size(queue_activereq,2),
                watchingdur=queue_activereq(1,activereq_ind); bwserved=queue_activereq(2,activereq_ind); 
                ir=queue_activereq(3,activereq_ind); er=queue_activereq(4,activereq_ind); pr=queue_activereq(5,activereq_ind);
                s=queue_activereq(6,activereq_ind); mr=queue_activereq(7,activereq_ind); type_r=queue_activereq(8,activereq_ind);
                mtrue=queue_activereq(9,activereq_ind);
                siz=videodata.mat_content(4,mtrue); dur=videodata.mat_content(3,mtrue);
                vec_rqst=[type_r;watchingdur;siz;(s>3);er;mtrue];
                if flag_compresscatalog==1, m=find_centroid(videodata_foroptim,vec_rqst); end;
                queue_activereq(7,activereq_ind)=m;
                %-- Catch bw resources
                [budget_link,budget_PoP_ir]=UpdateBudgetonCatch(budget_link,budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr);
                CPUload_pernode(ir)=CPUload_pernode(ir)+d_VTC(1+(strue>3),strue,type_r);
                %-- CPU resources already caught
            end;
            for activereq_ind=1:size(queue_activefromPoP,2),
                bwserved=queue_activefromPoP(2,activereq_ind); ir=queue_activefromPoP(3,activereq_ind); pr=queue_activefromPoP(4,activereq_ind);
                %-- Release bw resources
                [budget_link,budget_PoP_ir]=UpdateBudgetonCatch(budget_link,budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr);
            end;
            
        end;
    end;
    %----
end;
%----
array_QoE=[rqst_rejected,startup_delay,relativerate_served,reason_rej];

end

function [budget_link,budget_PoP_ir,queue_activefromPoP,caches_entries,queue_activereq,CPUload_pernode,...
    rqst_rejected,reason_rej,startup_delay,relativerate_served,ir,pr]=Accommodate_rsqt(...
    watchingdur,dur,e,s,m,mtrue,type,bwlasthop,siz,...
    d_VTC,nbof_content,nbof_resol,array_z,vec_cacheSizes,...
    bmin_ms,bmax_ms,inital_buf,nbof_fixedendnodes,srcIPpath_table,dstIPpath_table,linkIPpath_table,...
    budget_link,budget_path,budget_PoP_ir,queue_activefromPoP,caches_entries,queue_activereq,CPUload_pernode,...
    rqst_rejected,reason_rej,startup_delay,relativerate_served,rowtrace_index,t_bbu_i,t_vtc_i)

nbof_nodes=size(srcIPpath_table,2);
nbof_endnodes=size(array_z,2)+nbof_fixedendnodes;
%-- Update bw_perpath
budg_linksofpath=linkIPpath_table.*repmat(budget_link,size(linkIPpath_table,1),1);
bw_tmp=1e4*ones(size(linkIPpath_table));
bw_tmp(logical(linkIPpath_table))=budg_linksofpath(logical(linkIPpath_table));
bw_perpath=sparse(min(bw_tmp,[],2));
%--
%-- Select serving node and path: select first with budget ems>bmax then bmin; if
%doesn't exist, then select the first with total budget>bmax then bmin
PoP=1; ir=[]; pr=[];
flag_fromPoPorrej=0; flag_servedas_unk=0;
ind_ems=(e-1)*(nbof_content+1)*nbof_resol+(m-1)*nbof_resol+s;
%size(budget_path), ind_ems, size(bw_perpath), min(bmax_ms(type,s),bwlasthop)
%ind_ems
candidate_paths=find((budget_path(:,ind_ems)>0)&(bw_perpath>=min(bmax_ms(type,s),bwlasthop)));
CPU_ir_free=1;
if ~isempty(candidate_paths),
    CPU_ir_free=0; cp_ind=1;
    while CPU_ir_free==0&&cp_ind<=length(candidate_paths),
        pr=candidate_paths(cp_ind);
        ir=find(srcIPpath_table(pr,:)==1);
        if CPUload_pernode(ir)-t_bbu_i(ir)<t_vtc_i(ir),
            CPU_ir_free=1;
        else,
            cp_ind=cp_ind+1;
        end;
    end;
    if CPU_ir_free==1,
        pr=candidate_paths(cp_ind);
        ir=find(srcIPpath_table(pr,:)==1);
        budg_fromcache=bw_perpath(pr);
    end;
end;
if isempty(candidate_paths)||CPU_ir_free==0,
    ind_ems_same_e=(e-1)*(nbof_content+1)*nbof_resol+1:(e-1)*(nbof_content+1)*nbof_resol+nbof_content*nbof_resol;
    candidate_paths=find((sum(budget_path(:,ind_ems_same_e),2)>0)&(bw_perpath>=min(bmax_ms(type,s),bwlasthop)));
    CPU_ir_free=1;
    if ~isempty(candidate_paths),
        CPU_ir_free=0; cp_ind=1;
        while CPU_ir_free==0&&cp_ind<=length(candidate_paths),
            pr=candidate_paths(cp_ind);
            ir=find(srcIPpath_table(pr,:)==1);
            if CPUload_pernode(ir)-t_bbu_i(ir)<t_vtc_i(ir),
                CPU_ir_free=1;
            else,
                cp_ind=cp_ind+1;
            end;
        end;
        if CPU_ir_free==1,
            pr=candidate_paths(cp_ind);
            ir=find(srcIPpath_table(pr,:)==1);
            budg_fromcache=bw_perpath(pr);
        end;
    end;
end;
if isempty(candidate_paths)||CPU_ir_free==0,
    candidate_paths=find((sum(budget_path(:,ind_ems_same_e),2)>0)&(bw_perpath>=min(bmin_ms(type,s),bwlasthop)));
    CPU_ir_free=1;
    if ~isempty(candidate_paths),
        CPU_ir_free=0; cp_ind=1;
        while CPU_ir_free==0&&cp_ind<=length(candidate_paths),
            pr=candidate_paths(cp_ind);
            ir=find(srcIPpath_table(pr,:)==1);
            if CPUload_pernode(ir)-t_bbu_i(ir)<t_vtc_i(ir),
                CPU_ir_free=1;
            else,
                cp_ind=cp_ind+1;
            end;
        end;
        if CPU_ir_free==1,
            pr=candidate_paths(cp_ind);
            ir=find(srcIPpath_table(pr,:)==1);
            budg_fromcache=bw_perpath(pr);
        end;
    end;
end;
if isempty(candidate_paths)||CPU_ir_free==0,
    if e>nbof_fixedendnodes, [a,dst]=min(abs(array_z(:,e-nbof_fixedendnodes)-1)); else, dst=nbof_nodes-nbof_endnodes+e; end;
    candidate_paths=find((bw_perpath>=min(bmin_ms(type,s),bwlasthop))&...
        (logical(sum(srcIPpath_table(:,logical(t_vtc_i'>0)),2)))&(dstIPpath_table(:,dst)));
    CPU_ir_free=1;
    if ~isempty(candidate_paths),
        CPU_ir_free=0; cp_ind=1;
        while CPU_ir_free==0&&cp_ind<=length(candidate_paths),
            pr=candidate_paths(cp_ind);
            ir=find(srcIPpath_table(pr,:)==1);
            if CPUload_pernode(ir)-t_bbu_i(ir)<t_vtc_i(ir),
                CPU_ir_free=1;
            else,
                cp_ind=cp_ind+1;
            end;
        end;
        if CPU_ir_free==1,
            pr=candidate_paths(cp_ind);
            ir=find(srcIPpath_table(pr,:)==1);
            budg_fromcache=bw_perpath(pr);
        end;
    end;
end;
if isempty(candidate_paths)||CPU_ir_free==0,
    flag_fromPoPorrej=1;
    rqst_rejected(rowtrace_index)=1;
    %--- Logging the reason for the rejection
    if CPU_ir_free==0,,
        reason_rej(rowtrace_index)=1; 
    elseif isempty(candidate_paths),
        reason_rej(rowtrace_index)=2;
    end;
end;


if flag_fromPoPorrej==0,
    ir=find(srcIPpath_table(pr,:)==1);

    %--- Update Cstay of the caches' entries
    cache_entries=caches_entries{ir};
    sizes=[]; mind=[];
    if isempty(cache_entries)==0, % C_stay increases for all m's in cache
        cache_entries(3,:)=cache_entries(3,:)+1;
        sizes=cache_entries(4,:);
        mind=find(cache_entries(1,:)==mtrue);
    end;
    flag_incache=1;
    if isempty(mind)==0, % if content m already in cache at ir
        cache_entries(2,mind)=cache_entries(2,mind)+1; % C_hit of m increases
        bwserved=0;
        preload_time=0;
        [bwserved,budget_link,budget_PoP_ir,queue_activereq,CPUload_pernode]=CatchResources_fromCache(budg_fromcache,bwlasthop,bmax_ms(type,s),...
            budget_link,budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr,queue_activereq,watchingdur,...
            ir,e,s,CPUload_pernode,d_VTC,preload_time,m,type,mtrue,flag_servedas_unk);
        %-- Startup delay and relative rate/quality
        startup_delay(rowtrace_index)=0; % no loading of the cache, bw adapted on cache-client segment to maintain st. delay | siz*8/dur*15/budg_fromcache;    % buffering time due to cache-end node bw
        relativerate_served(rowtrace_index)=bwserved/min(bmax_ms(type,s),bwlasthop);
        %----
        reason_rej(rowtrace_index)=5;
    else,
        flag_incache=0;
        %-- Catch resources PoP->cache if needed
        if ir~=PoP,
            [rqst_rejected(rowtrace_index),reason_rej(rowtrace_index),budg_fromPoP,budget_link,budget_PoP_ir,queue_activefromPoP,bws]=CatchResources_fromPoP(budget_link,budget_PoP_ir,...
                srcIPpath_table,dstIPpath_table,bwlasthop,linkIPpath_table,ir,siz,queue_activefromPoP,flag_fromPoPorrej,...
                bmax_ms(type,s),bmin_ms(type,s),watchingdur,e,m,s,mtrue);
            if rqst_rejected(rowtrace_index)==0,
                %-- Catch resources cache-> end node or BBU
                bwserved=0;
                preload_time=queue_activefromPoP(1,end);
                [bwserved,budget_link,budget_PoP_ir,queue_activereq,CPUload_pernode]=CatchResources_fromCache(budg_fromcache,bwlasthop,bmax_ms(type,s),...
                    budget_link,budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr,queue_activereq,watchingdur,...
                    ir,e,s,CPUload_pernode,d_VTC,preload_time,m,type,mtrue,flag_servedas_unk);
                %-- Startup delay and relative rate/quality
                startup_delay(rowtrace_index)=siz*8/dur*inital_buf/budg_fromPoP; %min([budg_fromPoP,budg_fromcache,bwlasthop]);
                relativerate_served(rowtrace_index)=min(bwserved,budg_fromPoP)/min(bmax_ms(type,s),bwlasthop);
                %----
            end;
        else, %-- if the selected cache is the PoP
            %-- Catch resources cache-> end node or BBU
            bwserved=0;
            preload_time=0;
            [bwserved,budget_link,budget_PoP_ir,queue_activereq,CPUload_pernode]=CatchResources_fromCache(budg_fromcache,bwlasthop,...
                bmax_ms(type,s),budget_link,budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr,queue_activereq,watchingdur,...
                ir,e,s,CPUload_pernode,d_VTC,preload_time,m,type,mtrue,flag_servedas_unk);
            %-- Startup delay and relative rate/quality
            startup_delay(rowtrace_index)=0; %siz*8/dur*inital_buf/min(budg_fromcache,bwlasthop);;    % time for the client to buffer the first inital_buf sec
            relativerate_served(rowtrace_index)=bwserved/min(bmax_ms(type,s),bwlasthop);
            %----
        end;
        %--- Add cache entry
        if rqst_rejected(rowtrace_index)==0,
            if sum(sizes)<=vec_cacheSizes(ir)-siz,
                cache_entries=[cache_entries,[mtrue;1;1;siz]];
            else,   % eviction required
                scores=cache_entries(2,:)./cache_entries(3,:)./cache_entries(4,:);  % score 'LFU-based IBR-score' as defined in iproxy
                [sc,ind]=sort(scores,'ascend');
                cache_entries=cache_entries(:,ind);
                cumsizes=cumsum(cache_entries(4,:));
                ind_to_evict=logical(1-(cumsizes<siz));
                cache_entries=cache_entries(:,ind_to_evict);
                cache_entries=[[mtrue;1;1;siz],cache_entries];
            end;
            reason_rej(rowtrace_index)=6;
        end;
    end;
    caches_entries{ir}=cache_entries;
    %----
end;
end

function videodata_foroptim=make_videodataforoptim(topologydata,videodata,infrastructuredata,flag_compresscatalog,max_ems_p,ind_start,ind_end)
flag_compresscatalog=1;

nbof_mobendnodes=topologydata.nbof_mobendnodes;
nbof_fixedendnodes=topologydata.nbof_fixedendnodes;
nbof_endnodes=nbof_mobendnodes+nbof_fixedendnodes;
nbof_nodes=size(topologydata.pathInfo.bin_initNodes,1);
nbof_IPpaths=topologydata.pathInfo.P;
nbof_resol=size(videodata.alpha,2);

%-- update mat_content with seen content only
videodata_foroptim=videodata;
videodata_foroptim.mat_trace=videodata_foroptim.mat_trace(ind_start:ind_end,:);
nbof_content=size(videodata_foroptim.mat_content,2);

%--- Computation of vems (number of parallel requests)--
vems=sparse(1,nbof_endnodes*nbof_content*nbof_resol);
wdems=sparse(1,nbof_endnodes*nbof_content*nbof_resol);
occur_ems=sparse(1,nbof_endnodes*nbof_content*nbof_resol);
trace_time=videodata_foroptim.mat_trace(:,1);
for trace_ind=1:size(videodata_foroptim.mat_trace,1),
    e=videodata_foroptim.mat_trace(trace_ind,2); m=videodata_foroptim.mat_trace(trace_ind,3); s=videodata_foroptim.mat_trace(trace_ind,4);
    ind_ems=(e-1)*nbof_content*nbof_resol+(m-1)*nbof_resol+s;
    vems(ind_ems)=vems(ind_ems)+videodata_foroptim.mat_trace(trace_ind,7)/(trace_time(end)-trace_time(1));
    wdems(ind_ems)=wdems(ind_ems)+videodata_foroptim.mat_trace(trace_ind,7);
    occur_ems(ind_ems)=occur_ems(ind_ems)+1;
end;
wdems(occur_ems>0)=wdems(occur_ems>0)./occur_ems(occur_ems>0);
videodata_foroptim.vems=vems;
videodata_foroptim.wdems=wdems;
%----
max_catalog=ceil(max_ems_p/(nbof_endnodes*nbof_resol*nbof_IPpaths));
max_catalog=max(min(floor(max_catalog),nbof_content),10);
if max_catalog<nbof_content,
    [videodata_foroptim]=cluster_catalog(topologydata,videodata_foroptim,infrastructuredata,max_catalog);
else,
    videodata_foroptim.cluster_weight=ones(1,size(videodata_foroptim.mat_content,2));
end;

end

function m=find_centroid(videodata_foroptim,vec_rqst)

%--- Transform each feature into the right type: type as normalized rank,
%dur and size as z-score, flag4K left as binary

if isfield(videodata_foroptim,'vec_mean'),

cluster_weight=videodata_foroptim.cluster_weight;
vec_mean=videodata_foroptim.vec_mean;
vec_std=videodata_foroptim.vec_std;
centroidsnorm=videodata_foroptim.full_centroidsnorm;
mean_dur=vec_mean(1); mean_size=vec_mean(2); mean_e=vec_mean(3:end); nbof_endnodes=length(mean_e);
std_dur=vec_std(1); std_size=vec_std(2); std_e=vec_std(3:end);
nbof_videotype=videodata_foroptim.nbof_videotype;

if length(vec_rqst)<5,
    vec_rqst,
end;
type=vec_rqst(1); watchingdur=vec_rqst(2); siz=vec_rqst(3); flag4K=(vec_rqst(4)>3); e=vec_rqst(5);

type_transf=(type-1)/(nbof_videotype-1);
dur_transf=(watchingdur-mean_dur)/std_dur;
size_transf=(siz-mean_size)/std_size;
flag4K_transf=flag4K;
e_origin=zeros(nbof_endnodes,1); e_origin(e)=1;

input_norm=[type_transf;dur_transf;size_transf;flag4K_transf;e_origin];
vec_diff=repmat(input_norm,1,size(centroidsnorm,2))-centroidsnorm(2:size(centroidsnorm,1),:);
dist_centroids=diag(sqrt(vec_diff'*vec_diff));

[md,m]=min(dist_centroids);

else,
    m=vec_rqst(6);
end;

end

function array_x_p=merge_unk(array_x_p,array_xu_p,nbof_IPpaths,nbof_endnodes,nbof_content,nbof_resol)

mat1=sparse(zeros(nbof_IPpaths,nbof_endnodes*(nbof_content+1)*nbof_resol));
for e=1:nbof_endnodes,
    ind1=(e-1)*(nbof_content+1)*nbof_resol+1;
    ind2=(e-1)*(nbof_content+1)*nbof_resol+nbof_content*nbof_resol;
    mat1(:,ind1:ind2)=array_x_p(:,(e-1)*nbof_content*nbof_resol+1:e*nbof_content*nbof_resol);
    ind1=(e-1)*(nbof_content+1)*nbof_resol+nbof_content*nbof_resol+1;
    ind2=(e-1)*(nbof_content+1)*nbof_resol+nbof_content*nbof_resol+nbof_resol;
    mat1(:,ind1:ind2)=array_xu_p(:,(e-1)*nbof_resol+1:e*nbof_resol);
end;
array_x_p=mat1;
end

function [gamma_central,maxpower,maxQoE]=get_gammacentral(topo_traffic_filename,model,videodata_foroptim)
    load(topo_traffic_filename,'topologydata','videodata','infrastructuredata','backgroundTraff');
    maxpower_pernode=infrastructuredata.IPRpower+infrastructuredata.EGSpower+infrastructuredata.SRVpower+infrastructuredata.VMpower*sum(infrastructuredata.G_n*infrastructuredata.K);
    nbof_nodes=size(topologydata.nodeTable,1);
    maxpower=maxpower_pernode*nbof_nodes;
    E_M = topologydata.nbof_mobendnodes; % numMobileEndNodes;
    E_F = topologydata.nbof_fixedendnodes; % numFixEndNodes;
    E = E_M+E_F;  % numEndNodes;
    vems = videodata.vems';% to col
    % We transform all the content-type-dependnt info into individual content-dependant info
    nbof_resol=4;
    vem=sum(reshape(videodata_foroptim.vems,nbof_resol,length(videodata_foroptim.vems)/nbof_resol),1);
    vm=sum(reshape(vem,length(vem)/E,E),2);
    maxQoE=sum(videodata_foroptim.vems.*min(sum(infrastructuredata.nodeStorage)/sum(videodata_foroptim.mat_content(4,logical(vm>0))),1)); % sum(vems)
    if strcmp(model,'ViRCA3'),
        nbof_mobendnodes=E_M;
        maxQoE=sum(videodata.vems.*min(sum(infrastructuredata.nodeStorage([1 nbof_nodes-E+1:nbof_nodes]))/sum(videodata.mat_content(4,logical(vm>0))),1)); % sum(vems)
    end;
    gamma_central=maxpower/maxQoE;
end
