function [rqst_rejected,reason_rej,budg_fromPoP,budget_link,budget_PoP_ir,queue_activefromPoP,bwserved]=CatchResources_fromPoP(budget_link,budget_PoP_ir,...
    srcIPpath_table,dstIPpath_table,bwlasthop,linkIPpath_table,ir,siz_m,queue_activefromPoP,flag_fromPoPorrej,bmax,bmin,watchingdur,e,m,s,mtrue)

rqst_rejected=0; PoP=1; bwserved=0; reason_rej=0;
if flag_fromPoPorrej==0,
    %-- Select path from PoP to ir
    budgp=sparse(zeros(size(srcIPpath_table,1),1)); %-- to keep the same vector size and hence get thr right path index pr
    budgp(logical(srcIPpath_table(:,PoP)&dstIPpath_table(:,ir)))=budget_PoP_ir(logical(srcIPpath_table(:,PoP)&dstIPpath_table(:,ir)));
    [budg_fromPoP,pr]=max(budgp); % we assume the grabbed bw is the available bw on the path
    if budg_fromPoP<=0,
        rqst_rejected=1;
        %--- Logging the reason for the rejection
        reason_rej=4; % no bw from PoP to serve that cache
        %-------
        budg_fromPoP=0; bwserved=0;
    else,
        %-- Enqueue the request in the queue of active requests from PoP
        transferdur=siz_m/budg_fromPoP;
        queue_activefromPoP=[queue_activefromPoP,[transferdur;budg_fromPoP;ir;pr;e;m;s;mtrue;flag_fromPoPorrej]];
        %-- Catch bw resources from PoP, and impact on other budgets
        [budget_link,budget_PoP_ir]=UpdateBudgetonCatch(budget_link,budget_PoP_ir,budg_fromPoP,linkIPpath_table,srcIPpath_table,pr);
    end;
    
else,
    budgp=zeros(size(srcIPpath_table,1),1); %-- to keep the same vector size and hence get thr right path index pr
    budgp(logical(srcIPpath_table(:,PoP)&dstIPpath_table(:,ir)))=budget_PoP_ir(logical(srcIPpath_table(:,PoP)&dstIPpath_table(:,ir)));
    [budg_fromPoP,pr]=max(budgp);
    budg_fromPoP=min(budg_fromPoP,bwlasthop);
    bwserved=min([budg_fromPoP,bwlasthop,bmax]);
    if bwserved<min(bwlasthop,bmin),
        rqst_rejected=1;
    else,
        %-- Enqueue the request in the queue of active requests from PoP
        transferdur=watchingdur*60;
        queue_activefromPoP=[queue_activefromPoP,[transferdur;bwserved;ir;pr;e;m;s;mtrue;flag_fromPoPorrej]];
        %-- Catch bw resources from PoP, and impact on
        %other budgets
        [budget_link,budget_PoP_ir]=UpdateBudgetonCatch(budget_link,budget_PoP_ir,bwserved,linkIPpath_table,srcIPpath_table,pr);
    end;
end;