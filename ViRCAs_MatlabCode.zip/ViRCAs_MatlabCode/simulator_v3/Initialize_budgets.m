function [budget_path,budget_PoP_ir,capa_perpath,budget_link]=Initialize_budgets(nbof_nodes,nbof_IPpaths,nbof_endnodes,nbof_content,nbof_resol,capa_perlink,nbof_mobendnodes,nbof_fixedendnodes,...
    array_z,array_x_p,y_p,srcIPpath_table,dstIPpath_table,linkIPpath_table,g_ipr_i,bin_nodesInPath)

PoP=1;
first_endnode=nbof_nodes-nbof_endnodes+1; last_endnode=nbof_nodes;
indices_endnodes=first_endnode:last_endnode;

nbof_ems=nbof_endnodes*(nbof_content+1)*nbof_resol;
nbof_ms=nbof_content*nbof_resol;
%--- Intializing budgets from caches to end nodes
budget_path=sparse(zeros(nbof_IPpaths,nbof_ems));   % pems
for e=1:nbof_mobendnodes,
    indendnodes_e=nbof_fixedendnodes+e;
    indallnodes_e=indices_endnodes(indendnodes_e);
    ind_ems=(indendnodes_e-1)*nbof_ms+1:indendnodes_e*nbof_ms;
    [a,j]=min(abs(array_z(:,e)-1));
    budget_path(logical(dstIPpath_table(:,j)),ind_ems)=array_x_p(logical(dstIPpath_table(:,j)),ind_ems);    %pems
end;
for e=1:nbof_fixedendnodes,
    indendnodes_e=e;
    indallnodes_e=indices_endnodes(indendnodes_e);
    ind_ems=(indendnodes_e-1)*nbof_ms+1:indendnodes_e*nbof_ms;
    j=indallnodes_e;
    budget_path(logical(dstIPpath_table(:,j)),ind_ems)=array_x_p(logical(dstIPpath_table(:,j)),ind_ems);    %pems
end;
%----
%--- Initializing budgets from PoP to caches, that is all IP paths
on_nodes=repmat(g_ipr_i',nbof_IPpaths,1);
nodesInPath=bin_nodesInPath';
inactive_paths=zeros(nbof_IPpaths,nbof_nodes);
inactive_paths((on_nodes-nodesInPath)==-1)=1;
path_active=(sum(inactive_paths,2)==0);

capa_linksofpath=linkIPpath_table.*repmat(capa_perlink,nbof_IPpaths,1);
budget_PoP_ir=sparse(zeros(nbof_IPpaths,1));
ind_pathsfromPoP=logical(srcIPpath_table(:,PoP));
capa_perpath_tmp=capa_linksofpath; capa_perpath_tmp(capa_linksofpath==0)=max(capa_linksofpath(:))+1;
capa_perpath=min(capa_perpath_tmp,[],2); capa_perpath(capa_perpath>=max(capa_linksofpath(:))+1)=0; capa_perpath=capa_perpath.*path_active;
budget_PoP_ir(ind_pathsfromPoP)=capa_perpath(ind_pathsfromPoP);
%----
%--- Initializing budget_link
nbof_links=size(linkIPpath_table,2);
budget_link=zeros(1,nbof_links);
ind_activepath=find(path_active>0);
for path_ind=ind_activepath',
    budget_link(logical(linkIPpath_table(path_ind,:)))=capa_perlink(logical(linkIPpath_table(path_ind,:)));
end;
%----
