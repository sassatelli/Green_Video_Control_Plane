topo_vec={'FMC_tree';'Mobile_backhaul'};
% load_vec=[0.01 0.05 0.2 1];
load_vec=[0.05 0.2 1];
model_vec={'ViRCA';'ViRCA2';'ViRCA3'};

figure(1); ind_topo=1;
set(gca,'FontSize',18);
hold on;
for ind_mod=1:length(model_vec),
    for ind_load=1:length(load_vec),
        plot_Paretofront(topo_vec{ind_topo},model_vec{ind_mod},load_vec(ind_load));
    end;
end;
xlabel('power (W)','FontSize',24)
ylabel('QoE','FontSize',24)
h = findobj(gca,'Type','line');
legend([h(1) h(5) h(9)],'ViRCA','ViRCA2','ViRCA3')
hold off;

figure(2); ind_topo=2;
set(gca,'FontSize',18);
hold on;
for ind_mod=1:length(model_vec),
    for ind_load=1:length(load_vec),
        plot_Paretofront(topo_vec{ind_topo},model_vec{ind_mod},load_vec(ind_load));
    end;
end;
xlabel('power (W)','FontSize',24)
ylabel('QoE','FontSize',24)
% h = findobj(gca,'Type','line');
% legend([h(1) h(5) h(9)],'ViRCA','ViRCA2','ViRCA3')
hold off;

