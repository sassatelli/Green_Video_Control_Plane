function plot_scen23(topology_name,scen,gamma_factor,totalrequests)

% array_usedbudgets,array_QoE,array_CPU_load,array_optimoutput
% array_usedbudgets=cell(1,2);
% array_usedbudgets{rowtrace_index,1}=sum(budget_path_initial-budget_path,2); array_usedbudgets{rowtrace_index,2}=budget_PoP_ir_initial-budget_PoP_ir;
% array_QoE=[rqst_rejected,startup_delay,relativerate_served];
% array_CPU_load=repmat(t_bbu_i',size(trace_time,1),1);
% array_optimoutput{ind_optim,1}=0; array_optimoutput{ind_optim,2}=1;
% array_optimoutput{ind_optim,3}=sol.power; array_optimoutput{ind_optim,4}=sol.g_ipr_i; array_optimoutput{ind_optim,5}=sol.g_egs_i;
% array_optimoutput{ind_optim,6}=ViRCA_sol.t_bbu_i; array_optimoutput{ind_optim,7}=ViRCA_sol.t_vtc_i;

%-- Get the required parameters for the next figures
nbof_contentpercatalog=1e4; nbof_catalog=2; %totalrequests=2e4; %1e5;
if strcmp(topology_name,'FMC_tree'),
    topo_traffic_filename=['../simpoints/topo_traffic_',scen,'_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
elseif strcmp(topology_name,'FMC_ringandspur'),
    topo_traffic_filename=['../simpoints/topo_traffic_',scen,'_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
elseif strcmp(topology_name,'Mobile_backhaul'), % 2 1
    topo_traffic_filename=['../simpoints/topo_traffic_',scen,'_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
end;
load(topo_traffic_filename);
mat_trace=videodata.mat_trace(1:end,:); %2e4
srcIPpath_table=topologydata.pathInfo.bin_initNodes';
nbof_endnodes=topologydata.nbof_mobendnodes+topologydata.nbof_fixedendnodes;

%--- Figure 3 (QoE3, power and frac of on nodes vs time)
model='ViRCA';
res_filename=['sols/res_',scen,'_',model,'_',topology_name,'_gammafactor',num2str(gamma_factor),'.mat']; %,'_L',num2str(load_factor)
% load(res_filename,'results');
% array_usedbudgets_V1=results{1,1}; array_QoE_V1=results{1,2}; array_CPU_load_V1=results{1,3}; array_optimoutput_V1=results{1,4};
load(res_filename);
array_usedbudgets_V1=array_usedbudgets; array_QoE_V1=array_QoE; array_CPU_load_V1=array_CPU_load; array_optimoutput_V1=array_optimoutput;
filename=['res_',scen,'_',model,'_',topology_name,'_gammafactor',num2str(gamma_factor),'.mat'];
save(['array_usedbudgets_V1' '_' filename],'array_usedbudgets_V1','-v7.3');
clear results array_usedbudgets_V1 array_CPU_load_V1;
clear array_usedbudgets array_QoE array_CPU_load array_optimoutput;

%-- Plot the actual load over time
nbof_points=200;
window_len=(mat_trace(end,1)-mat_trace(1,1))/nbof_points;
load_win=zeros(ceil((mat_trace(end,1)-mat_trace(1,1))/window_len),1); window_tick=load_win;
win_ind=1;
i_start=1;
while win_ind<=length(load_win),
    tstart=mat_trace(i_start,1);
    i_end=find(mat_trace(:,1)>=min(tstart+window_len,mat_trace(end,1))); i_end=i_end(1)-1;
    load_win(win_ind)=(i_end-i_start+1)/(mat_trace(i_end,1)-mat_trace(i_start,1)); % % nbof_rqst/timeperiod
    %load_win(win_ind)=sum(mat_trace(i_start:i_end,7))*60/(mat_trace(i_end,1)-mat_trace(i_start,1)); % % nbof_rqst/timeperiod
    window_tick(win_ind)=mat_trace(i_start,1); %(mat_trace(i_start,1)+mat_trace(i_end,1))/2;
    i_start=i_end+1;
    win_ind=win_ind+1;
end;
figure(3); 
set(gca,'FontSize',18);
hold on
h_load=stairs(window_tick,load_win,'-k','LineWidth',2);
window_tick_load=window_tick;

QoE3_v1_win=zeros(ceil((mat_trace(end,1)-mat_trace(1,1))/window_len),1); %QoE3_v2_win=QoE3_v1_win; QoE3_v3_win=QoE3_v1_win;
QoEreas_win=QoE3_v1_win;
window_tick=QoE3_v1_win;
win_ind=1;
i_start=1;
while win_ind<=length(QoE3_v1_win),
    tstart=mat_trace(i_start,1);
    i_end=find(mat_trace(:,1)>=min(tstart+window_len,mat_trace(end,1))); i_end=i_end(1)-1;
    QoE3_v1_win(win_ind)=mean(array_QoE_V1(i_start:i_end,3));
    ind=find(array_QoE_V1(i_start:i_end,4)<5); v=i_start:i_end;
    QoEreas_win(win_ind)=mean(array_QoE_V1(v(ind),4));
    window_tick(win_ind)=mat_trace(i_start,1); %(mat_trace(i_start,1)+mat_trace(i_end,1))/2;
    i_start=i_end+1;
    win_ind=win_ind+1;
end;
figure(3); hold on
h_QoE=plot(window_tick,QoE3_v1_win,'-+g','LineWidth',2,'markers',8);
h_reas=plot(window_tick,QoEreas_win,'*r','LineWidth',2,'markers',8);

len1=length(cell2mat(array_optimoutput_V1(:,1)));
array_optimoutput_V1(len1+1,:)=array_optimoutput_V1(len1,:); array_optimoutput_V1(len1+1,1:2)={mat_trace(end,1),len1+1};

[maxpower,nbof_nodes]=get_maxpower(topo_traffic_filename);
power_V1=cell2mat(array_optimoutput_V1(:,3));
timeoptim_V1=cell2mat(array_optimoutput_V1(:,1)); 
c=zeros(length(timeoptim_V1),length(array_optimoutput_V1{1,4}));
for i=1:length(timeoptim_V1),
    c(i,:)=array_optimoutput_V1{i,4}+array_optimoutput_V1{i,5};
end;
m=(c>0);
fraconnodes_V1=sum(m,2);
h_fracnodes=stairs(timeoptim_V1,fraconnodes_V1/max(fraconnodes_V1),'-om','LineWidth',2,'markers',8);
c=zeros(length(timeoptim_V1),length(array_optimoutput_V1{1,4}));
for i=1:length(timeoptim_V1),
    c(i,:)=array_optimoutput_V1{i,6};
end;
cpusBBU_V1=sum(c,2);
h_bbu=stairs(timeoptim_V1,cpusBBU_V1/max(cpusBBU_V1),'-^c','LineWidth',2,'markers',8);
c=zeros(length(timeoptim_V1),length(array_optimoutput_V1{1,4}));
for i=1:length(timeoptim_V1),
    c(i,:)=array_optimoutput_V1{i,7};
end;
cpusVTC_V1=sum(c,2);
h_vtc=stairs(timeoptim_V1,cpusVTC_V1/max(cpusVTC_V1),'-vr','LineWidth',2,'markers',8);
xlabel('time','FontSize',24);
legend([h_load,h_QoE,h_fracnodes,h_bbu,h_vtc,h_reas],{'load','relative rate(*)','frac. of nodes on','frac. of CPUs for BBU ops','frac. of CPUs for video transcoding ops','reason for QoE drop'},'FontSize',24)



%--- Figure 4 (nb of paths taken by same-type requests)
model='ViRCA';
filename=['res_',scen,'_',model,'_',topology_name,'_gammafactor',num2str(gamma_factor),'.mat'];
load(['array_usedbudgets_V1' '_' filename],'array_usedbudgets_V1');

ratio=zeros(ceil((mat_trace(end,1)-mat_trace(1,1))/window_len),1);
window_tick=0;
win_ind=1;
i_start=1;
while win_ind<=size(ratio,1),
    tstart=mat_trace(i_start,1);
    i_end=find(mat_trace(:,1)>=min(tstart+window_len,mat_trace(end,1))); i_end=i_end(1)-1;
    if i_end<i_start,
        ratio=ratio(1:win_ind-1);
        break;
    end;
    ipe_vec=cell2mat(array_usedbudgets_V1(i_start:i_end,2)); ipe_vec=ipe_vec';
    nbused_paths=zeros(1,nbof_endnodes); nbused_src=zeros(1,nbof_endnodes);
    for e=1:nbof_endnodes,
        bin_ind=logical(ipe_vec(3,:)==e);
        if sum(bin_ind)>0,
            nbused_paths(e)=length(unique(ipe_vec(2,bin_ind)));
            nbused_src(e)=length(unique(ipe_vec(1,bin_ind)));
        end;
    end;
    ratio(win_ind)=mean(nbused_paths(nbused_paths>0)./nbused_src(nbused_paths>0));
    window_tick(win_ind)=mat_trace(i_start,1); %(mat_trace(i_start,1)+mat_trace(i_end,1))/2;
    i_start=i_end+1;
    win_ind=win_ind+1;
end;
figure(4); 
set(gca,'FontSize',18);
hold on
h_ratio=stairs(window_tick,ratio,'-r','LineWidth',2,'markers',8);
h_load=stairs(window_tick_load,load_win,'-k','LineWidth',2,'markers',8);
legend([h_load,h_ratio],{'load','nb of paths per request type'},'FontSize',24);

end

function [maxpower,nbof_nodes]=get_maxpower(topo_traffic_filename)
    filename=['../simpoints/',topo_traffic_filename];
    load(filename,'topologydata','videodata','infrastructuredata','backgroundTraff');
    infrastructuredata.K=12
    maxpower_pernode=infrastructuredata.IPRpower+infrastructuredata.EGSpower+infrastructuredata.SRVpower+infrastructuredata.VMpower*sum(infrastructuredata.G_n*infrastructuredata.K);
    maxpower=maxpower_pernode*size(topologydata.nodeTable,1);
    nbof_nodes=size(topologydata.nodeTable,1);
end
