topo_vec={'FMC_tree';'Mobile_backhaul'};
load_vec=[0.01 0.05 0.2 1];
model_vec={'ViRCA';'ViRCA2';'ViRCA3'};
gamma_factor_vec=[0.4 1]; %[0.1 0.4 0.7 1]; %1;%[0.01 0.04 0.07 0.1 0.2 0.3 0.4 0.5 0.6 0.7 1 50];

figure(1); ind_topo=1;
set(gca,'FontSize',18);
hold on;
for ind_mod=1:length(model_vec),
    for ind_g=1:length(gamma_factor_vec),
        plot_scen1(topo_vec{ind_topo},load_vec,model_vec{ind_mod},gamma_factor_vec(ind_g));
    end;
end;
xlabel('power (W)','FontSize',24)
ylabel('QoE','FontSize',24)
hold off;

for ind_g=1:length(gamma_factor_vec),
    plot_scen1_fig2(topo_vec{ind_topo},load_vec,gamma_factor_vec(ind_g))
end;

ind_topo=1;
for ind_mod=1:length(model_vec),
    for ind_g=1:1,%length(gamma_factor_vec),
        plot_scen1(topo_vec{ind_topo},load_vec,model_vec{ind_mod},gamma_factor_vec(ind_g));
    end;
end;


figure(2); ind_topo=2;
set(gca,'FontSize',18);
hold on;
for ind_mod=1:length(model_vec),
    for ind_g=1:length(gamma_factor_vec),
        plot_scen1(topo_vec{ind_topo},load_vec,model_vec{ind_mod},gamma_factor_vec(ind_g));
    end;
end;
xlabel('power (W)','FontSize',24)
ylabel('QoE','FontSize',24)
hold off;

for ind_g=1:length(gamma_factor_vec),
    plot_scen1_fig2(topo_vec{ind_topo},load_vec,gamma_factor_vec(ind_g))
end;

ind_topo=2;
for ind_mod=1:length(model_vec),
    for ind_g=1:1,%length(gamma_factor_vec),
        plot_scen1(topo_vec{ind_topo},load_vec,model_vec{ind_mod},gamma_factor_vec(ind_g));
    end;
end;
