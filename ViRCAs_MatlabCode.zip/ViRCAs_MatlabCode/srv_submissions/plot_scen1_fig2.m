function plot_scen1_fig2(topology_name,load_vec,gamma_factor)

%--- Figure 2 (Power types vs load)
nbof_catalog=1; totalrequests=1e5; nbof_contentpercatalog=1e4;
filename=['../simpoints/topo_traffic_scen1_',topology_name,'_L',num2str(load_vec(1)),'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
load(filename,'topologydata','videodata','infrastructuredata','backgroundTraff');

len=length(load_vec);
xtick=[];
    
figure;
set(gca,'FontSize',18);
hold on;

for i=1:len,
    model='ViRCA';
    sol_filename=['sols/sol_gamma_',model,'_',topology_name,'_L',num2str(load_vec(i)),'_gammafactor',num2str(gamma_factor),'.mat'];
    load(sol_filename);
    CPU_power=infrastructuredata.SRVpower*sum(sol.g_srv_i)+infrastructuredata.VMpower*sum(sol.t_bbu_i)+infrastructuredata.VMpower*sum(sol.t_vtc_i);
    Rout_power=infrastructuredata.IPRpower*sum(sol.g_ipr_i);
    Sw_power=infrastructuredata.EGSpower*sum(sol.g_egs_i);
    powers_V1=[CPU_power,Rout_power,Sw_power];
    
    model='ViRCA2';
    sol_filename=['sols/sol_gamma_',model,'_',topology_name,'_L',num2str(load_vec(i)),'_gammafactor',num2str(gamma_factor),'.mat'];
    load(sol_filename);
    CPU_power=infrastructuredata.SRVpower*sum(sol.g_srv_i)+infrastructuredata.VMpower*sum(sol.t_bbu_i)+infrastructuredata.VMpower*sum(sol.t_vtc_i);
    Rout_power=infrastructuredata.IPRpower*sum(sol.g_ipr_i);
    Sw_power=infrastructuredata.EGSpower*sum(sol.g_egs_i);
    powers_V2=[CPU_power,Rout_power,Sw_power];
    
    model='ViRCA3';
    sol_filename=['sols/sol_gamma_',model,'_',topology_name,'_L',num2str(load_vec(i)),'_gammafactor',num2str(gamma_factor),'.mat'];
    load(sol_filename);
    CPU_power=infrastructuredata.SRVpower*sum(sol.g_srv_i)+infrastructuredata.VMpower*sum(sol.t_bbu_i)+infrastructuredata.VMpower*sum(sol.t_vtc_i);
    Rout_power=infrastructuredata.IPRpower*sum(sol.g_ipr_i);
    Sw_power=infrastructuredata.EGSpower*sum(sol.g_egs_i);
    powers_V3=[CPU_power,Rout_power,Sw_power];
    
    y=[powers_V1;powers_V2;powers_V3];
    x=[i-0.2 i i+0.2];
    handl=bar(x,y,'stacked');
    xtick=[xtick,x];
end;

x_labels={'ViRCA','ViRCA2','ViRCA3','ViRCA','ViRCA2','ViRCA3','ViRCA','ViRCA2','ViRCA3','ViRCA','ViRCA2','ViRCA3'};
set(gca,'XLim',[0 len+1],'XTick',xtick,'XTickLabel',x_labels);
set(gca,'XTickLabelRotation',45)
xlabel('load factor')
ylabel('power (W)')
leg_labels={'CPU power' 'Routing power' 'Switching power'};
legend(handl,leg_labels)
hold off;
