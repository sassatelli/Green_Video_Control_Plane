function plot_Paretofront(topology_name,model,traffload)

gamma_factor_vec=[0.01 0.04 0.07 0.1 0.2 0.3 0.4 0.5 0.6 0.7 1 10]; %[0.01 0.1 0.4 0.7 1 10]; %[0.01 0.04 0.07 0.1 0.2 0.3 0.4 0.5 0.6 0.7 1 10]; %[0.01 0.04 0.07 0.1:0.1:0.7 1];% 10 50];
len=length(gamma_factor_vec);
power_vec=zeros(1,len);
QoE_vec=zeros(1,len);
optgap_vec=zeros(1,len);
cachedm=zeros(1,len);

if strcmp(topology_name,'FMC_tree'), nbof_nodes=22; elseif strcmp(topology_name,'Mobile_backhaul'), nbof_nodes=31; end;

for i=1:len,
    sol_filename=['sols/sol_gamma_',model,'_',topology_name,'_L',num2str(traffload),'_gammafactor',num2str(gamma_factor_vec(i)),'.mat'];
    load(sol_filename);
    power_vec(i)=sol.power;
    QoE_vec(i)=sol.QoE;
    optgap_vec(i)=sol.miprelgap;
    nbof_catalog=1; totalrequests=1e5; nbof_contentpercatalog=1e4;
    hm=sum(reshape(sol.h_mi,nbof_nodes,length(sol.h_mi)/nbof_nodes),1);
    cachedm(i)=sum(hm>0);
end;

%--- Figure 1 (QoE vs Power)
if strcmp(model,'ViRCA'),
    colorstr='red'; mt='o';
elseif strcmp(model,'ViRCA2'),
    colorstr='green'; mt='s';
elseif strcmp(model,'ViRCA3'),
    colorstr='blue'; mt='^';
end;
% figure(2); hold on;
% subplot(1,2,1)
plot(power_vec,QoE_vec,['-',mt],'Color',colorstr,'LineWidth',2,'markers',8);
% xlabel('power')
% ylabel('QoE')
for i=1:len,
    x=power_vec(i);
    y=QoE_vec(i);
    text(x,y*0.8,num2str(gamma_factor_vec(i)),'Color',colorstr,'FontSize',12);
%     text(x,y*1.2,num2str(cachedm(i)),'Color',colorstr,'FontSize',12);
end;
% hold off;
optgap_vec

% figure(2); hold on;
% subplot(1,2,2)
% plot(power_vec,optgap_vec,'-ob');
% xlabel('power')
% ylabel('optimality gap')
% legend(model)
% for i=1:len,
%     x=power_vec(i);
%     y=optgap_vec(i);
%     text(x-1,y-1,num2str(gamma_factor_vec(i)));
% end;
% hold off;
