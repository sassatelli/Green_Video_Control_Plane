function plot_scen2cstfinal(topology_name,scen,gamma_factor,totalrequests)

% array_usedbudgets,array_QoE,array_CPU_load,array_optimoutput
% array_usedbudgets=cell(1,2);
% array_usedbudgets{rowtrace_index,1}=sum(budget_path_initial-budget_path,2); array_usedbudgets{rowtrace_index,2}=budget_PoP_ir_initial-budget_PoP_ir;
% array_QoE=[rqst_rejected,startup_delay,relativerate_served];
% array_CPU_load=repmat(t_bbu_i',size(trace_time,1),1);
% array_optimoutput{ind_optim,1}=0; array_optimoutput{ind_optim,2}=1;
% array_optimoutput{ind_optim,3}=sol.power; array_optimoutput{ind_optim,4}=sol.g_ipr_i; array_optimoutput{ind_optim,5}=sol.g_egs_i;
% array_optimoutput{ind_optim,6}=ViRCA_sol.t_bbu_i; array_optimoutput{ind_optim,7}=ViRCA_sol.t_vtc_i;

model='ViRCA';
res_filename=['sols/res_',scen,'_',model,'_',topology_name,'_gammafactor',num2str(gamma_factor),'.mat']; %,'_L',num2str(load_factor)
load(res_filename);
array_usedbudgets_V1=array_usedbudgets; array_QoE_V1=array_QoE; array_CPU_load_V1=array_CPU_load; array_optimoutput_V1=array_optimoutput;
filename=['res_',scen,'_',model,'_',topology_name,'_gammafactor',num2str(gamma_factor),'.mat'];
save(['array_usedbudgets_V1' '_' filename],'array_usedbudgets_V1','-v7.3');
clear results array_usedbudgets_V1 array_CPU_load_V1;
clear array_usedbudgets array_QoE array_CPU_load array_optimoutput;
model='ViRCA2';
res_filename=['sols/res_',scen,'_',model,'_',topology_name,'_gammafactor',num2str(gamma_factor),'.mat'];
load(res_filename);
array_usedbudgets_V2=array_usedbudgets; array_QoE_V2=array_QoE; array_CPU_load_V2=array_CPU_load; array_optimoutput_V2=array_optimoutput;
filename=['res_',scen,'_',model,'_',topology_name,'_gammafactor',num2str(gamma_factor),'.mat'];
save(['array_usedbudgets_V2' '_' filename],'array_usedbudgets_V2','-v7.3');
clear results array_usedbudgets_V2 array_CPU_load_V2;
clear array_usedbudgets array_QoE array_CPU_load array_optimoutput;
model='ViRCA3';
res_filename=['sols/res_',scen,'_',model,'_',topology_name,'_gammafactor',num2str(gamma_factor),'.mat'];
load(res_filename);
array_usedbudgets_V3=array_usedbudgets; array_QoE_V3=array_QoE; array_CPU_load_V3=array_CPU_load; array_optimoutput_V3=array_optimoutput;
filename=['res_',scen,'_',model,'_',topology_name,'_gammafactor',num2str(gamma_factor),'.mat'];
save(['array_usedbudgets_V3' '_' filename],'array_usedbudgets_V3','-v7.3');
clear results array_usedbudgets_V3 array_CPU_load_V3;
clear array_usedbudgets array_QoE array_CPU_load array_optimoutput;

%--- Powers at first optim
array_optimoutput_V1{1,3}, array_optimoutput_V2{1,3}, array_optimoutput_V3{1,3}

%--- Figure 1 (all QoE metrics for all strategies)
QoE1_ViRCA=mean(array_QoE_V1(:,1)); QoE2_ViRCA=mean(array_QoE_V1(array_QoE_V1(:,1)==0,2)); QoE3_ViRCA=mean(array_QoE_V1(array_QoE_V1(:,1)==0,3));
QoE1_ViRCA2=mean(array_QoE_V2(:,1)); QoE2_ViRCA2=mean(array_QoE_V2(array_QoE_V2(:,1)==0,2)); QoE3_ViRCA2=mean(array_QoE_V2(array_QoE_V2(:,1)==0,3));
QoE1_ViRCA3=mean(array_QoE_V3(:,1)); QoE2_ViRCA3=mean(array_QoE_V3(array_QoE_V3(:,1)==0,2)); QoE3_ViRCA3=mean(array_QoE_V3(array_QoE_V3(:,1)==0,3));
figure(1);
set(gca,'FontSize',20);
subplot(1,4,1);
set(gca,'FontSize',20);
y=[QoE1_ViRCA,QoE1_ViRCA2,QoE1_ViRCA3];
c = {'ViRCA','ViRCA2','ViRCA3'};
bar(y);
set(gca,'FontSize',20,'XLim',[0 4],'XTick',1:3,'XTickLabel',c);
set(gca,'XTickLabelRotation',45)
ylabel('Frac. of rejected requests','FontSize',24)
subplot(1,4,2);
set(gca,'FontSize',20);
y=[QoE2_ViRCA,QoE2_ViRCA2,QoE2_ViRCA3];
bar(y)
set(gca,'FontSize',20,'XLim',[0 4],'XTick',1:3,'XTickLabel',c);
set(gca,'XTickLabelRotation',45)
ylabel('Startup delay (s)','FontSize',24)
subplot(1,4,3);
set(gca,'FontSize',20);
y=[QoE3_ViRCA,QoE3_ViRCA2,QoE3_ViRCA3];
bar(y)
set(gca,'FontSize',20,'XLim',[0 4],'XTick',1:3,'XTickLabel',c);
set(gca,'XTickLabelRotation',45)
ylabel('Relative video rate','FontSize',24)
subplot(1,4,4);
set(gca,'FontSize',20);
y=[array_optimoutput_V1{1,3}, array_optimoutput_V2{1,3}, array_optimoutput_V3{1,3}];
bar(y);
set(gca,'FontSize',20,'XLim',[0 4],'XTick',1:3,'XTickLabel',c);
set(gca,'XTickLabelRotation',45)
ylabel('Power (W)','FontSize',24)

% --- Figure explaining the observed perf
figure(11);
set(gca,'FontSize',20);

%%%% placement of caches and bbus
t_bbu_V1=array_optimoutput_V1{1,6}; t_vtc_V1=array_optimoutput_V1{1,7};
t_bbu_V2=array_optimoutput_V2{1,6}; t_vtc_V2=array_optimoutput_V2{1,7};
t_bbu_V3=array_optimoutput_V3{1,6}; t_vtc_V3=array_optimoutput_V3{1,7};
subplot(3,1,1);
set(gca,'FontSize',20);
hold on; stem(t_bbu_V1,'or-','LineWidth',2,'markers',8); stem(t_vtc_V1,'*b-','LineWidth',2,'markers',8); hold off
legend({'BBUs locations','caches locations'},'FontSize',24);
title('ViRCA');
ylabel('cores','FontSize',24);
subplot(3,1,2);
set(gca,'FontSize',20);
hold on; stem(t_bbu_V2,'or-','LineWidth',2,'markers',8); stem(t_vtc_V2,'*b-','LineWidth',2,'markers',8); hold off
title('ViRCA2');
ylabel('cores','FontSize',24);
subplot(3,1,3);
set(gca,'FontSize',20);
hold on; stem(t_bbu_V3,'or-','LineWidth',2,'markers',8); stem(t_vtc_V3,'*b-','LineWidth',2,'markers',8); hold off
title('ViRCA3');
xlabel('node index','FontSize',24);
ylabel('cores','FontSize',24);

%-- Get the required parameters for the next figures
nbof_contentpercatalog=1e4; nbof_catalog=1; %totalrequests=2e4; %1e5;
if strcmp(topology_name,'FMC_tree'),
    topo_traffic_filename=['../simpoints/topo_traffic_',scen,'_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
elseif strcmp(topology_name,'FMC_ringandspur'),
    topo_traffic_filename=['../simpoints/topo_traffic_',scen,'_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
elseif strcmp(topology_name,'Mobile_backhaul'), % 2 1
    topo_traffic_filename=['../simpoints/topo_traffic_',scen,'_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
end;
load(topo_traffic_filename);
mat_trace=videodata.mat_trace(1:2e4,:); %2e4
srcIPpath_table=topologydata.pathInfo.bin_initNodes';
nbof_endnodes=topologydata.nbof_mobendnodes+topologydata.nbof_fixedendnodes;

%--- Figure 2 (QoE3 vs popularity)
requested_content=unique(mat_trace(:,3));
pop=zeros(length(requested_content),1);
len=length(requested_content);
for i=1:length(requested_content),
    bin_ind=(mat_trace(:,3)==requested_content(i));
    pop(i)=sum(bin_ind);
end;
% clear array_QoE_V1 array_QoE_V2 array_QoE_V3;
[pop_sorted,hitolow]=sort(pop,'descend');
pop_cum=cumsum(pop_sorted);
hi_ind=find(pop_cum/pop_cum(end)<=0.05); med_ind=find((pop_cum/pop_cum(end)>0.05)&(pop_cum/pop_cum(end)<=0.2)); low_ind=find(pop_cum/pop_cum(end)>0.2);

bin_ind=ismember(mat_trace(:,3),requested_content(hitolow(low_ind)));
QoE3_lowpop_ViRCA=mean(array_QoE_V1(bin_ind,3)); QoE3_lowpop_ViRCA2=mean(array_QoE_V2(bin_ind,3)); QoE3_lowpop_ViRCA3=mean(array_QoE_V3(bin_ind,3));
QoE2_lowpop_ViRCA=mean(array_QoE_V1(bin_ind&(array_QoE_V1(:,1)==0),2)); QoE2_lowpop_ViRCA2=mean(array_QoE_V2(bin_ind&(array_QoE_V2(:,1)==0),2)); QoE2_lowpop_ViRCA3=mean(array_QoE_V3(bin_ind&(array_QoE_V3(:,1)==0),2));
lb=sum(bin_ind&(array_QoE_V1(:,1)==0));
fromsrvorcache_low_V1=[sum(array_QoE_V1(bin_ind&(array_QoE_V1(:,1)==0),4)==5)/lb,sum(array_QoE_V1(bin_ind&(array_QoE_V1(:,1)==0),4)==6)/lb]; 
lb=sum(bin_ind&(array_QoE_V2(:,1)==0));
fromsrvorcache_low_V2=[sum(array_QoE_V2(bin_ind&(array_QoE_V2(:,1)==0),4)==5)/lb,sum(array_QoE_V2(bin_ind&(array_QoE_V2(:,1)==0),4)==6)/lb]; 
lb=sum(bin_ind&(array_QoE_V3(:,1)==0));
fromsrvorcache_low_V3=[sum(array_QoE_V3(bin_ind&(array_QoE_V3(:,1)==0),4)==5)/lb,sum(array_QoE_V3(bin_ind&(array_QoE_V3(:,1)==0),4)==6)/lb]; 

bin_ind=ismember(mat_trace(:,3),requested_content(hitolow(med_ind)));
QoE3_medpop_ViRCA=mean(array_QoE_V1(bin_ind,3)); QoE3_medpop_ViRCA2=mean(array_QoE_V2(bin_ind,3)); QoE3_medpop_ViRCA3=mean(array_QoE_V3(bin_ind,3));
QoE2_medpop_ViRCA=mean(array_QoE_V1(bin_ind&(array_QoE_V1(:,1)==0),2)); QoE2_medpop_ViRCA2=mean(array_QoE_V2(bin_ind&(array_QoE_V2(:,1)==0),2)); QoE2_medpop_ViRCA3=mean(array_QoE_V3(bin_ind&(array_QoE_V3(:,1)==0),2));
lb=sum(bin_ind&(array_QoE_V1(:,1)==0));
fromsrvorcache_med_V1=[sum(array_QoE_V1(bin_ind&(array_QoE_V1(:,1)==0),4)==5)/lb,sum(array_QoE_V1(bin_ind&(array_QoE_V1(:,1)==0),4)==6)/lb]; 
lb=sum(bin_ind&(array_QoE_V2(:,1)==0));
fromsrvorcache_med_V2=[sum(array_QoE_V2(bin_ind&(array_QoE_V2(:,1)==0),4)==5)/lb,sum(array_QoE_V2(bin_ind&(array_QoE_V2(:,1)==0),4)==6)/lb]; 
lb=sum(bin_ind&(array_QoE_V3(:,1)==0));
fromsrvorcache_med_V3=[sum(array_QoE_V3(bin_ind&(array_QoE_V3(:,1)==0),4)==5)/lb,sum(array_QoE_V3(bin_ind&(array_QoE_V3(:,1)==0),4)==6)/lb]; 

bin_ind=ismember(mat_trace(:,3),requested_content(hitolow(hi_ind)));
QoE3_hipop_ViRCA=mean(array_QoE_V1(bin_ind,3)); QoE3_hipop_ViRCA2=mean(array_QoE_V2(bin_ind,3)); QoE3_hipop_ViRCA3=mean(array_QoE_V3(bin_ind,3));
QoE2_hipop_ViRCA=mean(array_QoE_V1(bin_ind&(array_QoE_V1(:,1)==0),2)); QoE2_hipop_ViRCA2=mean(array_QoE_V2(bin_ind&(array_QoE_V2(:,1)==0),2)); QoE2_hipop_ViRCA3=mean(array_QoE_V3(bin_ind&(array_QoE_V3(:,1)==0),2));
lb=sum(bin_ind&(array_QoE_V1(:,1)==0));
fromsrvorcache_hi_V1=[sum(array_QoE_V1(bin_ind&(array_QoE_V1(:,1)==0),4)==5)/lb,sum(array_QoE_V1(bin_ind&(array_QoE_V1(:,1)==0),4)==6)/lb]; 
lb=sum(bin_ind&(array_QoE_V2(:,1)==0));
fromsrvorcache_hi_V2=[sum(array_QoE_V2(bin_ind&(array_QoE_V2(:,1)==0),4)==5)/lb,sum(array_QoE_V2(bin_ind&(array_QoE_V2(:,1)==0),4)==6)/lb]; 
lb=sum(bin_ind&(array_QoE_V3(:,1)==0));
fromsrvorcache_hi_V3=[sum(array_QoE_V3(bin_ind&(array_QoE_V3(:,1)==0),4)==5)/lb,sum(array_QoE_V3(bin_ind&(array_QoE_V3(:,1)==0),4)==6)/lb]; 

figure(2);
set(gca,'FontSize',20);
y=[QoE3_lowpop_ViRCA,QoE3_lowpop_ViRCA2,QoE3_lowpop_ViRCA3;...
   QoE3_medpop_ViRCA,QoE3_medpop_ViRCA2,QoE3_medpop_ViRCA3;...
   QoE3_hipop_ViRCA,QoE3_hipop_ViRCA2,QoE3_hipop_ViRCA3];
h=bar(y,'group');
c={'low pop.','medium pop.','high pop.'};
set(gca,'XLim',[0 4],'XTick',1:3,'XTickLabel',c);
ylabel('Relative video rate (*)','FontSize',24)
bar_labels={'ViRCA 1' 'ViRCA 2' 'ViRCA 3'};
legend(bar_labels,'location','northwest','FontSize',24)

figure(21);
y=[QoE2_lowpop_ViRCA,QoE2_lowpop_ViRCA2,QoE2_lowpop_ViRCA3;...
   QoE2_medpop_ViRCA,QoE2_medpop_ViRCA2,QoE2_medpop_ViRCA3;...
   QoE2_hipop_ViRCA,QoE2_hipop_ViRCA2,QoE2_hipop_ViRCA3];
h=bar(y,'group');
c={'low pop.','medium pop.','high pop.'};
set(gca,'XLim',[0 4],'XTick',1:3,'XTickLabel',c);
ylabel('Startup delay (s)','FontSize',24)
bar_labels={'ViRCA 1' 'ViRCA 2' 'ViRCA 3'};
legend(bar_labels,'location','northwest','FontSize',24)

figure(22); hold on;
y=[fromsrvorcache_low_V1;fromsrvorcache_low_V2;fromsrvorcache_low_V3];
x=[0.8 1 1.2];
hlow=bar(x,y,'stacked');
y=[fromsrvorcache_med_V1;fromsrvorcache_med_V2;fromsrvorcache_med_V3];
x=[1.8 2 2.2];
hmed=bar(x,y,'stacked');
y=[fromsrvorcache_hi_V1;fromsrvorcache_hi_V2;fromsrvorcache_hi_V3];
x=[2.8 3 3.2];
hhi=bar(x,y,'stacked');

c={'low pop.','medium pop.','high pop.'};
set(gca,'XLim',[0 4],'XTick',1:3,'XTickLabel',c);
ylabel('Origins','FontSize',24)
leg_labels={'from cache','from PoP'};
legend(hlow,leg_labels,'FontSize',24)
hold off;
return;

end

function [maxpower,nbof_nodes]=get_maxpower(topo_traffic_filename)
    filename=['../simpoints/',topo_traffic_filename];
    load(filename,'topologydata','videodata','infrastructuredata','backgroundTraff');
    infrastructuredata.K=12
    maxpower_pernode=infrastructuredata.IPRpower+infrastructuredata.EGSpower+infrastructuredata.SRVpower+infrastructuredata.VMpower*sum(infrastructuredata.G_n*infrastructuredata.K);
    maxpower=maxpower_pernode*size(topologydata.nodeTable,1);
    nbof_nodes=size(topologydata.nodeTable,1);
end
