function [videodata]=cluster_catalog(topologydata,videodata,infrastructuredata,max_catalog)

%-- vems: sparse vector of full length nbof_endnodes x nbof_content2 xnbof_resol (nbof_content2 is the number of contents when the 4K requests have been assigned another id)
%-- mat_content: 5 x nbof_content2 (row1: m, row2: type, row3: duration, row4: size; row5: flag4K)
%-- mat_trace: totalrequests x 8 (columns: timestamp|e|m|s|type|siz|watchingdur|bwlasthop)

mat_content=videodata.mat_content;
nbof_content=size(mat_content,2); nbof_videotype=size(videodata.alpha,1); nbof_resol=size(videodata.alpha,2);
nbof_endnodes=topologydata.nbof_fixedendnodes+topologydata.nbof_mobendnodes;
% % add nb of rqst per end node as feature to each content
mat_content=sparse([mat_content;zeros(nbof_endnodes,nbof_content)]);
vems=videodata.vems;
ind_vnonzero=find(vems>0);
for ind_ems=ind_vnonzero,
    e=ceil(ind_ems/(nbof_content*nbof_resol)); m=ceil((ind_ems-(e-1)*(nbof_content*nbof_resol))/nbof_resol);
    mat_content(5+e,m)=mat_content(5+e,m)+vems(ind_ems);
end;

%--- Transform each feature into the right type: type as normalized rank,
%dur and size as z-score, flag4K left as binary

mat_content_transf=sparse(zeros(5+nbof_endnodes,nbof_content));
mat_content_transf(1,:)=mat_content(1,:);
mat_content_transf(2,:)=(mat_content(2,:)-1)/(nbof_videotype-1);
std_dur=std(mat_content(3,:)); mean_dur=mean(mat_content(3,:));
mat_content_transf(3,:)=(mat_content(3,:)-mean_dur)/std_dur;
std_size=std(mat_content(4,:)); mean_size=mean(mat_content(4,:));
mat_content_transf(4,:)=(mat_content(4,:)-mean_size)/std_size;
mat_content_transf(5,:)=mat_content(5,:);
mean_e=zeros(nbof_endnodes,1); std_e=zeros(nbof_endnodes,1); 
for e=1:nbof_endnodes,
    std_e(e)=std(mat_content(5+e,:)); mean_e(e)=mean(mat_content(5+e,:));
    if std_e(e)>0,
        mat_content_transf(5+e,:)=(mat_content(5+e,:)-mean_e(e))/std_e(e);
    end;
end;
vec_mean=[mean_dur;mean_size;mean_e];
vec_std=[std_dur;std_size;std_e];

%--- Perform kmeans with Euclidean distance
max_nbof_content=max_catalog; %10; %floor(nbof_content/100);
X=mat_content_transf(2:5+nbof_endnodes,:); X=X';
[idx,C]=kmeans(X,max_nbof_content,'EmptyAction','drop','Replicates',1,'Start','sample'); %'MaxIter',1,'Start',C
mat_synth=C';
ind_to_drop=isnan(mat_synth(1,:));
mat_synth=mat_synth(:,logical(1-ind_to_drop));
ind_centr=(1:length(ind_to_drop)); ind_centr=ind_centr(logical(1-ind_to_drop));
for i=1:nbof_content,
    j=find(ind_centr==idx(i));
    idx(i)=j;
end;

%--- Replicate centroids so that the total size per centroid is less than
%the min HDD capa, then set the size of centroid to the sum of sizes in
%this cluster

nbof_clusters_initial=size(mat_synth,2);
for ind_centr=1:nbof_clusters_initial,
    nbof_clusters=size(mat_synth,2);
    bin_members=logical((idx==ind_centr));
    sumsize_ofcluster=sum(mat_content(4,bin_members));
    ind_members=find(idx==ind_centr);
    if sumsize_ofcluster>min(infrastructuredata.nodeStorage),
        nbof_partitions=ceil(sumsize_ofcluster/min(infrastructuredata.nodeStorage));
        partition_attrib=randi(nbof_partitions,length(ind_members),1);
        mat_synth=[mat_synth,repmat(mat_synth(:,ind_centr),1,nbof_partitions-1)];
        clusters_ind=[ind_centr;nbof_clusters+(1:nbof_partitions-1)'];
        idx(bin_members)=clusters_ind(partition_attrib);
    end;
end;

%--- Create synthetic content pertaining to the input space
new_nbof_content=size(mat_synth,2);
mat_synth=[1:new_nbof_content;mat_synth];
full_centroidsnorm=mat_synth;
mat_synth=mat_synth(1:5,:);
% flag as the majority of the respective cluster:
for clust_ind=1:new_nbof_content,
    nbof_flag0=sum(mat_content(5,logical(idx==clust_ind))==0);
    nbof_flag1=sum(mat_content(5,logical(idx==clust_ind))==1);
    mat_synth(5,clust_ind)=nbof_flag1>nbof_flag0;
end;    
% mat_synth(5,:)=round(mat_synth(5,:)); 
if sum(mat_synth(5,:)>1|mat_synth(5,:)<0)>0, error('pb at 5'); end;
% mat_synth(4,:)=mat_synth(4,:)*std_size+mean_size;
% % Set the content size of the centroid to the sum of the members
for clust_ind=1:new_nbof_content,
    bin_members=logical((idx==clust_ind));
    mat_synth(4,clust_ind)=sum(mat_content(4,bin_members));
end;
mat_synth(3,:)=mat_synth(3,:)*std_dur+mean_dur;
mat_synth(2,:)=round(mat_synth(2,:)*(nbof_videotype-1)+1); mat_synth(2,:)=min(max(mat_synth(2,:),1),nbof_videotype);
if sum(mat_synth(2,:)>nbof_videotype|mat_synth(2,:)<1)>0, error('pb at 2'); end;

%--- Rewrite mat_content and mat_trace with new content
mat_trace=videodata.mat_trace;
%----Changed here to match what's done in the simulator---% mat_trace(:,3)=idx(mat_trace(:,3));
videodata.vec_mean=vec_mean;
videodata.vec_std=vec_std;
videodata.full_centroidsnorm=full_centroidsnorm;
videodata.nbof_videotype=nbof_videotype;
for trace_ind=1:size(mat_trace,1),
    type=mat_trace(trace_ind,5); watchingdur=mat_trace(trace_ind,7); siz=mat_trace(trace_ind,6); s=mat_trace(trace_ind,4); e=mat_trace(trace_ind,2);
    vec_rqst=[type;watchingdur;siz;(s>3);e];
    mat_trace(trace_ind,3)=find_centroid(videodata,vec_rqst);
end;
%-------------------
mat_trace(:,5)=mat_synth(2,mat_trace(:,3));
mat_trace(:,6)=mat_synth(4,mat_trace(:,3));

%--- Computation of vems (number of parallel requests)--
vems=sparse(1,nbof_endnodes*new_nbof_content*nbof_resol);
wdems=sparse(1,nbof_endnodes*new_nbof_content*nbof_resol);
occur_ems=sparse(1,nbof_endnodes*new_nbof_content*nbof_resol);
trace_time=mat_trace(:,1);
for trace_ind=1:size(mat_trace,1),
    e=mat_trace(trace_ind,2); m=mat_trace(trace_ind,3); s=mat_trace(trace_ind,4);
    ind_ems=(e-1)*new_nbof_content*nbof_resol+(m-1)*nbof_resol+s;
    vems(ind_ems)=vems(ind_ems)+mat_trace(trace_ind,7)*60/(trace_time(end)-trace_time(1));
    wdems(ind_ems)=wdems(ind_ems)+mat_trace(trace_ind,7)*60;
    occur_ems(ind_ems)=occur_ems(ind_ems)+1;
end;
wdems(occur_ems>0)=wdems(occur_ems>0)./occur_ems(occur_ems>0);
%----
%--- Number of elements per cluster (weight)
cluster_weight=zeros(1,new_nbof_content);
for clust_ind=1:new_nbof_content,
    cluster_weight(clust_ind)=sum(idx==clust_ind);
end;
%----
videodata.vems=vems;
videodata.wdems=wdems;
videodata.mat_content=mat_synth;
videodata.mat_trace=mat_trace;
videodata.cluster_weight=cluster_weight;
videodata.vec_mean=vec_mean;
videodata.vec_std=vec_std;
videodata.full_centroidsnorm=full_centroidsnorm;
videodata.nbof_videotype=nbof_videotype;

end

function m=find_centroid(videodata_foroptim,vec_rqst)

%--- Transform each feature into the right type: type as normalized rank,
%dur and size as z-score, flag4K left as binary

if isfield(videodata_foroptim,'vec_mean'),

vec_mean=videodata_foroptim.vec_mean;
vec_std=videodata_foroptim.vec_std;
centroidsnorm=videodata_foroptim.full_centroidsnorm;
mean_dur=vec_mean(1); mean_size=vec_mean(2); mean_e=vec_mean(3:end); nbof_endnodes=length(mean_e);
std_dur=vec_std(1); std_size=vec_std(2); std_e=vec_std(3:end);
nbof_videotype=videodata_foroptim.nbof_videotype;

type=vec_rqst(1); watchingdur=vec_rqst(2); siz=vec_rqst(3); flag4K=(vec_rqst(4)>3); e=vec_rqst(5);

type_transf=(type-1)/(nbof_videotype-1);
dur_transf=(watchingdur-mean_dur)/std_dur;
size_transf=(siz-mean_size)/std_size;
flag4K_transf=flag4K;
e_origin=zeros(nbof_endnodes,1); e_origin(e)=1;

input_norm=[type_transf;dur_transf;size_transf;flag4K_transf;e_origin];
vec_diff=repmat(input_norm,1,size(centroidsnorm,2))-centroidsnorm(2:size(centroidsnorm,1),:);
dist_centroids=diag(sqrt(vec_diff'*vec_diff));

[md,m]=min(dist_centroids);

else,
    m=vec_rqst(6);
end;

end