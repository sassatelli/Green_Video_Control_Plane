%v3: with caching only at PoP and BBU hotel--> 
%   sum[m in M] s_m h_mi <= S_i*z_ie, for each (i in N/PoP)
%   sum[m in M] s_m h_mi <= S_i, for i = PoP
function [sol, slack] = VCRAN_MILP_v3_bkg(topologydata,videodata,infrastructuredata, gamma)

    % Dimensions
    E_M = topologydata.nbof_mobendnodes; % numMobileEndNodes;
    E_F = topologydata.nbof_fixedendnodes; % numFixEndNodes;
    E = E_M+E_F;  % numEndNodes;
    N = size(topologydata.pathInfo.bin_nodesInPath,1);
    L = size(topologydata.pathInfo.bin_edgesInPath,1);
    M = size(videodata.mat_content,2);%     numContents (that is not the number of content types);
    S = size(videodata.alpha,2);%     numResols;
    P = topologydata.pathInfo.P;
        
    %Indeces
    bin_PoP_Id = (topologydata.nodeTable(:,3)==0);
    if sum(bin_PoP_Id)>1, error('More than one PoP'); end
    bin_NOT_mobNodes_Ids = (topologydata.nodeTable(:,3)~=4);
    bin_fixNodes_Ids = (topologydata.nodeTable(:,3)==3);
    bin_mobNodes_Ids = (topologydata.nodeTable(:,3)==4);
    fixNodes_Ids = find(topologydata.nodeTable(:,3)==3);
    mobNodes_Ids = find(topologydata.nodeTable(:,3)==4);
    
    %contents catalog
%     v_ems = [kron(ones(E_F,1), mat2vct(videoInfo.videosPerFixPoint_byContDev));...
%              kron(ones(E_M,1), mat2vct(videoInfo.videosPerCellSite_byContDev))];
    v_ems = videodata.vems';% to col
    % We transform all the content-type-dependnt info into individual content-dependant info
    b_min_ms = videodata.bmin(videodata.mat_content(2,:),:); 
    b_max_ms = videodata.bmax(videodata.mat_content(2,:),:);
    b_min_ems = kron(ones(E,1), mat2vct(b_min_ms));
    b_max_ems = kron(ones(E,1), mat2vct(b_max_ms));
    QoE_ms = videodata.alpha(videodata.mat_content(2,:),:);
    QoE_ems = kron(ones(E,1), mat2vct(QoE_ms));
    for flag4K = 0:size(videodata.d_tc,1)-1,
        switch flag4K 
            case 0 %not flag4K
                d_tc_ms_not4k = squeeze(videodata.d_tc(flag4K+1,:,videodata.mat_content(2,:)))';
                d_tc_ms_not4k((videodata.mat_content(5,:)==1)',:)=0; %removing 4k
            case 1 %flag4K
                d_tc_ms_4k = squeeze(videodata.d_tc(flag4K+1,:,videodata.mat_content(2,:)))';
                d_tc_ms_4k(not(videodata.mat_content(5,:))',:)=0; %removing not 4k
        end
    end
    d_tc_ms =mat2vct(d_tc_ms_4k + d_tc_ms_not4k);
    contentSize = videodata.mat_content(4,:);
    % min background traff per (e,m,s)
    min_backgTraff_ems=sparse(zeros(size(videodata.vems)));
    indsup0=logical(videodata.vems>0);
    allvec=videodata.beta*(videodata.vems./videodata.wdems).*kron(ones(1,E),kron(contentSize,ones(1,S)));
    min_backgTraff_ems(indsup0) = allvec(indsup0); % otherwise divide by zero and NaN

    %unknown content
    b_min_s_unknown = mean(b_min_ms)'; %col vector
    b_max_s_unknown = mean(b_max_ms)'; %col vector
    QoE_unknown = mean(QoE_ms)'; %col vector
    b_min_es = kron(ones(E,1), b_min_s_unknown);
    b_max_es = kron(ones(E,1), b_max_s_unknown);
    QoE_eus = kron(ones(E,1), QoE_unknown);
    d_tc_us = mean(d_tc_ms_4k)'+mean(d_tc_ms_not4k)';
    
    
    %Decisions Variables

    % f_emsi --> Continous var btw 0 and 1   
    offset_f_emsi =0;
    length_f_emsi = E*M*S*N;
    cost_f_emsi = sparse(length_f_emsi,1);
    lb_f_emsi = sparse(length_f_emsi,1);
    ub_f_emsi = ones(length_f_emsi,1);
    ctype_f_emsi = repmat('C', 1, length_f_emsi);
    
    % vf_eusi --> Continous var btw 0 and 1   
    offset_vf_eusi = offset_f_emsi + length_f_emsi; 
    length_vf_eusi = E*1*S*N;
    cost_vf_eusi = sparse(length_vf_eusi,1);
    lb_vf_eusi = sparse(length_vf_eusi,1);
    ub_vf_eusi = Inf*ones(length_vf_eusi,1);
    ctype_vf_eusi = repmat('C', 1, length_vf_eusi);
    
    % x_ems_p --> Continous var btw 0 and inf (traffic units)    
    offset_x_ems_p = offset_vf_eusi + length_vf_eusi;
    length_x_ems_p = E*M*S*P;
    cost_x_ems_p = sparse(length_x_ems_p,1);
    lb_x_ems_p = sparse(length_x_ems_p,1);
    ub_x_ems_p = Inf*ones(length_x_ems_p,1);
    ctype_x_ems_p = repmat('C', 1, length_x_ems_p);
    
    % x_ems_ij --> Continous var btw 0 and inf (traffic units)  
    UB_videoTraff = sum(v_ems)*max(max(videodata.bmax));
    offset_x_ems_ij = offset_x_ems_p+length_x_ems_p;
    length_x_ems_ij = E*M*S*N^2;
    cost_x_ems_ij = gamma*kron(QoE_ems, ones(N*N,1));
    lb_x_ems_ij = sparse(length_x_ems_ij,1);
%     ub_x_ems_ij = sparse(length_x_ems_ij,1); 
    ub_x_ems_ij_fix = sparse(E_F*M*S*N^2,1); 
    % if e in E_f, we cannot deport BBUs, then, for j =~ e, x_ems_ij = 0
    for ef = 1:E_F,
        n = fixNodes_Ids(ef);
%         aux = sparse(N,1);aux(n) = UB_videoTraff;
        aux = sparse(n,1,UB_videoTraff,N,1);
        ub_x_ems_ij_fix((ef-1)*M*S*N^2 + 1 : ef*M*S*N^2) = kron(ones(M*S*N,1),aux);
    end
    ub_x_ems_ij = [ub_x_ems_ij_fix; UB_videoTraff*ones(E_M*M*S*N^2,1)]; 
    ctype_x_ems_ij = repmat('C', 1, length_x_ems_ij);
    
       
    % x_eus_p --> Continous var btw 0 and inf (traffic units)    
    offset_x_eus_p = offset_x_ems_ij + length_x_ems_ij;
    length_x_eus_p = E*(1)*S*P;
    cost_x_eus_p = sparse(length_x_eus_p,1);
    lb_x_eus_p = sparse(length_x_eus_p,1);
    ub_x_eus_p = Inf*ones(length_x_eus_p,1);
    ctype_x_eus_p = repmat('C', 1, length_x_eus_p);
    
    % x_eus_ij --> Continous var btw 0 and inf (traffic units)  
    offset_x_eus_ij = offset_x_eus_p+length_x_eus_p;
    length_x_eus_ij = E*(1)*S*N^2;
    cost_x_eus_ij =  sparse(length_x_eus_ij,1);
%     cost_x_eus_ij = gamma*kron(QoE_eus, ones(N*N,1));
    lb_x_eus_ij = sparse(length_x_eus_ij,1);
    ub_x_eus_ij_fix = sparse(E_F*(1)*S*N^2,1); 
    % if e in E_f, we cannot deport BBUs, then, for j =~ e, x_eus_ij = 0
    for e = 1:E_F,
        n = fixNodes_Ids(e);
%         aux = sparse(N,1);aux(n) = UB_videoTraff;
        aux = sparse(n,1,UB_videoTraff,N,1);
        ub_x_eus_ij_fix((e-1)*(1)*S*N^2 + 1 : e*(1)*S*N^2) = kron(ones((1)*S*N,1),aux);
    end
    ub_x_eus_ij = [ub_x_eus_ij_fix; UB_videoTraff*ones(E_M*1*S*N^2,1)]; 
    ctype_x_eus_ij = repmat('C', 1, length_x_eus_ij);
    
    % y_p --> Continous var btw 0 and inf (traffic units)  
%     UB_backgrTraff = sum(min_backgTraff_ems)*N;
    UB_backgrTraff = Inf;
    offset_y_p = offset_x_eus_ij+length_x_eus_ij;
    length_y_p = P;
    cost_y_p = sparse(length_y_p,1);
    lb_y_p = sparse(length_y_p,1);
    bin_pathsFromPoP = topologydata.pathInfo.bin_initNodes(bin_PoP_Id,:);
    ub_y_p=sparse(zeros(size(bin_pathsFromPoP')));
    ub_y_p(logical(bin_pathsFromPoP')) = UB_backgrTraff;
    ctype_y_p = repmat('C', 1, length_y_p);
    
    % z_ej --> Binary var
    offset_z_ej = offset_y_p+length_y_p;
    length_z_ej = N*E_M; %only  for mobile nodes
    cost_z_ej = sparse(length_z_ej,1);
    lb_z_ej = sparse(length_z_ej,1);    
    %if e is a mobile end node, and there is no CPRI path btw e and i, z_ei
    %= 0, we cannot deport BBUs 
    %NOTE: we assume that in topologydata.CPRI_linkTable, there are no CPRI paths between
    %end nodes, only btw a mobile end node and an intermediary node.
    %NOTE: in a directed graph, the adjacency matrix indicates if there is a 
    % link from j to e, but z_ej is sorted ej. 
     %if e is a mobile end node, and i is other end node, z_ei = 0,
    %otherwise z_ee = 1,    
    CPRI_adjacencyMat = sparse(topologydata.CPRI_linkTable(:,1), topologydata.CPRI_linkTable(:,2), 1, N, N);
    ub_z_ej = mat2vct((CPRI_adjacencyMat(:,bin_mobNodes_Ids))');
    ctype_z_ej = repmat('B', 1, length_z_ej); 
%     CPRI_adjacencyMat =vct2mat(any(CPRI_pathInfo.bin_nodePairs,2), N, N);
%     %if e is a mobile end node, and i is other end node, z_ei = 0,
%     %otherwise z_ee = 1,
%     CPRI_adjacencyMat(sub2ind(size(CPRI_adjacencyMat),mobNodes_Ids,mobNodes_Ids))=1;

    % z_j --> Binary var 
    offset_z_j = offset_z_ej+length_z_ej;
    length_z_j = N;
    cost_z_j = sparse(length_z_j,1);
    lb_z_j = sparse(length_z_j,1);
    ub_z_j = ones(length_z_j,1);
    ctype_z_j = repmat('B', 1, length_z_j);
    
    % h_mi --> Continous var btw 0 and 1  
    offset_h_mi = offset_z_j+length_z_j;
    length_h_mi = M*N;
    cost_h_mi = sparse(length_h_mi,1);
    lb_h_mi = sparse(length_h_mi,1);
    ub_h_mi = ones(length_h_mi,1);
    ctype_h_mi = repmat('C', 1, length_h_mi);
    
    % g_ipr_i --> Integer var
    offset_g_ipr_i = offset_h_mi+length_h_mi;
    length_g_ipr_i = N;
    cost_g_ipr_i = -infrastructuredata.IPRpower*ones(length_g_ipr_i,1);
    lb_g_ipr_i = sparse(length_g_ipr_i,1);
    ub_g_ipr_i = ones(length_g_ipr_i,1);
    ctype_g_ipr_i = repmat('I', 1, length_g_ipr_i);
    
    % g_egs_i --> Integer var
    offset_g_egs_i = offset_g_ipr_i+length_g_ipr_i;
    length_g_egs_i = N;
    cost_g_egs_i = -infrastructuredata.EGSpower*ones(length_g_egs_i,1);
    lb_g_egs_i = sparse(length_g_egs_i,1);
    ub_g_egs_i = ones(length_g_egs_i,1);
    ctype_g_egs_i = repmat('I', 1, length_g_egs_i);
    
    % g_srv_i --> Integer var
    offset_g_srv_i = offset_g_egs_i+length_g_egs_i;
    length_g_srv_i = N;
    cost_g_srv_i = -infrastructuredata.SRVpower*ones(length_g_srv_i,1);
    lb_g_srv_i = sparse(length_g_srv_i,1);
    ub_g_srv_i = infrastructuredata.G_n;
    ctype_g_srv_i = repmat('I', 1, length_g_srv_i);
    
       
    % t_bbu_i --> Integer var
    offset_t_bbu_i = offset_g_srv_i+length_g_srv_i;
    length_t_bbu_i = N;
    cost_t_bbu_i = -infrastructuredata.VMpower*ones(length_t_bbu_i,1);
    lb_t_bbu_i = sparse(length_t_bbu_i,1);
    ub_t_bbu_i = infrastructuredata.K.*infrastructuredata.G_n;
    ctype_t_bbu_i = repmat('I', 1, length_t_bbu_i);

    
    % t_vtc_i --> Integer var
    offset_t_vtc_i = offset_t_bbu_i+length_t_bbu_i;
    length_t_vtc_i = N;
    cost_t_vtc_i = -infrastructuredata.VMpower*ones(length_t_vtc_i,1);
    lb_t_vtc_i = sparse(length_t_vtc_i,1);
    ub_t_vtc_i = infrastructuredata.K.*infrastructuredata.G_n;
    ctype_t_vtc_i = repmat('I', 1, length_t_vtc_i);
    
    
    numVars = length_vf_eusi + length_f_emsi + length_x_ems_p + length_x_ems_ij + length_x_eus_p + length_x_eus_ij + length_y_p + length_z_ej + length_z_j + length_h_mi + length_g_ipr_i + length_g_egs_i + length_g_srv_i + length_t_bbu_i + length_t_vtc_i;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
    %Constraints
    fprintf ('Creating constraints ... \n');

    %Min QoE  
    %sum[j in N] x_ems_ij >= b_min_ms * v_ems * f_emsi, for each (e in E,m in M+u, s in S,i in N)
    numCtrs = E*M*S*N; 
    A_minQoE = sparse(numCtrs,numVars);
    A_minQoE_f_emsi = kron(spdiags(b_min_ems.*v_ems,0,E*M*S,E*M*S),speye(N));
    A_minQoE_x_ems_ij = kron(speye(E*M*S*N), ones(1,N)); 
    A_minQoE(:,1:length_f_emsi) = -A_minQoE_f_emsi;
    %length_x_ems_ij_minus_x_eus_ij =  E*(M)*S*N^2;
    A_minQoE(:,offset_x_ems_ij+1:offset_x_ems_ij+length_x_ems_ij) = A_minQoE_x_ems_ij;
    lhs_minQoE = sparse(numCtrs,1);
    rhs_minQoE = Inf*ones(numCtrs,1);
    clear A_minQoE_f_emsi A_minQoE_x_ems_ij;

    %Max QoE  
    %sum[j in N] x_ems_ij >= b_max_ms * v_ems * f_emsi, for each (e in E,m in M+u, s in S,i in N)
    numCtrs = E*M*S*N; 
    A_maxQoE = sparse(numCtrs,numVars);
    A_maxQoE_f_emsi = kron(spdiags(b_max_ems.*v_ems,0,E*M*S,E*M*S),speye(N));
    A_maxQoE_x_ems_ij = kron(speye(E*M*S*N), ones(1,N)); 
    A_maxQoE(:,1:length_f_emsi) = -A_maxQoE_f_emsi;
    A_maxQoE(:,offset_x_ems_ij+1:offset_x_ems_ij+length_x_ems_ij) = A_maxQoE_x_ems_ij;
    lhs_maxQoE = -Inf(numCtrs,1);
    rhs_maxQoE = sparse(numCtrs,1);
    clear A_maxQoE_f_emsi A_maxQoE_x_ems_ij;
    
    %Min QoE vf_eus 
    %sum[j in N] x_eus_ij >= b_min_s * vf_eusi, for each (e in E, s in S,i in N)
    numCtrs = E*S*N; 
    A_minQoE_u = sparse(numCtrs,numVars);
    A_minQoE_u_vf_eusi = kron(spdiags(b_min_es,0,E*1*S,E*1*S),speye(N));
    A_minQoE_u_x_eus_ij = kron(speye(E*1*S*N), ones(1,N)); 
    A_minQoE_u(:,offset_vf_eusi+ 1:offset_vf_eusi+length_vf_eusi) = -A_minQoE_u_vf_eusi;
    A_minQoE_u(:,offset_x_eus_ij+1:offset_x_eus_ij+length_x_eus_ij) = A_minQoE_u_x_eus_ij;
    lhs_minQoE_u = sparse(numCtrs,1);
    rhs_minQoE_u = Inf*ones(numCtrs,1);
    clear A_minQoE_u_vf_eusi A_minQoE_u_x_eus_ij;
    
    %Max QoE vf_eus 
    %sum[j in N] x_eus_ij <= b_max_s * vf_eusi, for each (e in E, s in S,i in N)
    numCtrs = E*S*N; 
    A_maxQoE_u = sparse(numCtrs,numVars);
    A_maxQoE_u_vf_eusi = kron(spdiags(b_max_es,0,E*1*S,E*1*S),speye(N));
    A_maxQoE_u_x_eus_ij = kron(speye(E*1*S*N), ones(1,N)); 
    A_maxQoE_u(:,offset_vf_eusi+ 1:offset_vf_eusi+length_vf_eusi) = -A_maxQoE_u_vf_eusi;
    A_maxQoE_u(:,offset_x_eus_ij+1:offset_x_eus_ij+length_x_eus_ij) = A_maxQoE_u_x_eus_ij;
    lhs_maxQoE_u = -Inf(numCtrs,1);
    rhs_maxQoE_u = sparse(numCtrs,1);
    clear A_maxQoE_u_vf_eusi A_maxQoE_u_x_eus_ij;
    
    %Share video caches 
    %sum[i in N] f_emsi <= 1, for each (e in E,m in M+u, s in S)
    numCtrs = E*M*S; 
    A_shareVidSrc = sparse(numCtrs,numVars);
    A_shareVidSrc_f_emsi = kron(speye(E*M*S),ones(1,N));
    A_shareVidSrc(:,1:length_f_emsi) = A_shareVidSrc_f_emsi;
    lhs_shareVidSrc = sparse(numCtrs,1);
    rhs_shareVidSrc = ones(numCtrs,1);
    clear A_shareVidSrc_f_emsi;
    
    %Relationship btw f_emsi and h_mi
    % f_emsi <= h_mi, for each (e in E,m in M+u, s in S, i in N)
    numCtrs = E*M*S*N; 
    A_hitRatio = sparse(numCtrs,numVars);
    A_hitRatio_f_emsi = speye(length_f_emsi);
    A_hitRatio_h_mi = kron(kron(ones(E,1),kron(speye(M),ones(S,1))),speye(N));
    A_hitRatio(:, 1:+length_f_emsi) = A_hitRatio_f_emsi;
    A_hitRatio(:,offset_h_mi+1:offset_h_mi+length_h_mi) = -A_hitRatio_h_mi;
    lhs_hitRatio = -Inf(numCtrs,1);
    rhs_hitRatio = sparse(numCtrs,1);
    clear A_hitRatio_f_emsi A_hitRatio_h_mi
    
    %Storage Capacity 
%      with caching only at PoP and BBU hotel--> 
%   sum[m in M] s_m h_mi <= S_i, for i = PoP
%   sum[m in M] s_m h_mi <= S_i*z_i, for each (i in N/PoP)
    numCtrs = N; 
    A_storCap = sparse(numCtrs, numVars);
    contentSize = videodata.mat_content(4,:);
    A_storCap_h_mi = kron(contentSize,speye(N));  
    A_storCap_z_j = [sparse(1,N); 
                    sparse(N-1,1) spdiags(infrastructuredata.nodeStorage(2:N),0,N-1,N-1)];% that appears only for the last N-1 ctrs  
    A_storCap(:,offset_h_mi+1:offset_h_mi+length_h_mi) = A_storCap_h_mi;
    A_storCap(:,offset_z_j+1:offset_z_j+length_z_j) = -A_storCap_z_j;
    lhs_storCap = -Inf(numCtrs,1);
    rhs_storCap = [infrastructuredata.nodeStorage(1); 
                    sparse(N-1,1)] ;
    %----allow fixed end nodes to be caches
    rhs_storCap = [infrastructuredata.nodeStorage(1); 
                    sparse(N-1-E,1);infrastructuredata.nodeStorage(N-E+1:N-E+E_F);sparse(E_M,1)] ;
    %--------
    clear A_storCap_h_mi A_storCap_z_ej
  
    %Indicator variable about BBU deportation LB z_i: 1 if node i has a BBU from
    %any node e_m
    %sum[e in E_M] z_ei <= N*z_i, for each (i in N)
    numCtrs = N;  
    A_BBUzi_LB = sparse(numCtrs, numVars);
    A_BBUzi_LB_z_ej = kron(ones(1,E_M), speye(N,N));
    A_BBUzi_LB_z_j = speye(N,N);
    A_BBUzi_LB(:,offset_z_ej+1:offset_z_ej+length_z_ej) = A_BBUzi_LB_z_ej;
    A_BBUzi_LB(:,offset_z_j+1:offset_z_j+length_z_j) =  -N*A_BBUzi_LB_z_j;
    clear A_BBUzi_LB_z_ej A_BBUzi_LB_z_j;
    lhs_BBUzi_LB = -Inf*ones(numCtrs,1);
    rhs_BBUzi_LB = sparse(numCtrs,1);
    
     %Indicator variable about BBU deportation UB z_i: 1 if node i has a BBU from
    %any node e_m
    %  z_i <= sum[e in E_M] z_ei , for each (i in N)
    numCtrs = N;  
    A_BBUzi_UB = sparse(numCtrs, numVars);
    A_BBUzi_UB_z_ej = kron(ones(1,E_M), speye(N,N));
    A_BBUzi_UB_z_j = speye(N,N);
    A_BBUzi_UB(:,offset_z_j+1:offset_z_j+length_z_j) =  A_BBUzi_UB_z_j;
    A_BBUzi_UB(:,offset_z_ej+1:offset_z_ej+length_z_ej)= - A_BBUzi_UB_z_ej;
    clear A_BBUzi_UB_z_ej A_BBUzi_UB_z_j;
    lhs_BBUzi_UB = -Inf*ones(numCtrs,1);
    rhs_BBUzi_UB = sparse(numCtrs,1);
    
    %Video Traffic Flow Conservation 
    %sum[ p in P_ij] x_ems_p = x_ems_ij , for each (e in E, s in S, m in M,i in N, j in N) 
    numCtrs = E*(M)*S*N*N;  
    A_vidCons = sparse(numCtrs,numVars);
    A_vidCons_x_ems_p = kron(speye(E*(M)*S), topologydata.pathInfo.bin_nodePairs);  
    A_vidCons_x_ems_ij = speye(numCtrs);
    A_vidCons(:, offset_x_ems_p+1 : offset_x_ems_p+length_x_ems_p) = A_vidCons_x_ems_p;
    A_vidCons(:, offset_x_ems_ij+1 :offset_x_ems_ij+length_x_ems_ij) = -A_vidCons_x_ems_ij;
    lhs_vidCons = sparse(numCtrs,1);
    rhs_vidCons = sparse(numCtrs,1);
    clear A_vidCons_x_ems_p A_vidCons_x_ems_ij
    
    %Video Traffic Flow Conservation - content u
    %sum[ p in P_ij] x_eus_p = x_eus_ij , for each (e in E, s in S, u,i in N, j in N) 
    numCtrs = E*(1)*S*N*N;  
    A_vidCons_u = sparse(numCtrs,numVars);
    A_vidCons_u_x_eus_p = kron(speye(E*(1)*S), topologydata.pathInfo.bin_nodePairs);  
    A_vidCons_u_x_eus_ij = speye(numCtrs);
    A_vidCons_u(:, offset_x_eus_p+1 : offset_x_eus_p+length_x_eus_p) = A_vidCons_u_x_eus_p;
    A_vidCons_u(:, offset_x_eus_ij+1 :offset_x_eus_ij+length_x_eus_ij) = -A_vidCons_u_x_eus_ij;
    lhs_vidCons_u = sparse(numCtrs,1);
    rhs_vidCons_u = sparse(numCtrs,1);
    clear A_vidCons_u_x_eus_p A_vidCons_u_x_eus_ij
    
    %Background Traffic Flow Conservation 
    %sum[p in P_PoPi] y_p >= sum[ems in EMS](1-h*im)s_m(v_ems/wd_ems) f_iems, for each (i in N)
    numCtrs = N;  
    A_backgCons = sparse(numCtrs,numVars); 
    A_backgCons_f_emsi = kron(min_backgTraff_ems,speye(N));
    A_backgCons_y_p = kron(ones(N,1),bin_pathsFromPoP).*topologydata.pathInfo.bin_endNodes;
    A_backgCons(:,offset_f_emsi+1:offset_f_emsi+length_f_emsi) = A_backgCons_f_emsi;
    A_backgCons(:,offset_y_p+1:offset_y_p+length_y_p) = - A_backgCons_y_p;
    %----to force BBUs to have minimum bw from PoP at least
    A_backgCons(:,offset_z_j+1:offset_z_j+length_z_j) = speye(N)*infrastructuredata.WDMcap/1e4;
    %-------
    lhs_backgCons = -Inf(numCtrs,1);
    rhs_backgCons = sparse(N,1);
    %----to force fix end nodes to have minimum bw from PoP at least
    rhs_backgCons(N-E+1:N-E+E_F) = -infrastructuredata.WDMcap/1e4;
    %-------
    clear A_backgCons_y_p A_backgCons_f_emsi

    
    %LTE Capacity (BBU placement) 
    %sum[i in N, s in S m in M+u, p in P_ij] x_ems_p = C_LTE_e z_ej, for each (e in Em,j in N)
    numCtrs = E_M*N;  
    A_LTEcap = sparse(numCtrs,numVars);
    A_LTEcap_x_ems_p = [sparse(numCtrs,E_F*(M)*S*P), kron(kron(speye(E_M,E_M),ones(1,(M)*S)),topologydata.pathInfo.bin_endNodes)]; 
    A_LTEcap_x_eus_p = [sparse(numCtrs,E_F*(1)*S*P), kron(kron(speye(E_M,E_M),ones(1,(1)*S)),topologydata.pathInfo.bin_endNodes)]; 
    A_LTEcap_z_ej = infrastructuredata.LTEcap*speye(length_z_ej,length_z_ej);
    A_LTEcap(:,offset_x_ems_p+1:offset_x_ems_p+length_x_ems_p)=A_LTEcap_x_ems_p;
    A_LTEcap(:,offset_x_eus_p+1:offset_x_eus_p+length_x_eus_p)=A_LTEcap_x_eus_p;
    A_LTEcap(:,offset_z_ej+1:offset_z_ej+length_z_ej)= -A_LTEcap_z_ej;
    clear A_LTEcap_x_ems_p A_LTEcap_x_eus_p  A_LTEcap_z_ej;
    lhs_LTEcap = -Inf(numCtrs,1);
    rhs_LTEcap = sparse(numCtrs,1);
      
    %WDM Capacity 
    %sum[p in P_l] sum [e in E, s in S, m in M+u] x_ems_p + y_p = C_WDM, for each (l in L_WDM)
    numCtrs = L;  
    A_WDMcap = sparse(numCtrs,numVars);
    A_WDMcap_x_ems_p = kron(ones(1,E*(M)*S),topologydata.pathInfo.bin_edgesInPath); 
    A_WDMcap_x_eus_p = kron(ones(1,E*(1)*S),topologydata.pathInfo.bin_edgesInPath); 
    A_WDMcap_y_p = topologydata.pathInfo.bin_edgesInPath;
    A_WDMcap(:,offset_x_ems_p+1:offset_x_ems_p+length_x_ems_p) = A_WDMcap_x_ems_p;
    A_WDMcap(:,offset_x_eus_p+1:offset_x_eus_p+length_x_eus_p) = A_WDMcap_x_eus_p;
    A_WDMcap(:,offset_y_p+1:offset_y_p+length_y_p) = A_WDMcap_y_p;
    clear A_WDMcap_x_ems_p A_WDMcap_x_eus_p A_WDMcap_y_p;
    lhs_WDMcap = sparse(numCtrs,1);
    rhs_WDMcap = infrastructuredata.WDMcap*topologydata.WDM_linkTable(:,3); %col 3: # virtual links in the bundle
%     rhs_WDMcap = infrastructuredata.WDMcap*ones(numCtrs,1);
        
    %IP Router Capacity 
    %sum[p in P_n] sum [e in E, s in S, m in M+u] x_ems_p +  y_p <= C_IPR*g_ipr_i, for each (n in N)
    numCtrs = N;  
    A_IPRcap = sparse(numCtrs, numVars);
    A_IPRcap_x_ems_p = kron(ones(1,E*(M)*S),topologydata.pathInfo.bin_nodesInPath); 
    A_IPRcap_x_eus_p = kron(ones(1,E*(1)*S),topologydata.pathInfo.bin_nodesInPath); 
    A_IPRcap_y_p = topologydata.pathInfo.bin_nodesInPath;
    A_IPRcap_g_ipr_i = -infrastructuredata.IPRcap*speye(numCtrs);
    A_IPRcap(:,offset_x_ems_p+1:offset_x_ems_p+length_x_ems_p) = A_IPRcap_x_ems_p; 
    A_IPRcap(:,offset_x_eus_p+1:offset_x_eus_p+length_x_eus_p) = A_IPRcap_x_eus_p; 
    A_IPRcap(:,offset_y_p+1:offset_y_p+length_y_p) = A_IPRcap_y_p; 
    A_IPRcap(:,offset_g_ipr_i+1:offset_g_ipr_i+length_g_ipr_i)= A_IPRcap_g_ipr_i;
    lhs_IPRcap = -Inf*ones(numCtrs,1);
    rhs_IPRcap = sparse(numCtrs,1);
    clear A_IPRcap_x_ems_p A_IPRcap_x_eus_p A_IPRcap_y_p A_IPRcap_g_ipr_i;
    
%   %Ethernet Gigaswitch Capacity 
    %sum[p in P_out_n+P_in_n] sum [e in E, s in S, m in M+u] x_ems_p +  y_p <= C_EGS*g_egs_i, for each (n in N)
    numCtrs = N;  
    A_EGScap = sparse(numCtrs, numVars);
    ethernetNodePathTable = or(topologydata.pathInfo.bin_initNodes,kron(not(bin_fixNodes_Ids),ones(1,P)).*topologydata.pathInfo.bin_endNodes);
    A_EGScap_x_ems_p = kron(ones(1,E*(M)*S),ethernetNodePathTable); 
    A_EGScap_x_eus_p = kron(ones(1,E*(1)*S),ethernetNodePathTable); 
    A_EGScap_y_p = ethernetNodePathTable;
    A_EGScap_g_egs_i = -infrastructuredata.EGScap*speye(numCtrs);
    A_EGScap(:,offset_x_ems_p+1:offset_x_ems_p+length_x_ems_p) = A_EGScap_x_ems_p; 
    A_EGScap(:,offset_x_eus_p+1:offset_x_eus_p+length_x_eus_p) = A_EGScap_x_eus_p; 
    A_EGScap(:,offset_y_p+1:offset_y_p+length_y_p) = A_EGScap_y_p; 
    A_EGScap(:,offset_g_egs_i+1:offset_g_egs_i+length_g_egs_i)= A_EGScap_g_egs_i;
    lhs_EGScap = -Inf*ones(numCtrs,1);
    rhs_EGScap = sparse(numCtrs,1);
    clear A_EGScap_x_ems_p A_EGScap_x_eus_p A_EGScap_y_p A_EGScap_g_egs_i; 
    
    %BBU is deported to one unique node
    %sum[j in N] z_ej = 1, for each (e in Em)
    numCtrs = E_M;  
    A_uniqueBBU = sparse(numCtrs, numVars);
    A_uniqueBBU_z_ej = kron(speye(E_M,E_M),ones(1,N));
    A_uniqueBBU(:,offset_z_ej+1:offset_z_ej+length_z_ej)=A_uniqueBBU_z_ej;
    clear A_uniqueBBU_z_ej;
    lhs_uniqueBBU = ones(numCtrs,1);
    rhs_uniqueBBU = ones(numCtrs,1); 

    %VMs performing BBU processing
    %sum[e in E_M] d_e*z_ei <= t_bbu_i, for each (i in N)
    numCtrs = N;  
    A_BBUvms = sparse(numCtrs, numVars);
    A_BBUvms_z_ej = kron(infrastructuredata.d_bbu_e', speye(N,N));
    A_BBUvms_t_bbu_i = speye(N,N);
    A_BBUvms(:,offset_z_ej+1:offset_z_ej+length_z_ej)=A_BBUvms_z_ej;
    A_BBUvms(:,offset_t_bbu_i+1:offset_t_bbu_i+length_t_bbu_i) =  -A_BBUvms_t_bbu_i;
    clear A_BBUvms_z_ej A_BBUvms_t_bbu_i;
    lhs_BBUvms = -Inf*ones(numCtrs,1);
    rhs_BBUvms = sparse(numCtrs,1);

    %VMs performing video transcoding
    %sum[e in E, s in S] (sum[m in M]d_tc_ms*v_ems*f_emsi + d_us*vf_eusi) <= t_vtc_i, for each (i in N)
    numCtrs = N;  
    A_VTCvms = sparse(numCtrs, numVars);
%     v_ems'.*kron(ones(1,E*M),numVMsInfo.VTC')
%     pause
    A_VTCvms_f_emsi = kron(v_ems'.*kron(ones(1,E),d_tc_ms') , speye(N,N));
    A_VTCvms_vf_eusi = kron(kron(ones(1,E),d_tc_us') , speye(N,N));
    A_VTCvms_t_vtc_i = speye(N,N);
    A_VTCvms(:,offset_f_emsi+1:offset_f_emsi+length_f_emsi) = A_VTCvms_f_emsi;
    A_VTCvms(:,offset_vf_eusi+1:offset_vf_eusi+length_vf_eusi) = A_VTCvms_vf_eusi;
    A_VTCvms(:,offset_t_vtc_i+1:offset_t_vtc_i+length_t_vtc_i) =  -A_VTCvms_t_vtc_i;
    clear A_VTCvms_f_emsi A_VTCvms_vf_eusi A_VTCvms_t_vtc_i;
    lhs_VTCvms = -Inf*ones(numCtrs,1);
    rhs_VTCvms = sparse(numCtrs,1);
    
    %VM placement
    % t_bbu_i + t_vtc_i <= K * g_srv_i , for each (i in N)
    numCtrs = N;  
    A_vmPlace = sparse(numCtrs, numVars);
    A_vmPlace_t_bbu_i = speye(N,N);
    A_vmPlace_t_vtc_i = speye(N,N);
    A_vmPlace_g_srv_i =  infrastructuredata.K*speye(N,N);
    A_vmPlace(:,offset_t_bbu_i+1:offset_t_bbu_i+length_t_bbu_i) = A_vmPlace_t_bbu_i;
    A_vmPlace(:,offset_t_vtc_i+1:offset_t_vtc_i+length_t_vtc_i) = A_vmPlace_t_vtc_i;
    A_vmPlace(:,offset_g_srv_i+1:offset_g_srv_i+length_g_srv_i) = -A_vmPlace_g_srv_i;
    clear A_vmPlace_t_bbu_i A_vmPlace_t_vtc_i A_vmPlace_g_srv_i;
    lhs_vmPlace = -Inf*ones(numCtrs,1);
    rhs_vmPlace = sparse(numCtrs,1);
    
    %Physical Servers placevement
    % g_srv_i <= G * g_egs_i , for each (i in N)
    numCtrs = N;  
    A_srvPlace = sparse(numCtrs, numVars);
    A_srvPlace_g_srv_i = speye(N,N);
    A_srvPlace_g_egs_i = spdiags(infrastructuredata.G_n,0,N,N);
    A_srvPlace(:,offset_g_srv_i+1:offset_g_srv_i+length_g_srv_i) = A_srvPlace_g_srv_i;
    A_srvPlace(:,offset_g_egs_i+1:offset_g_egs_i+length_g_egs_i) = -A_srvPlace_g_egs_i;
    clear A_srvPlace_g_srv_i A_srvPlace_g_egs_i;
    lhs_srvPlace = -Inf*ones(numCtrs,1);
    rhs_srvPlace = sparse(numCtrs,1);
    
    %CPLEX call
    fprintf ('Calling CPLEX ... \n');
    cplex = Cplex('fullModel');
    cplex.Model.sense = 'maximize';
    cplex.Model.obj = [cost_f_emsi; cost_vf_eusi; cost_x_ems_p; cost_x_ems_ij; cost_x_eus_p; cost_x_eus_ij; cost_y_p; cost_z_ej; cost_z_j; cost_h_mi; cost_g_ipr_i; cost_g_egs_i; cost_g_srv_i; cost_t_bbu_i; cost_t_vtc_i];
    cplex.Model.lb = [lb_f_emsi; lb_vf_eusi; lb_x_ems_p; lb_x_ems_ij; lb_x_eus_p; lb_x_eus_ij; lb_y_p; lb_z_ej; lb_z_j; lb_h_mi; lb_g_ipr_i; lb_g_egs_i; lb_g_srv_i; lb_t_bbu_i; lb_t_vtc_i];
    cplex.Model.ub = [ub_f_emsi; ub_vf_eusi; ub_x_ems_p; ub_x_ems_ij; ub_x_eus_p; ub_x_eus_ij; ub_y_p; ub_z_ej; ub_z_j; ub_h_mi; ub_g_ipr_i; ub_g_egs_i; ub_g_srv_i; ub_t_bbu_i; ub_t_vtc_i];
    cplex.Model.ctype = [ctype_f_emsi ctype_vf_eusi ctype_x_ems_p ctype_x_ems_ij ctype_x_eus_p ctype_x_eus_ij ctype_y_p ctype_z_ej ctype_z_j ctype_h_mi ctype_g_ipr_i ctype_g_egs_i ctype_g_srv_i ctype_t_bbu_i ctype_t_vtc_i ];
    
    cplex.Model.A = [A_shareVidSrc;
                     A_hitRatio;
                     A_storCap;
                     A_minQoE;
                     A_maxQoE;
                     A_minQoE_u;
                     A_maxQoE_u;
                     A_vidCons;
                     A_vidCons_u;
                     A_backgCons;
                     A_LTEcap;
                     A_WDMcap;
                     A_IPRcap;
                     A_EGScap;
                     A_uniqueBBU;
                     A_BBUvms;
                     A_BBUzi_LB;
                     A_BBUzi_UB;
                     A_VTCvms;
                     A_vmPlace;
                     A_srvPlace;
                     ];
    cplex.Model.lhs = [ lhs_shareVidSrc;%0
                        lhs_hitRatio;%-Inf
                        lhs_storCap; % 0
                        lhs_minQoE; % 0
                        lhs_maxQoE; % -Inf
                        lhs_minQoE_u; % 0
                        lhs_maxQoE_u; % -Inf
                        lhs_vidCons; %0
                        lhs_vidCons_u; %0
                        lhs_backgCons; %backgroundTraff traff
                        lhs_LTEcap;  % -Inf
                        lhs_WDMcap;  % 0
                        lhs_IPRcap;  % 0
                        lhs_EGScap;  % 0
                        lhs_uniqueBBU; % 0
                        lhs_BBUvms; %-Inf
                        lhs_BBUzi_LB; %-Inf
                        lhs_BBUzi_UB; %-Inf
                        lhs_VTCvms; %-Inf
                        lhs_vmPlace; %-Inf
                        lhs_srvPlace; %-Inf
                        ];
    cplex.Model.rhs = [ rhs_shareVidSrc; %1
                        rhs_hitRatio;%0
                        rhs_storCap; % storage cap
                        rhs_minQoE; % Inf
                        rhs_maxQoE; % 0
                        rhs_minQoE_u; % Inf
                        rhs_maxQoE_u; % 0
                        rhs_vidCons;  % = 0
                        rhs_vidCons_u;  % = 0
                        rhs_backgCons; % backgroundTraff traff
                        rhs_LTEcap; %0
                        rhs_WDMcap % C_WDM
                        rhs_IPRcap % C_IPR
                        rhs_EGScap % C_EGS
                        rhs_uniqueBBU; % 1
                        rhs_BBUvms; %0
                        rhs_BBUzi_LB; %0
                        rhs_BBUzi_UB; %0
                        rhs_VTCvms; %0
                        rhs_vmPlace; %0
                        rhs_srvPlace; %0
                        ]; 
                    
     offset_shareVidSrc = 0;                    
     numCtrs_shareVidSrc = E*M*S;
     offset_hitRatio = offset_shareVidSrc + numCtrs_shareVidSrc;  
     numCtrs_hitRatio = E*M*S*N;
     offset_storCap = offset_hitRatio + numCtrs_hitRatio;
     numCtrs_storCap = N;  
     offset_minQoE = offset_storCap + numCtrs_storCap;
     numCtrs_minQoE = E*M*S*N;
     offset_maxQoE = offset_minQoE + numCtrs_minQoE;
     numCtrs_maxQoE = E*M*S*N; 
     offset_minQoE_u = offset_maxQoE + numCtrs_maxQoE;
     numCtrs_minQoE_u = E*S*N;
     offset_maxQoE_u = offset_minQoE_u + numCtrs_minQoE_u;
     numCtrs_maxQoE_u = E*S*N; 
     offset_vidCons = offset_maxQoE_u + numCtrs_maxQoE_u;
     numCtrs_vidCons = E*(M)*S*N*N; 
     offset_vidCons_u = offset_vidCons + numCtrs_vidCons;
     numCtrs_vidCons_u = E*(1)*S*N*N; 
     offset_backgCons = offset_vidCons_u + numCtrs_vidCons_u;
     numCtrs_backgCons = N; 
     offset_LTEcap = offset_backgCons + numCtrs_backgCons;
     numCtrs_LTEcap = E_M*N; 
     offset_WDMcap = offset_LTEcap + numCtrs_LTEcap;
     numCtrs_WDMcap = L; 
     offset_IPRcap = offset_WDMcap + numCtrs_WDMcap;
     numCtrs_IPRcap = N; 
     offset_EGScap = offset_IPRcap + numCtrs_IPRcap;
     numCtrs_EGScap = N; 
     offset_uniqueBBU = offset_EGScap + numCtrs_EGScap;
     numCtrs_uniqueBBU = E_M; 
     offset_rhs_BBUvms = offset_uniqueBBU + numCtrs_uniqueBBU;
     numCtrs_rhs_BBUvms = N; 
     offset_VTCvms = offset_rhs_BBUvms + numCtrs_rhs_BBUvms;
     numCtrs_VTCvms = N;                   
%     size(cplex.Model.obj)    
%     size(cplex.Model.lb)
%     size(cplex.Model.ub)
%     size(cplex.Model.ctype)
%     
%     size(cplex.Model.A)
%     size(cplex.Model.lhs)
%     size(cplex.Model.rhs)

    %MILP stopping criterions
    cplex.Param.mip.tolerances.mipgap.Cur = 3e-3; %relativ optim gap = 3%
    cplex.Param.timelimit.Cur = 10*60; %(s) = 3 min
    cplex.solve();

    fprintf ('\nSolution status = %s \n', cplex.Solution.statusstring);
    fprintf ('Solution value = %f \n', cplex.Solution.objval);
    
    sol.time = cplex.Solution.time;
    sol.miprelgap = cplex.Solution.miprelgap;
    sol.status = cplex.Solution.statusstring;
    sol.statusnum = cplex.Solution.status;
    sol.obj =  cplex.Solution.objval;
    sol.x = cplex.Solution.x;
    sol.ax= cplex.Solution.ax;
    sol.vf_eusi = sparse(cplex.Solution.x(offset_vf_eusi+ 1 : offset_vf_eusi+ length_vf_eusi));
    sol.f_emsi = sparse(cplex.Solution.x(offset_f_emsi+ 1 : offset_f_emsi+ length_f_emsi));
    sol.x_ems_p = sparse(cplex.Solution.x(offset_x_ems_p+ 1 : offset_x_ems_p+ length_x_ems_p));
    sol.x_ems_ij = sparse(cplex.Solution.x(offset_x_ems_ij+ 1 : offset_x_ems_ij+ length_x_ems_ij));
    sol.x_eus_p = sparse(cplex.Solution.x(offset_x_eus_p+ 1 : offset_x_eus_p+ length_x_eus_p));
    sol.x_eus_ij = sparse(cplex.Solution.x(offset_x_eus_ij+ 1 : offset_x_eus_ij+ length_x_eus_ij));
    sol.y_p = sparse(cplex.Solution.x(offset_y_p+ 1 : offset_y_p+ length_y_p));
    sol.z_ej = cplex.Solution.x(offset_z_ej+ 1 : offset_z_ej+ length_z_ej);
    sol.z_j = cplex.Solution.x(offset_z_j+ 1 : offset_z_j+ length_z_j);
    sol.z_j = cplex.Solution.x(offset_z_j+ 1 : offset_z_j+ length_z_j);
    sol.h_mi = sparse(cplex.Solution.x(offset_h_mi+ 1 : offset_h_mi+ length_h_mi));
    sol.g_ipr_i = cplex.Solution.x(offset_g_ipr_i+ 1 : offset_g_ipr_i+ length_g_ipr_i);
    sol.g_egs_i = cplex.Solution.x(offset_g_egs_i+ 1 : offset_g_egs_i+ length_g_egs_i);
    sol.g_srv_i = cplex.Solution.x(offset_g_srv_i+ 1 : offset_g_srv_i+ length_g_srv_i);
    sol.t_bbu_i = cplex.Solution.x(offset_t_bbu_i+ 1 : offset_t_bbu_i+ length_t_bbu_i);
    sol.t_vtc_i = cplex.Solution.x(offset_t_vtc_i+ 1 : offset_t_vtc_i+ length_t_vtc_i);
    
    %computing slackness used to trigger reoptim
    %1) min QoE
    slack.minQoE = sol.ax(offset_minQoE+1 : offset_minQoE+numCtrs_minQoE); %>0 by default
    %2) min QoE_u
    slack.minQoE_u = sol.ax(offset_minQoE_u+1 : offset_minQoE_u+numCtrs_minQoE_u); %<0 by default
    %3) max QoE
    slack.maxQoE = sol.ax(offset_maxQoE+1 : offset_maxQoE+numCtrs_maxQoE); %>0 by default
    %4) max QoE_u
    slack.maxQoE_u = sol.ax(offset_maxQoE_u+1 : offset_maxQoE_u+numCtrs_maxQoE_u); %<0 by default
    %5) VTCvms
    slack.VTCvms = -sol.ax(offset_VTCvms+1 : offset_VTCvms+numCtrs_VTCvms); %<0 by default
%     
%      fprintf ('Checking slackness in QoE ems ctrs (min max)  \n');
%     [A_minQoE_x_ems_ij*sol.x_ems_ij-A_minQoE_f_emsi*sol.f_emsi A_maxQoE_x_ems_ij*sol.x_ems_ij-A_maxQoE_f_emsi*sol.f_emsi]
% %     
%      postproccesing(sol, topologydata, videodata,infrastructuredata, gamma)
    [power,QoE]=compute_power_QoE(cost_x_ems_ij,cost_g_ipr_i,cost_g_egs_i,cost_g_srv_i,cost_t_bbu_i,cost_t_vtc_i,sol);
    sol.power=-power;
    sol.QoE=QoE/gamma;
    
end
function postproccesing(sol, topologydata, videodata,infrastructuredata, gamma)    

  % Dimensions
    E_M = topologydata.nbof_mobendnodes; % numMobileEndNodes;
    E_F = topologydata.nbof_fixedendnodes; % numFixEndNodes;
    E = E_M+E_F;  % numEndNodes;
    N = size(topologydata.pathInfo.bin_nodesInPath,1);
    L = size(topologydata.pathInfo.bin_edgesInPath,1);
    M = size(videodata.mat_content,2);%     numContents (that is not the number of content types);
    S = size(videodata.alpha,2);%     numResols;
    P = topologydata.pathInfo.P;
        
    %Indeces
    bin_PoP_Id = (topologydata.nodeTable(:,3)==0);
    if sum(bin_PoP_Id)>1, error('More than one PoP'); end
    bin_NOT_mobNodes_Ids = (topologydata.nodeTable(:,3)~=4);
    bin_fixNodes_Ids = (topologydata.nodeTable(:,3)==3);
    bin_mobNodes_Ids = (topologydata.nodeTable(:,3)==4);
    fixNodes_Ids = find(topologydata.nodeTable(:,3)==3);
    mobNodes_Ids = find(topologydata.nodeTable(:,3)==4);
    
    %contents catalog
%     v_ems = [kron(ones(E_F,1), mat2vct(videoInfo.videosPerFixPoint_byContDev));...
%              kron(ones(E_M,1), mat2vct(videoInfo.videosPerCellSite_byContDev))];
    v_ems = videodata.vems';% to col
    % We transform all the content-type-dependnt info into individual content-dependant info
    b_min_ms = videodata.bmin(videodata.mat_content(2,:),:); 
    b_max_ms = videodata.bmax(videodata.mat_content(2,:),:);
    b_min_ems = kron(ones(E,1), mat2vct(b_min_ms));
    b_max_ems = kron(ones(E,1), mat2vct(b_max_ms));
    QoE_ms = videodata.alpha(videodata.mat_content(2,:),:);
    QoE_ems = kron(ones(E,1), mat2vct(QoE_ms));
    for flag4K = 0:size(videodata.d_tc,1)-1,
        switch flag4K 
            case 0 %not flag4K
                d_tc_ms_not4k = squeeze(videodata.d_tc(flag4K+1,:,videodata.mat_content(2,:)))';
                d_tc_ms_not4k((videodata.mat_content(5,:)==1)',:)=0; %removing 4k
            case 1 %flag4K
                d_tc_ms_4k = squeeze(videodata.d_tc(flag4K+1,:,videodata.mat_content(2,:)))';
                d_tc_ms_4k(not(videodata.mat_content(5,:))',:)=0; %removing not 4k
        end
    end
    d_tc_ms =mat2vct(d_tc_ms_4k + d_tc_ms_not4k);

    %unknown content
    b_min_s_unknown = mean(b_min_ms)'; %col vector
    b_max_s_unknown = mean(b_max_ms)'; %col vector
    QoE_unknown = mean(QoE_ms)'; %col vector
    b_min_es = kron(ones(E,1), b_min_s_unknown);
    b_max_es = kron(ones(E,1), b_max_s_unknown);
    QoE_eus = kron(ones(E,1), QoE_unknown);
    d_tc_us = mean(d_tc_ms_4k)'+mean(d_tc_ms_not4k)';
    
    videoTraffMatrix = zeros(N,N,E*M*S); 
    aggVideoTraffMatrix = zeros(N,N,E); 
    f_emsi_matrix = zeros(N,E*M*S);
    for ems = 1:E*M*S,
        e = ceil(ems/(M*S));
        f_emsi_matrix (:,ems) = ((reshape(sol.f_emsi((ems-1)*N+1 : ems*N),[N,1]))');
        videoTraffMatrix (:,:,ems) = ((reshape(sol.x_ems_ij((ems-1)*N^2+1 : ems*N^2),[N,N]))');
        aggVideoTraffMatrix(:,:,e) = aggVideoTraffMatrix(:,:,e) +  videoTraffMatrix (:,:,ems);
    end
%     sum(sol.f_emsi)
%     sum(sum(f_emsi_matrix))
%     pause
    vf_eusi_matrix = vct2mat(sol.vf_eusi, E*1*S, N);
    unkVidTraffMatrix = zeros(N,N,E*1*S); 
    aggUnkVidTraffMatrix = zeros(N,N,E); 
    for es = 1:E*S,
        e = ceil(es/(1*S));
        unkVidTraffMatrix (:,:,es) = ((reshape(sol.x_eus_ij((es-1)*N^2+1 : es*N^2),[N,N]))');
        aggUnkVidTraffMatrix(:,:,e) = aggUnkVidTraffMatrix(:,:,e) +  unkVidTraffMatrix (:,:,es);
    end
    
%     vf_eusi_matrix = zeros(N,E*1*S);
%     for es = 1:E*1*S,
%         vf_eusi_matrix (:,es) = ((reshape(vf_eusi((es-1)*N+1 : es*N),[N,1]))');
%         es
%         vf_eusi_matrix(:,es)
%         pause
%     end
%     sum(vf_eusi)
%     sum(sum(vf_eusi_matrix))
%     pause
    for e = 1:E,
        e 
        disp('aggVideoTraffMatrix')
        ag=aggVideoTraffMatrix(:,:,e)
%         disp('aggUnkVidTraffMatrix')
%         aggUnkVidTraffMatrix(:,:,e)
%         pause
    end
    
    disp('Total aggVideoTraffMatrix=')
    carriedVidTraffic = sum(sum(sum(aggVideoTraffMatrix)))
    disp('Total Offered aggVideoTraffMatrix=')
    maxOfferedVidTrafic = v_ems'*b_max_ems
    pause
    v_ems
%     b_max_ems
    sum_bmax = sum(b_max_ems)
%     max_bmax = max(b_max_ems)
    numVideos = sum(v_ems)
    max_numVideos_paralel = max(v_ems)
%     pause
    disp('acceptedTraffic_wrtMax = ')
    acceptedTraffic_wrtMax = carriedVidTraffic/maxOfferedVidTrafic
    
    disp('Total aggUnkVidTraffMatrix=')
    sum(sum(sum(aggUnkVidTraffMatrix)))
%     disp('Total Offered aggUnkVidTraffMatrix=')
%     v_es'*b_max_es
%     pause
  
    backgroundTraff_t = topologydata.pathInfo.bin_endNodes*sol.y_p
    backgroundTraff_s = topologydata.pathInfo.bin_initNodes*sol.y_p
    
    z_ej_mat = vct2mat(sol.z_ej, E_M, N)
    sol.z_j
    h_mi_mat = vct2mat(sol.h_mi, M, N)
    
    sol.g_ipr_i
    sol.g_egs_i
    sol.g_srv_i
    sol.t_bbu_i 
    sol.t_vtc_i
end
function vector_col = mat2vct(matrix)
    vector_col = reshape(matrix', [numel(matrix) 1]);
end
function matrix = vct2mat(vector, numRows, numCols)
    matrix = (reshape(vector,[numCols numRows]))';
end

function [power,QoE]=compute_power_QoE(cost_x_ems_ij,cost_g_ipr_i,cost_g_egs_i,cost_g_srv_i,cost_t_bbu_i,cost_t_vtc_i,sol)

QoE=sum(cost_x_ems_ij.*sol.x_ems_ij);
power=sum(cost_g_ipr_i.*sol.g_ipr_i)+sum(cost_g_egs_i.*sol.g_egs_i)+sum(cost_g_srv_i.*sol.g_srv_i)+...
    sum(cost_t_bbu_i.*sol.t_bbu_i)+sum(cost_t_vtc_i.*sol.t_vtc_i);
end
