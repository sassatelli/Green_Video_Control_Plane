function srv_submission_scen3(topology_name,model,gamma_factor)

initialize();

scenario_ind=3;
nbof_catalog=2; totalrequests=1e5; 
nbof_contentpercatalog=1e4;
topo_traffic_filename=['../simpoints/topo_traffic_scen',num2str(scenario_ind),'_',topology_name,'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
if exist(topo_traffic_filename,'file')==0,
    Generate_scen_forcurves(scenario_ind,topology_name);
end;

if strcmp(model,'ViRCA'),
    full_model=@VCRAN_MILP_bkg; partial_model=@QoE_RCA_LP_bkg;
elseif strcmp(model,'ViRCA2'),
    full_model=@VCRAN_MILP_v2_bkg; partial_model=@QoE_RCA_LP_bkg;
elseif strcmp(model,'ViRCA3'),
    full_model=@VCRAN_MILP_v3_bkg; partial_model=@QoE_RCA_LP_v3_bkg;
end;

%--Parameters - time in sec
T_sample=5*60; %-- 5min as in MPLS-TE
T_reconfInfra=30*60; %-- 1/2h to save energy by shting down some nodes
T_reconfRoutCach=10*60; %
T_optimini=5*60; %-- piece of trace considered for initial optim
[gamma_central,maxpower,maxQoE]=get_gammacentral(topo_traffic_filename,model);
gamma.factor=gamma_factor;
gamma.maxpower=maxpower;
beta=0.5;
max_ems_p=1e6;
flag_compresscatalog=1;

%-- Local launch
[array_usedbudgets,array_QoE,array_CPU_load,array_optimoutput]=Simulator_main_withReopt(topo_traffic_filename,...
    T_sample,T_reconfInfra,T_reconfRoutCach,T_optimini,gamma,beta,max_ems_p,flag_compresscatalog,full_model,partial_model,model);

load(topo_traffic_filename,'topologydata','videodata','infrastructuredata','backgroundTraff');
res_filename=['sols/res_scen',num2str(scenario_ind),'_',model,'_',topology_name,'_gammafactor',num2str(gamma.factor),'_K',num2str(infrastructuredata.K),'.mat'];
save(res_filename,'array_usedbudgets','array_QoE','array_CPU_load','array_optimoutput','-v7.3')

return

end
%%%%%%%%%%

function initialize
    addpath( ...
        '../scenarii','../simpoints','../simulator_v3','../srv_submissions',...
         genpath('/usr/local/MATLAB/R2011a/toolbox/stats/'));
%         '/opt/ibm/ILOG/CPLEX_Studio1262/cplex/matlab/','/opt/ibm/ILOG/CPLEX_Studio1262/cplex/matlab/x86-64_linux');
end

function [gamma_central,maxpower,maxQoE]=get_gammacentral(topo_traffic_filename,model)
    load(topo_traffic_filename,'topologydata','videodata','infrastructuredata','backgroundTraff');
    maxpower_pernode=infrastructuredata.IPRpower+infrastructuredata.EGSpower+infrastructuredata.SRVpower+infrastructuredata.VMpower*sum(infrastructuredata.G_n*infrastructuredata.K);
    nbof_nodes=size(topologydata.nodeTable,1);
    maxpower=maxpower_pernode*nbof_nodes;
    E_M = topologydata.nbof_mobendnodes; % numMobileEndNodes;
    E_F = topologydata.nbof_fixedendnodes; % numFixEndNodes;
    E = E_M+E_F;  % numEndNodes;
    vems = videodata.vems';% to col
    % We transform all the content-type-dependnt info into individual content-dependant info
    nbof_resol=4;
    vem=sum(reshape(videodata.vems,nbof_resol,length(videodata.vems)/nbof_resol),1);
    vm=sum(reshape(vem,length(vem)/E,E),2);
    maxQoE=sum(videodata.vems.*min(sum(infrastructuredata.nodeStorage)/sum(videodata.mat_content(4,logical(vm>0))),1)); % sum(vems)
    if strcmp(model,'ViRCA3'),
        nbof_mobendnodes=E_M;
        maxQoE=sum(videodata.vems.*min(sum(infrastructuredata.nodeStorage([1 nbof_nodes-E+1:nbof_nodes]))/sum(videodata.mat_content(4,logical(vm>0))),1)); % sum(vems)
    end;
    gamma_central=maxpower/maxQoE;
end

