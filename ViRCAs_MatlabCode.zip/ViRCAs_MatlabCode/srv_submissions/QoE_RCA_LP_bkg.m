function [sol, slack,reoptimFlag] = QoE_RCA_LP_bkg(ViRCA_sol,topologydata,videodata,videodata_prevoptim,infrastructuredata, start_RCA_sol, prevSlack, measures_delta)
%% same for ViRCA and ViRCA2
    % Dimensions
    E_M = topologydata.nbof_mobendnodes; % numMobileEndNodes;
    E_F = topologydata.nbof_fixedendnodes; % numFixEndNodes;
    E = E_M+E_F;  % numEndNodes;
    N = size(topologydata.pathInfo.bin_nodesInPath,1);
    L = size(topologydata.pathInfo.bin_edgesInPath,1);
    M = size(videodata.mat_content,2);%     numContents (that is not the number of content types);
    S = size(videodata.alpha,2);%     numResols;
    P = topologydata.pathInfo.P;
        
    %Indeces
    bin_PoP_Id = (topologydata.nodeTable(:,3)==0);
    if sum(bin_PoP_Id)>1, error('More than one PoP'); end
    bin_NOT_mobNodes_Ids = (topologydata.nodeTable(:,3)~=4);
    bin_fixNodes_Ids = (topologydata.nodeTable(:,3)==3);
    bin_mobNodes_Ids = (topologydata.nodeTable(:,3)==4);
    fixNodes_Ids = find(topologydata.nodeTable(:,3)==3);
    mobNodes_Ids = find(topologydata.nodeTable(:,3)==4);
    
    %contents catalog
%     v_ems = [kron(ones(E_F,1), mat2vct(videoInfo.videosPerFixPoint_byContDev));...
%              kron(ones(E_M,1), mat2vct(videoInfo.videosPerCellSite_byContDev))];
    v_ems = videodata.vems';% to col
    % We transform all the content-type-dependnt info into individual
    % content-dependant info with content used for previous optim to decide triggering
    b_min_ms = videodata.bmin(videodata_prevoptim.mat_content(2,:),:); 
    b_max_ms = videodata.bmax(videodata_prevoptim.mat_content(2,:),:);
    b_min_ems = kron(ones(E,1), mat2vct(b_min_ms));
    b_max_ems = kron(ones(E,1), mat2vct(b_max_ms));
    QoE_ms = videodata.alpha(videodata_prevoptim.mat_content(2,:),:);
    QoE_ems = kron(ones(E,1), mat2vct(QoE_ms));
    for flag4K = 0:size(videodata.d_tc,1)-1,
        switch flag4K 
            case 0 %not flag4K
                d_tc_ms_not4k = squeeze(videodata.d_tc(flag4K+1,:,videodata_prevoptim.mat_content(2,:)))';
                d_tc_ms_not4k((videodata_prevoptim.mat_content(5,:)==1)',:)=0; %removing 4k
            case 1 %flag4K
                d_tc_ms_4k = squeeze(videodata.d_tc(flag4K+1,:,videodata_prevoptim.mat_content(2,:)))';
                d_tc_ms_4k(not(videodata_prevoptim.mat_content(5,:))',:)=0; %removing not 4k
        end
    end
    d_tc_ms =mat2vct(d_tc_ms_4k + d_tc_ms_not4k);
    % min background traff per (e,m,s)
    contentSize = videodata.mat_content(4,:);
    min_backgTraff_ems=sparse(zeros(size(videodata.vems)));
    indsup0=logical(videodata.vems>0);
    allvec=videodata.beta*(videodata.vems./videodata.wdems).*kron(ones(1,E),kron(contentSize,ones(1,S)));
    min_backgTraff_ems(indsup0) = allvec(indsup0); % otherwise divide by zero and NaN

    %unknown content
    b_min_s_unknown = mean(b_min_ms)'; %col vector
    b_max_s_unknown = mean(b_max_ms)'; %col vector
    QoE_unknown = mean(QoE_ms)'; %col vector
    b_min_es = kron(ones(E,1), b_min_s_unknown);
    b_max_es = kron(ones(E,1), b_max_s_unknown);
    QoE_eus = kron(ones(E,1), QoE_unknown);
    d_tc_us = mean(d_tc_ms_4k)'+mean(d_tc_ms_not4k)';
    
    % Triggering reoptim
    [reoptimFlag] = reoptimTrigger (prevSlack, N,E, measures_delta, b_min_ems, b_max_ems, d_tc_ms, b_min_es, b_max_es, d_tc_us);
    if not(reoptimFlag),
        sol = start_RCA_sol;
        slack = prevSlack;
        return
    end
    %---- If optimization to be triggered, then form the following
    %variables with the new content, used for optim-----------
    b_min_ms = videodata.bmin(videodata.mat_content(2,:),:); 
    b_max_ms = videodata.bmax(videodata.mat_content(2,:),:);
    b_min_ems = kron(ones(E,1), mat2vct(b_min_ms));
    b_max_ems = kron(ones(E,1), mat2vct(b_max_ms));
    QoE_ms = videodata.alpha(videodata.mat_content(2,:),:);
    QoE_ems = kron(ones(E,1), mat2vct(QoE_ms));
    for flag4K = 0:size(videodata.d_tc,1)-1,
        switch flag4K 
            case 0 %not flag4K
                d_tc_ms_not4k = squeeze(videodata.d_tc(flag4K+1,:,videodata.mat_content(2,:)))';
                d_tc_ms_not4k((videodata.mat_content(5,:)==1)',:)=0; %removing 4k
            case 1 %flag4K
                d_tc_ms_4k = squeeze(videodata.d_tc(flag4K+1,:,videodata.mat_content(2,:)))';
                d_tc_ms_4k(not(videodata.mat_content(5,:))',:)=0; %removing not 4k
        end
    end
    d_tc_ms =mat2vct(d_tc_ms_4k + d_tc_ms_not4k);

    %unknown content
    b_min_s_unknown = mean(b_min_ms)'; %col vector
    b_max_s_unknown = mean(b_max_ms)'; %col vector
    QoE_unknown = mean(QoE_ms)'; %col vector
    b_min_es = kron(ones(E,1), b_min_s_unknown);
    b_max_es = kron(ones(E,1), b_max_s_unknown);
    QoE_eus = kron(ones(E,1), QoE_unknown);
    d_tc_us = mean(d_tc_ms_4k)'+mean(d_tc_ms_not4k)';
    %----------------------------------
    
    %Decisions Variables

    % f_emsi --> Continous var btw 0 and 1   
    offset_f_emsi =0;
    length_f_emsi = E*M*S*N;
    cost_f_emsi = sparse(length_f_emsi,1);
    lb_f_emsi = sparse(length_f_emsi,1);
    ub_f_emsi = ones(length_f_emsi,1);
    
    % vf_eusi --> Continous var btw 0 and 1   
    offset_vf_eusi = offset_f_emsi + length_f_emsi; 
    length_vf_eusi = E*1*S*N;
    cost_vf_eusi = sparse(length_vf_eusi,1);
    lb_vf_eusi = sparse(length_vf_eusi,1);
    ub_vf_eusi = Inf*ones(length_vf_eusi,1);
    
    % x_ems_p --> Continous var btw 0 and inf (traffic units)    
    offset_x_ems_p = offset_vf_eusi + length_vf_eusi;
    length_x_ems_p = E*M*S*P;
    cost_x_ems_p = sparse(length_x_ems_p,1);
    lb_x_ems_p = sparse(length_x_ems_p,1);
    ub_x_ems_p = Inf*ones(length_x_ems_p,1);
    
    % x_ems_ij --> Continous var btw 0 and inf (traffic units)  
    UB_videoTraff = sum(v_ems)*max(max(videodata.bmax));
    offset_x_ems_ij = offset_x_ems_p+length_x_ems_p;
    length_x_ems_ij = E*M*S*N^2;
    cost_x_ems_ij = kron(QoE_ems, ones(N*N,1));
    lb_x_ems_ij = sparse(length_x_ems_ij,1);
%     ub_x_ems_ij = sparse(length_x_ems_ij,1); 
    ub_x_ems_ij_fix = sparse(E_F*M*S*N^2,1); 
    % if e in E_f, we cannot deport BBUs, then, for j =~ e, x_ems_ij = 0
    for ef = 1:E_F,
        n = fixNodes_Ids(ef);
%         aux = sparse(N,1);aux(n) = UB_videoTraff;
        aux = sparse(n,1,UB_videoTraff,N,1);
        ub_x_ems_ij_fix((ef-1)*M*S*N^2 + 1 : ef*M*S*N^2) = kron(ones(M*S*N,1),aux);
    end
    ub_x_ems_ij = [ub_x_ems_ij_fix; UB_videoTraff*ones(E_M*M*S*N^2,1)];     
       
    % x_eus_p --> Continous var btw 0 and inf (traffic units)    
    offset_x_eus_p = offset_x_ems_ij + length_x_ems_ij;
    length_x_eus_p = E*(1)*S*P;
    cost_x_eus_p = sparse(length_x_eus_p,1);
    lb_x_eus_p = sparse(length_x_eus_p,1);
    ub_x_eus_p = Inf*ones(length_x_eus_p,1);
    
    % x_eus_ij --> Continous var btw 0 and inf (traffic units)  
    offset_x_eus_ij = offset_x_eus_p+length_x_eus_p;
    length_x_eus_ij = E*(1)*S*N^2;
    cost_x_eus_ij =  sparse(length_x_eus_ij,1);
%     cost_x_eus_ij = kron(QoE_eus, ones(N*N,1));
    lb_x_eus_ij = sparse(length_x_eus_ij,1);
    ub_x_eus_ij_fix = sparse(E_F*(1)*S*N^2,1); 
    % if e in E_f, we cannot deport BBUs, then, for j =~ e, x_eus_ij = 0
    for e = 1:E_F,
        n = fixNodes_Ids(e);
%         aux = sparse(N,1);aux(n) = UB_videoTraff;
        aux = sparse(n,1,UB_videoTraff,N,1);
        ub_x_eus_ij_fix((e-1)*(1)*S*N^2 + 1 : e*(1)*S*N^2) = kron(ones((1)*S*N,1),aux);
    end
    ub_x_eus_ij = [ub_x_eus_ij_fix; UB_videoTraff*ones(E_M*1*S*N^2,1)]; 
    
    % y_p --> Continous var btw 0 and inf (traffic units)  
%     UB_backgrTraff = sum(min_backgTraff_ems)*N;
    UB_backgrTraff = Inf;
    offset_y_p = offset_x_eus_ij+length_x_eus_ij;
    length_y_p = P;
    cost_y_p = sparse(length_y_p,1);
    lb_y_p = sparse(length_y_p,1);
    bin_pathsFromPoP = topologydata.pathInfo.bin_initNodes(bin_PoP_Id,:);
    ub_y_p=sparse(zeros(size(bin_pathsFromPoP')));
    ub_y_p(logical(bin_pathsFromPoP')) = UB_backgrTraff;
    
    % h_mi --> Continous var btw 0 and 1  
    offset_h_mi = offset_y_p+length_y_p;
    length_h_mi = M*N;
    cost_h_mi = sparse(length_h_mi,1);
    lb_h_mi = sparse(length_h_mi,1);
    ub_h_mi = ones(length_h_mi,1);
    
    
    numVars = length_vf_eusi + length_f_emsi + length_x_ems_p + length_x_ems_ij + length_x_eus_p + length_x_eus_ij + length_y_p + length_h_mi;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
    %Constraints
    fprintf ('Creating constraints ... \n');

    %Min QoE  
    %sum[j in N] x_ems_ij >= b_min_ms * v_ems * f_emsi, for each (e in E,m in M+u, s in S,i in N)
    numCtrs = E*M*S*N; 
    A_minQoE = sparse(numCtrs,numVars);
    A_minQoE_f_emsi = kron(spdiags(b_min_ems.*v_ems,0,E*M*S,E*M*S),speye(N));
    A_minQoE_x_ems_ij = kron(speye(E*M*S*N), ones(1,N)); 
    A_minQoE(:,1:length_f_emsi) = -A_minQoE_f_emsi;
    %length_x_ems_ij_minus_x_eus_ij =  E*(M)*S*N^2;
    A_minQoE(:,offset_x_ems_ij+1:offset_x_ems_ij+length_x_ems_ij) = A_minQoE_x_ems_ij;
    lhs_minQoE = sparse(numCtrs,1);
    rhs_minQoE = Inf*ones(numCtrs,1);
    clear A_minQoE_f_emsi A_minQoE_x_ems_ij

    %Max QoE  
    %sum[j in N] x_ems_ij >= b_max_ms * v_ems * f_emsi, for each (e in E,m in M+u, s in S,i in N)
    numCtrs = E*M*S*N; 
    A_maxQoE = sparse(numCtrs,numVars);
    A_maxQoE_f_emsi = kron(spdiags(b_max_ems.*v_ems,0,E*M*S,E*M*S),speye(N));
    A_maxQoE_x_ems_ij = kron(speye(E*M*S*N), ones(1,N)); 
    A_maxQoE(:,1:length_f_emsi) = -A_maxQoE_f_emsi;
    A_maxQoE(:,offset_x_ems_ij+1:offset_x_ems_ij+length_x_ems_ij) = A_maxQoE_x_ems_ij;
    lhs_maxQoE = -Inf(numCtrs,1);
    rhs_maxQoE = sparse(numCtrs,1);
    clear A_maxQoE_f_emsi A_maxQoE_x_ems_ij
    
    %Min QoE vf_eus 
    %sum[j in N] x_eus_ij >= b_min_s * vf_eusi, for each (e in E, s in S,i in N)
    numCtrs = E*S*N; 
    A_minQoE_u = sparse(numCtrs,numVars);
    A_minQoE_u_vf_eusi = kron(spdiags(b_min_es,0,E*1*S,E*1*S),speye(N));
    A_minQoE_u_x_eus_ij = kron(speye(E*1*S*N), ones(1,N)); 
    A_minQoE_u(:,offset_vf_eusi+ 1:offset_vf_eusi+length_vf_eusi) = -A_minQoE_u_vf_eusi;
    A_minQoE_u(:,offset_x_eus_ij+1:offset_x_eus_ij+length_x_eus_ij) = A_minQoE_u_x_eus_ij;
    lhs_minQoE_u = sparse(numCtrs,1);
    rhs_minQoE_u = Inf*ones(numCtrs,1);
    clear A_minQoE_u_vf_eusi A_minQoE_u_x_eus_ij;
    
    %Max QoE vf_eus 
    %sum[j in N] x_eus_ij <= b_max_s * vf_eusi, for each (e in E, s in S,i in N)
    numCtrs = E*S*N; 
    A_maxQoE_u = sparse(numCtrs,numVars);
    A_maxQoE_u_vf_eusi = kron(spdiags(b_max_es,0,E*1*S,E*1*S),speye(N));
    A_maxQoE_u_x_eus_ij = kron(speye(E*1*S*N), ones(1,N)); 
    A_maxQoE_u(:,offset_vf_eusi+ 1:offset_vf_eusi+length_vf_eusi) = -A_maxQoE_u_vf_eusi;
    A_maxQoE_u(:,offset_x_eus_ij+1:offset_x_eus_ij+length_x_eus_ij) = A_maxQoE_u_x_eus_ij;
    lhs_maxQoE_u = -Inf(numCtrs,1);
    rhs_maxQoE_u = sparse(numCtrs,1);
    clear A_maxQoE_u_vf_eusi A_maxQoE_u_x_eus_ij;
    
    %Share video caches 
    %sum[i in N] f_emsi <= 1, for each (e in E,m in M+u, s in S)
    numCtrs = E*M*S; 
    A_shareVidSrc = sparse(numCtrs,numVars);
    A_shareVidSrc_f_emsi = kron(speye(E*M*S),ones(1,N));
    A_shareVidSrc(:,1:length_f_emsi) = A_shareVidSrc_f_emsi;
    lhs_shareVidSrc = sparse(numCtrs,1);
    rhs_shareVidSrc = ones(numCtrs,1);
    clear A_shareVidSrc_f_emsi;
    
    %Relationship btw f_emsi and h_mi
    % f_emsi <= h_mi, for each (e in E,m in M+u, s in S, i in N)
    numCtrs = E*M*S*N; 
    A_hitRatio = sparse(numCtrs,numVars);
    A_hitRatio_f_emsi = speye(length_f_emsi);
    A_hitRatio_h_mi = kron(kron(ones(E,1),kron(speye(M),ones(S,1))),speye(N));
    A_hitRatio(:, 1:+length_f_emsi) = A_hitRatio_f_emsi;
    A_hitRatio(:,offset_h_mi+1:offset_h_mi+length_h_mi) = -A_hitRatio_h_mi;
    lhs_hitRatio = -Inf(numCtrs,1);
    rhs_hitRatio = sparse(numCtrs,1);
    clear A_hitRatio_f_emsi A_hitRatio_h_mi
    
    %Storage Capacity 
    %sum[m in M] s_m h_mi <= S_i, for each (i in N)
    numCtrs = N; 
    A_storCap = sparse(numCtrs, numVars);
    contentSize = videodata.mat_content(4,:);
    A_storCap_h_mi = kron(contentSize,speye(N));  
    A_storCap(:,offset_h_mi+1:offset_h_mi+length_h_mi) = A_storCap_h_mi;
    lhs_storCap = sparse(numCtrs,1);
    rhs_storCap = infrastructuredata.nodeStorage;
    clear A_storCap_h_mi
  
    %Video Traffic Flow Conservation 
    %sum[ p in P_ij] x_ems_p = x_ems_ij , for each (e in E, s in S, m in M,i in N, j in N) 
    numCtrs = E*(M)*S*N*N;  
    A_vidCons = sparse(numCtrs,numVars);
    A_vidCons_x_ems_p = kron(speye(E*(M)*S), topologydata.pathInfo.bin_nodePairs);  
    A_vidCons_x_ems_ij = speye(numCtrs);
    A_vidCons(:, offset_x_ems_p+1 : offset_x_ems_p+length_x_ems_p) = A_vidCons_x_ems_p;
    A_vidCons(:, offset_x_ems_ij+1 :offset_x_ems_ij+length_x_ems_ij) = -A_vidCons_x_ems_ij;
    lhs_vidCons = sparse(numCtrs,1);
    rhs_vidCons = sparse(numCtrs,1);
    clear A_vidCons_x_ems_p A_vidCons_x_ems_ij
    
    %Video Traffic Flow Conservation - content u
    %sum[ p in P_ij] x_eus_p = x_eus_ij , for each (e in E, s in S, u,i in N, j in N) 
    numCtrs = E*(1)*S*N*N;  
    A_vidCons_u = sparse(numCtrs,numVars);
    A_vidCons_u_x_eus_p = kron(speye(E*(1)*S), topologydata.pathInfo.bin_nodePairs);  
    A_vidCons_u_x_eus_ij = speye(numCtrs);
    A_vidCons_u(:, offset_x_eus_p+1 : offset_x_eus_p+length_x_eus_p) = A_vidCons_u_x_eus_p;
    A_vidCons_u(:, offset_x_eus_ij+1 :offset_x_eus_ij+length_x_eus_ij) = -A_vidCons_u_x_eus_ij;
    lhs_vidCons_u = sparse(numCtrs,1);
    rhs_vidCons_u = sparse(numCtrs,1);
    clear A_vidCons_u_x_eus_p A_vidCons_u_x_eus_ij
    
    %Background Traffic Flow Conservation 
    %sum[p in P_PoPi] y_p >= sum[ems in EMS](1-h*im)s_m(v_ems/wd_ems) f_iems, for each (i in N)
    numCtrs = N;  
    A_backgCons = sparse(numCtrs,numVars); 
    A_backgCons_f_emsi = kron(min_backgTraff_ems,speye(N));
    A_backgCons_y_p = kron(ones(N,1),bin_pathsFromPoP).*topologydata.pathInfo.bin_endNodes;
    A_backgCons(:,offset_f_emsi+1:offset_f_emsi+length_f_emsi) = A_backgCons_f_emsi;
    A_backgCons(:,offset_y_p+1:offset_y_p+length_y_p) = - A_backgCons_y_p;
    lhs_backgCons = -Inf(numCtrs,1);
    rhs_backgCons = sparse(N,1);
    %----to force BBUs to have minimum bw from PoP at least
    rhs_backgCons= -infrastructuredata.WDMcap/1e4*ViRCA_sol.z_j;
    %----to force fix end nodes to have minimum bw from PoP at least
    rhs_backgCons(N-E+1:N-E+E_F) = rhs_backgCons(N-E+1:N-E+E_F) -infrastructuredata.WDMcap/1e4;
    %-------
    clear A_backgCons_y_p A_backgCons_f_emsi
    
    %LTE Capacity (BBU placement) 
    %sum[i in N, s in S m in M+u, p in P_ij] x_ems_p = C_LTE_e z_ej, for each (e in Em,j in N)
    numCtrs = E_M*N;  
    A_LTEcap = sparse(numCtrs,numVars);
    A_LTEcap_x_ems_p = [sparse(numCtrs,E_F*(M)*S*P), kron(kron(speye(E_M,E_M),ones(1,(M)*S)),topologydata.pathInfo.bin_endNodes)]; 
    A_LTEcap_x_eus_p = [sparse(numCtrs,E_F*(1)*S*P), kron(kron(speye(E_M,E_M),ones(1,(1)*S)),topologydata.pathInfo.bin_endNodes)]; 
    A_LTEcap(:,offset_x_ems_p+1:offset_x_ems_p+length_x_ems_p)=A_LTEcap_x_ems_p;
    A_LTEcap(:,offset_x_eus_p+1:offset_x_eus_p+length_x_eus_p)=A_LTEcap_x_eus_p;
    lhs_LTEcap = sparse(numCtrs,1);
    rhs_LTEcap = infrastructuredata.LTEcap*ViRCA_sol.z_ej; %col sol
    clear A_LTEcap_x_ems_p A_LTEcap_x_eus_p;
    
    %WDM Capacity 
    %sum[p in P_l] sum [e in E, s in S, m in M+u] x_ems_p + y_p = C_WDM, for each (l in L_WDM)
    numCtrs = L;  
    A_WDMcap = sparse(numCtrs,numVars);
    A_WDMcap_x_ems_p = kron(ones(1,E*(M)*S),topologydata.pathInfo.bin_edgesInPath); 
    A_WDMcap_x_eus_p = kron(ones(1,E*(1)*S),topologydata.pathInfo.bin_edgesInPath); 
    A_WDMcap_y_p = topologydata.pathInfo.bin_edgesInPath;
    A_WDMcap(:,offset_x_ems_p+1:offset_x_ems_p+length_x_ems_p) = A_WDMcap_x_ems_p;
    A_WDMcap(:,offset_x_eus_p+1:offset_x_eus_p+length_x_eus_p) = A_WDMcap_x_eus_p;
    A_WDMcap(:,offset_y_p+1:offset_y_p+length_y_p) = A_WDMcap_y_p;
    clear A_WDMcap_x_ems_p A_WDMcap_x_eus_p A_WDMcap_y_p;
    lhs_WDMcap = sparse(numCtrs,1);
    rhs_WDMcap = infrastructuredata.WDMcap*topologydata.WDM_linkTable(:,3); %col 3: # virtual links in the bundle
%     rhs_WDMcap = infrastructuredata.WDMcap*ones(numCtrs,1);
    
    %IP Router Capacity 
    %sum[p in P_n] sum [e in E, s in S, m in M+u] x_ems_p + sum [t in N] y_p <= C_IPR*g_ipr_i, for each (n in N)
    numCtrs = N;  
    A_IPRcap = sparse(numCtrs, numVars);
    A_IPRcap_x_ems_p = kron(ones(1,E*(M)*S),topologydata.pathInfo.bin_nodesInPath); 
    A_IPRcap_x_eus_p = kron(ones(1,E*(1)*S),topologydata.pathInfo.bin_nodesInPath); 
    A_IPRcap_y_p = topologydata.pathInfo.bin_nodesInPath;
    A_IPRcap(:,offset_x_ems_p+1:offset_x_ems_p+length_x_ems_p) = A_IPRcap_x_ems_p; 
    A_IPRcap(:,offset_x_eus_p+1:offset_x_eus_p+length_x_eus_p) = A_IPRcap_x_eus_p; 
    A_IPRcap(:,offset_y_p+1:offset_y_p+length_y_p) = A_IPRcap_y_p; 
    lhs_IPRcap = sparse(numCtrs,1);
    rhs_IPRcap = infrastructuredata.IPRcap*ViRCA_sol.g_ipr_i;
    clear A_IPRcap_x_ems_p A_IPRcap_x_eus_p A_IPRcap_y_p;
    
%   %Ethernet Gigaswitch Capacity 
    %sum[p in P_out_n+P_in_n] sum [e in E, s in S, m in M+u] x_ems_p + y_p <= C_EGS*g_egs_i, for each (n in N)
    numCtrs = N;  
    A_EGScap = sparse(numCtrs, numVars);
    ethernetNodePathTable = or(topologydata.pathInfo.bin_initNodes,kron(not(bin_fixNodes_Ids),ones(1,P)).*topologydata.pathInfo.bin_endNodes);
    A_EGScap_x_ems_p = kron(ones(1,E*(M)*S),ethernetNodePathTable); 
    A_EGScap_x_eus_p = kron(ones(1,E*(1)*S),ethernetNodePathTable); 
    A_EGScap_y_p = ethernetNodePathTable;
    A_EGScap(:,offset_x_ems_p+1:offset_x_ems_p+length_x_ems_p) = A_EGScap_x_ems_p; 
    A_EGScap(:,offset_x_eus_p+1:offset_x_eus_p+length_x_eus_p) = A_EGScap_x_eus_p; 
    A_EGScap(:,offset_y_p+1:offset_y_p+length_y_p) = A_EGScap_y_p; 
    lhs_EGScap = sparse(numCtrs,1);
    rhs_EGScap = infrastructuredata.EGScap*ViRCA_sol.g_egs_i;
    clear A_EGScap_x_ems_p A_EGScap_x_eus_p A_EGScap_y_p;
    
    %VMs performing video transcoding
    %sum[e in E, s in S] (sum[m in M]d_tc_ms*v_ems*f_emsi + d_us*vf_eusi) <= t_vtc_i, for each (i in N)
    numCtrs = N;  
    A_VTCvms = sparse(numCtrs, numVars);
    A_VTCvms_f_emsi = kron(v_ems'.*kron(ones(1,E),d_tc_ms') , speye(N,N));
    A_VTCvms_vf_eusi = kron(kron(ones(1,E),d_tc_us') , speye(N,N));
    A_VTCvms(:,offset_f_emsi+1:offset_f_emsi+length_f_emsi) = A_VTCvms_f_emsi;
    A_VTCvms(:,offset_vf_eusi+1:offset_vf_eusi+length_vf_eusi) = A_VTCvms_vf_eusi;
    clear A_VTCvms_f_emsi A_VTCvms_vf_eusi;
    lhs_VTCvms = sparse(numCtrs,1);
    rhs_VTCvms = ViRCA_sol.t_vtc_i;
    

    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %CPLEX call
    fprintf ('\n Calling CPLEX - QoE_RCA_LP ... \n');
    cplex = Cplex('QoE_RCA_LP');
    cplex.Model.sense = 'maximize';
    cplex.Model.obj = [cost_f_emsi; cost_vf_eusi; cost_x_ems_p; cost_x_ems_ij; cost_x_eus_p; cost_x_eus_ij; cost_y_p; cost_h_mi];
    cplex.Model.lb = [lb_f_emsi; lb_vf_eusi; lb_x_ems_p; lb_x_ems_ij; lb_x_eus_p; lb_x_eus_ij; lb_y_p; lb_h_mi];
    cplex.Model.ub = [ub_f_emsi; ub_vf_eusi; ub_x_ems_p; ub_x_ems_ij; ub_x_eus_p; ub_x_eus_ij; ub_y_p; ub_h_mi];
    
    cplex.Model.A = [A_shareVidSrc;
                     A_hitRatio;
                     A_storCap;
                     A_minQoE;
                     A_maxQoE;
                     A_minQoE_u;
                     A_maxQoE_u;
                     A_vidCons;
                     A_vidCons_u;
                     A_backgCons;
                     A_LTEcap;
                     A_WDMcap;
                     A_IPRcap;
                     A_EGScap;
                     A_VTCvms;
                     ];
    cplex.Model.lhs = [ lhs_shareVidSrc;%0
                        lhs_hitRatio;%-Inf
                        lhs_storCap; % 0
                        lhs_minQoE; % 0
                        lhs_maxQoE; % -Inf
                        lhs_minQoE_u; % 0
                        lhs_maxQoE_u; % -Inf
                        lhs_vidCons; %0
                        lhs_vidCons_u; %0
                        lhs_backgCons; %backgroundTraff traff
                        lhs_LTEcap;  % -Inf
                        lhs_WDMcap;  % 0
                        lhs_IPRcap;  % 0
                        lhs_EGScap;  % 0
                        lhs_VTCvms; %0
                        ];
    cplex.Model.rhs = [ rhs_shareVidSrc; %1
                        rhs_hitRatio;%0
                        rhs_storCap; % storage cap
                        rhs_minQoE; % Inf
                        rhs_maxQoE; % 0
                        rhs_minQoE_u; % Inf
                        rhs_maxQoE_u; % 0
                        rhs_vidCons;  % = 0
                        rhs_vidCons_u;  % = 0
                        rhs_backgCons; % backgroundTraff traff
                        rhs_LTEcap; %0
                        rhs_WDMcap % C_WDM
                        rhs_IPRcap % C_IPR
                        rhs_EGScap % C_EGS
                        rhs_VTCvms; %t_vtc_i
                        ]; 
     offset_shareVidSrc = 0;                    
     numCtrs_shareVidSrc = E*M*S;
     offset_hitRatio = offset_shareVidSrc + numCtrs_shareVidSrc;  
     numCtrs_hitRatio = E*M*S*N;
     offset_storCap = offset_hitRatio + numCtrs_hitRatio;
     numCtrs_storCap = N;  
     offset_minQoE = offset_storCap + numCtrs_storCap;
     numCtrs_minQoE = E*M*S*N;
     offset_maxQoE = offset_minQoE + numCtrs_minQoE;
     numCtrs_maxQoE = E*M*S*N; 
     offset_minQoE_u = offset_maxQoE + numCtrs_maxQoE;
     numCtrs_minQoE_u = E*S*N;
     offset_maxQoE_u = offset_minQoE_u + numCtrs_minQoE_u;
     numCtrs_maxQoE_u = E*S*N; 
     offset_vidCons = offset_maxQoE_u + numCtrs_maxQoE_u;
     numCtrs_vidCons = E*(M)*S*N*N; 
     offset_vidCons_u = offset_vidCons + numCtrs_vidCons;
     numCtrs_vidCons_u = E*(1)*S*N*N; 
     offset_backgCons = offset_vidCons_u + numCtrs_vidCons_u;
     numCtrs_backgCons = N; 
     offset_LTEcap = offset_backgCons + numCtrs_backgCons;
     numCtrs_LTEcap = E_M*N; 
     offset_WDMcap = offset_LTEcap + numCtrs_LTEcap;
     numCtrs_WDMcap = L; 
     offset_IPRcap = offset_WDMcap + numCtrs_WDMcap;
     numCtrs_IPRcap = N; 
     offset_EGScap = offset_IPRcap + numCtrs_IPRcap;
     numCtrs_EGScap = N; 
     offset_VTCvms = offset_EGScap + numCtrs_EGScap;
     numCtrs_VTCvms = N; 
%     size(cplex.Model.obj)    
%     size(cplex.Model.lb)
%     size(cplex.Model.ub)
%     size(cplex.Model.ctype)
%     
%     size(cplex.Model.A)
%     size(cplex.Model.lhs)
%     size(cplex.Model.rhs)
    if not(isempty(start_RCA_sol)),
        %cplex.Start.x = start_RCA_sol.x;
        %cplex.Start.ax = start_RCA_sol.ax;
        %cplex.Start.dual = start_RCA_sol.dual;
        %cplex.Start.reducedcost = start_RCA_sol.reducedcost;
        %cplex.Start.basis = start_RCA_sol.basis;
        %cplex.Param.advance.Cur = 1;
        %fprintf('\n Reoptimizing from previous basis. \n')
    end
    cplex.solve();

    fprintf ('\nSolution status = %s \n', cplex.Solution.statusstring);
%     cplex.Solution
%      pause
    sol_0.status = cplex.Solution.statusstring;
    sol_0.statusnum = cplex.Solution.status;
    if ~ismember(sol_0.statusnum,[1]), sol=sol_0; slack=0; return; end;
    fprintf ('Solution value = %f \n', cplex.Solution.objval);
    sol_0.obj =  cplex.Solution.objval;
    sol_0.x = cplex.Solution.x;
    sol_0.ax= cplex.Solution.ax;
    sol_0.dual = cplex.Solution.dual;
    sol_0.reducedcost = cplex.Solution.reducedcost;
    sol_0.basis = cplex.Solution.basis;
%     sol_0.vf_eusi = sparse(cplex.Solution.x(offset_vf_eusi+ 1 : offset_vf_eusi+ length_vf_eusi));
    sol_0.f_emsi = sparse(cplex.Solution.x(offset_f_emsi+ 1 : offset_f_emsi+ length_f_emsi));
    sol_0.x_ems_p = sparse(cplex.Solution.x(offset_x_ems_p+ 1 : offset_x_ems_p+ length_x_ems_p));
    sol_0.x_ems_ij = sparse(cplex.Solution.x(offset_x_ems_ij+ 1 : offset_x_ems_ij+ length_x_ems_ij));
%     sol_0.x_eus_p = sparse(cplex.Solution.x(offset_x_eus_p+ 1 : offset_x_eus_p+ length_x_eus_p));
%     sol_0.x_eus_ij = sparse(cplex.Solution.x(offset_x_eus_ij+ 1 : offset_x_eus_ij+ length_x_eus_ij));
    sol_0.y_p = sparse(cplex.Solution.x(offset_y_p+ 1 : offset_y_p+ length_y_p));
    sol_0.h_mi = sparse(cplex.Solution.x(offset_h_mi+ 1 : offset_h_mi+ length_h_mi));
    
    %%%%%%%%% QoE_RCA_u_LP: Assigning remaining resources to content 'u'
    % We fix previous solutions f_emsi, x_ems_p, x_ems_ij, y_p, h_mi
    lb_f_emsi = sol_0.f_emsi;     ub_f_emsi = sol_0.f_emsi;
    lb_x_ems_p = sol_0.x_ems_p;   ub_x_ems_p = sol_0.x_ems_p;
    lb_x_ems_ij = sol_0.x_ems_ij; ub_x_ems_ij = sol_0.x_ems_ij;
    lb_y_p = sol_0.y_p;           ub_y_p = sol_0.y_p;
    lb_h_mi =sol_0.h_mi;          ub_h_mi =sol_0.h_mi;
    % We maximize QoE of u
     cost_x_eus_ij = kron(QoE_eus, ones(N*N,1));
     % We update the cplex model
     %CPLEX call
    fprintf ('\n Calling CPLEX QoE_RCA_u_LP... \n');
    cplex.Model.obj = [cost_f_emsi; cost_vf_eusi; cost_x_ems_p; cost_x_ems_ij; cost_x_eus_p; cost_x_eus_ij; cost_y_p; cost_h_mi];
    cplex.Model.lb = [lb_f_emsi; lb_vf_eusi; lb_x_ems_p; lb_x_ems_ij; lb_x_eus_p; lb_x_eus_ij; lb_y_p; lb_h_mi];
    cplex.Model.ub = [ub_f_emsi; ub_vf_eusi; ub_x_ems_p; ub_x_ems_ij; ub_x_eus_p; ub_x_eus_ij; ub_y_p; ub_h_mi];
    cplex.Start.x = sol_0.x;
    cplex.Start.ax = sol_0.ax;
    cplex.Start.dual = sol_0.dual;
    cplex.Start.reducedcost = sol_0.reducedcost;
    cplex.Start.basis = sol_0.basis;
    cplex.Param.advance.Cur = 1;
    cplex.solve();
    
    fprintf ('\nSolution status = %s \n', cplex.Solution.statusstring);
    fprintf ('Solution value = %f \n', cplex.Solution.objval);
%     cplex.Solution
%      pause
    sol.status = cplex.Solution.statusstring;
    sol.statusnum = cplex.Solution.status;
    sol.obj =  cplex.Solution.objval;
    sol.x = cplex.Solution.x;
    sol.ax= cplex.Solution.ax;
    sol.dual = cplex.Solution.dual;
    sol.reducedcost = cplex.Solution.reducedcost;
    sol.basis = cplex.Solution.basis;
    sol.vf_eusi = sparse(cplex.Solution.x(offset_vf_eusi+ 1 : offset_vf_eusi+ length_vf_eusi));
    sol.f_emsi = sparse(cplex.Solution.x(offset_f_emsi+ 1 : offset_f_emsi+ length_f_emsi));
    sol.x_ems_p = sparse(cplex.Solution.x(offset_x_ems_p+ 1 : offset_x_ems_p+ length_x_ems_p));
    sol.x_ems_ij = sparse(cplex.Solution.x(offset_x_ems_ij+ 1 : offset_x_ems_ij+ length_x_ems_ij));
    sol.x_eus_p = sparse(cplex.Solution.x(offset_x_eus_p+ 1 : offset_x_eus_p+ length_x_eus_p));
    sol.x_eus_ij = sparse(cplex.Solution.x(offset_x_eus_ij+ 1 : offset_x_eus_ij+ length_x_eus_ij));
    sol.y_p = sparse(cplex.Solution.x(offset_y_p+ 1 : offset_y_p+ length_y_p));
    sol.h_mi = sparse(cplex.Solution.x(offset_h_mi+ 1 : offset_h_mi+ length_h_mi));
    
    
    %computing slackness used to trigger reoptim
    %1) min QoE
    slack.minQoE = sol.ax(offset_minQoE+1 : offset_minQoE+numCtrs_minQoE); %>0 by default
    %2) min QoE_u
    slack.minQoE_u = sol.ax(offset_minQoE_u+1 : offset_minQoE_u+numCtrs_minQoE_u); %<0 by default
    %3) max QoE
    slack.maxQoE = sol.ax(offset_maxQoE+1 : offset_maxQoE+numCtrs_maxQoE); %>0 by default
    %4) max QoE_u
    slack.maxQoE_u = sol.ax(offset_maxQoE_u+1 : offset_maxQoE_u+numCtrs_maxQoE_u); %<0 by default
    %5) VTCvms
    slack.VTCvms = ViRCA_sol.t_vtc_i - sol.ax(offset_VTCvms+1 : offset_VTCvms+numCtrs_VTCvms); %>0
    
%         ViRCA_sol.t_vtc_i
%     sol.ax(offset_VTCvms+1 : offset_VTCvms+numCtrs_VTCvms)
%     pause
%      fprintf ('Checking slackness in QoE ems ctrs (min max)  \n');
%     [A_minQoE_x_ems_ij*sol.x_ems_ij-A_minQoE_f_emsi*sol.f_emsi A_maxQoE_x_ems_ij*sol.x_ems_ij-A_maxQoE_f_emsi*sol.f_emsi]
%     
%       postproccesing(sol, topologydata, videodata,infrastructuredata)
    [QoE]=compute_QoE(cost_x_ems_ij,cost_x_eus_ij,sol);
    sol.QoE=QoE;
    
end
function postproccesing(sol, topologydata, videodata,infrastructuredata)    

  % Dimensions
    E_M = topologydata.nbof_mobendnodes; % numMobileEndNodes;
    E_F = topologydata.nbof_fixedendnodes; % numFixEndNodes;
    E = E_M+E_F;  % numEndNodes;
    N = size(topologydata.pathInfo.bin_nodesInPath,1);
    L = size(topologydata.pathInfo.bin_edgesInPath,1);
    M = size(videodata.mat_content,2);%     numContents (that is not the number of content types);
    S = size(videodata.alpha,2);%     numResols;
    P = topologydata.pathInfo.P;
        
    %Indeces
    bin_PoP_Id = (topologydata.nodeTable(:,3)==0);
    if sum(bin_PoP_Id)>1, error('More than one PoP'); end
    bin_NOT_mobNodes_Ids = (topologydata.nodeTable(:,3)~=4);
    bin_fixNodes_Ids = (topologydata.nodeTable(:,3)==3);
    bin_mobNodes_Ids = (topologydata.nodeTable(:,3)==4);
    fixNodes_Ids = find(topologydata.nodeTable(:,3)==3);
    mobNodes_Ids = find(topologydata.nodeTable(:,3)==4);
    
    %contents catalog
%     v_ems = [kron(ones(E_F,1), mat2vct(videoInfo.videosPerFixPoint_byContDev));...
%              kron(ones(E_M,1), mat2vct(videoInfo.videosPerCellSite_byContDev))];
    v_ems = videodata.vems';% to col
    % We transform all the content-type-dependnt info into individual content-dependant info
    b_min_ms = videodata.bmin(videodata.mat_content(2,:),:); 
    b_max_ms = videodata.bmax(videodata.mat_content(2,:),:);
    b_min_ems = kron(ones(E,1), mat2vct(b_min_ms));
    b_max_ems = kron(ones(E,1), mat2vct(b_max_ms));
    QoE_ms = videodata.alpha(videodata.mat_content(2,:),:);
    QoE_ems = kron(ones(E,1), mat2vct(QoE_ms));
    for flag4K = 0:size(videodata.d_tc,1)-1,
        switch flag4K 
            case 0 %not flag4K
                d_tc_ms_not4k = squeeze(videodata.d_tc(flag4K+1,:,videodata.mat_content(2,:)))';
                d_tc_ms_not4k((videodata.mat_content(5,:)==1)',:)=0; %removing 4k
            case 1 %flag4K
                d_tc_ms_4k = squeeze(videodata.d_tc(flag4K+1,:,videodata.mat_content(2,:)))';
                d_tc_ms_4k(not(videodata.mat_content(5,:))',:)=0; %removing not 4k
        end
    end
    d_tc_ms =mat2vct(d_tc_ms_4k + d_tc_ms_not4k);

    %unknown content
    b_min_s_unknown = mean(b_min_ms)'; %col vector
    b_max_s_unknown = mean(b_max_ms)'; %col vector
    QoE_unknown = mean(QoE_ms)'; %col vector
    b_min_es = kron(ones(E,1), b_min_s_unknown);
    b_max_es = kron(ones(E,1), b_max_s_unknown);
    QoE_eus = kron(ones(E,1), QoE_unknown);
    d_tc_us = mean(d_tc_ms_4k)'+mean(d_tc_ms_not4k)';
    
    videoTraffMatrix = zeros(N,N,E*M*S); 
    aggVideoTraffMatrix = zeros(N,N,E); 
    f_emsi_matrix = zeros(N,E*M*S);
    for ems = 1:E*M*S,
        e = ceil(ems/(M*S));
        f_emsi_matrix (:,ems) = ((reshape(sol.f_emsi((ems-1)*N+1 : ems*N),[N,1]))');
        videoTraffMatrix (:,:,ems) = ((reshape(sol.x_ems_ij((ems-1)*N^2+1 : ems*N^2),[N,N]))');
        aggVideoTraffMatrix(:,:,e) = aggVideoTraffMatrix(:,:,e) +  videoTraffMatrix (:,:,ems);
    end
%     sum(sol.f_emsi)
%     sum(sum(f_emsi_matrix))
%     pause
    vf_eusi_matrix = vct2mat(sol.vf_eusi, E*1*S, N);
    unkVidTraffMatrix = zeros(N,N,E*1*S); 
    aggUnkVidTraffMatrix = zeros(N,N,E); 
    for es = 1:E*S,
        e = ceil(es/(1*S));
        unkVidTraffMatrix (:,:,es) = ((reshape(sol.x_eus_ij((es-1)*N^2+1 : es*N^2),[N,N]))');
        aggUnkVidTraffMatrix(:,:,e) = aggUnkVidTraffMatrix(:,:,e) +  unkVidTraffMatrix (:,:,es);
    end
    
%     vf_eusi_matrix = zeros(N,E*1*S);
%     for es = 1:E*1*S,
%         vf_eusi_matrix (:,es) = ((reshape(vf_eusi((es-1)*N+1 : es*N),[N,1]))');
%         es
%         vf_eusi_matrix(:,es)
%         pause
%     end
%     sum(vf_eusi)
%     sum(sum(vf_eusi_matrix))
%     pause
    for e = 1:E,
        e 
        disp('aggVideoTraffMatrix')
        ag=aggVideoTraffMatrix(:,:,e)
%         disp('aggUnkVidTraffMatrix')
%         aggUnkVidTraffMatrix(:,:,e)
%         pause
    end
    
    disp('Total aggVideoTraffMatrix=')
    carriedVidTraffic = sum(sum(sum(aggVideoTraffMatrix)))
    disp('Total Offered aggVideoTraffMatrix=')
    maxOfferedVidTrafic = v_ems'*b_max_ems
    pause
    v_ems
%     b_max_ems
    sum_bmax = sum(b_max_ems)
%     max_bmax = max(b_max_ems)
    numVideos = sum(v_ems)
    max_numVideos_paralel = max(v_ems)
%     pause
    disp('acceptedTraffic_wrtMax = ')
    acceptedTraffic_wrtMax = carriedVidTraffic/maxOfferedVidTrafic
    
    disp('Total aggUnkVidTraffMatrix=')
    sum(sum(sum(aggUnkVidTraffMatrix)))
%     disp('Total Offered aggUnkVidTraffMatrix=')
%     v_es'*b_max_es
%     pause
  
    backgroundTraff_t = topologydata.pathInfo.bin_endNodes*sol.y_p
    backgroundTraff_s = topologydata.pathInfo.bin_initNodes*sol.y_p
    pause
    
    z_ej_mat = vct2mat(sol.z_ej, E_M, N)
    pause
    
    h_mi_mat = vct2mat(sol.h_mi, M, N)
    
    sol.g_ipr_i
    sol.g_egs_i
    sol.g_srv_i
    sol.t_bbu_i 
    sol.t_vtc_i
end
function vector_col = mat2vct(matrix)
    vector_col = reshape(matrix', [numel(matrix) 1]);
end
function matrix = vct2mat(vector, numRows, numCols)
    matrix = (reshape(vector,[numCols numRows]))';
end
function [QoE]=compute_QoE(cost_x_ems_ij,cost_x_eus_ij,sol)

QoE=sum(cost_x_ems_ij.*sol.x_ems_ij)+sum(cost_x_eus_ij.*sol.x_eus_ij);
end

function [reoptimFlag] = reoptimTrigger (prevSlack, N,E, measures_delta, b_min_ems, b_max_ems, d_tc_ms, b_min_es, b_max_es, d_tc_us)
reoptimFlag = 0;
precision = 1e-9;
%minQoE
if sum((prevSlack.minQoE-kron(b_min_ems,ones(N,1)).*measures_delta.vf_emsi)<-precision), 
    disp('1')
    reoptimFlag = 1;
end
%maxQoE
if sum((prevSlack.maxQoE-kron(b_max_ems,ones(N,1)).*measures_delta.vf_emsi)>precision), 
    disp('2')
    reoptimFlag = 1;
end
%minQoE_u
if sum((prevSlack.minQoE_u-kron(b_min_es,ones(N,1)).*measures_delta.vf_eusi)<-precision), 
    disp('3')
    reoptimFlag = 1;
end
%maxQoE_u
if sum((prevSlack.maxQoE_u-kron(b_max_es,ones(N,1)).*measures_delta.vf_eusi)>precision), 
    disp('4')
    reoptimFlag = 1;
end
%VTCvms
if sum((prevSlack.VTCvms-kron(kron(ones(1,E),d_tc_ms'),speye(N,N))*measures_delta.vf_emsi-kron(kron(ones(1,E),d_tc_us'),speye(N,N))*measures_delta.vf_eusi)<-precision), 
    disp('5')
%     sum(prevSlack.VTCvms)
%     sum(kron(kron(ones(1,E),d_tc_ms'),speye(N,N))*measures_delta.vf_emsi-kron(kron(ones(1,E),d_tc_us'),speye(N,N))*measures_delta.vf_eusi)
    reoptimFlag = 1;
end

end
