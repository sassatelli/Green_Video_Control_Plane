function srv_submission_gamma(topology_name,model,traffload,gamma_factor)

initialize();

scenario_ind=1;

%-- Generate and Compress catalog only Once
nbof_catalog=1; totalrequests=1e5; nbof_contentpercatalog=1e4;
filename=['../simpoints/topo_traffic_scen1_',topology_name,'_L',num2str(traffload),'_MC',num2str(nbof_contentpercatalog),'_C',num2str(nbof_catalog),'_TR',num2str(totalrequests),'.mat'];
if exist(filename,'file')==0,
    Generate_scen_forcurves(scenario_ind,topology_name,traffload);
    load(filename,'topologydata','videodata','infrastructuredata','backgroundTraff');
    max_ems_p=1e6;
    flag_compresscatalog=1;
    if flag_compresscatalog==1,
        nbof_content=size(videodata.mat_content,2); nbof_resol=size(videodata.alpha,2); nbof_endnodes=topologydata.nbof_fixedendnodes+topologydata.nbof_mobendnodes; nbof_IPpaths=topologydata.pathInfo.P;
        max_catalog=max_ems_p/(nbof_endnodes*nbof_resol*nbof_IPpaths);
        size(videodata.mat_content,2)
        max_catalog=max(min(floor(max_catalog),nbof_content),10)
        [videodata]=cluster_catalog(topologydata,videodata,infrastructuredata,max_catalog);
    end;
    size(videodata.mat_content,2)
    save(filename,'topologydata','videodata','infrastructuredata','backgroundTraff');
end;
%----------

load(filename,'topologydata','videodata','infrastructuredata','backgroundTraff');

%--Parameters
[gamma_central,maxpower,maxQoE]=get_gammacentral(filename,model);
gamma.factor=gamma_factor;
gamma.maxpower=maxpower;
gamma.maxQoE=maxQoE;
gamma.value=gamma.factor*gamma.maxpower/gamma.maxQoE;
beta=0.2;

%-- Local launch
if strcmp(model,'ViRCA'),
    sol=VCRAN_MILP_bkg(topologydata,videodata,infrastructuredata,gamma.value);
elseif strcmp(model,'ViRCA2'),
    sol=VCRAN_MILP_v2_bkg(topologydata,videodata,infrastructuredata,gamma.value);
elseif strcmp(model,'ViRCA3'),
    sol=VCRAN_MILP_v3_bkg(topologydata,videodata,infrastructuredata,gamma.value);
end;
sol_filename=['sols/sol_gamma_',model,'_',topology_name,'_L',num2str(traffload),'_gammafactor',num2str(gamma_factor),'.mat'];
save(sol_filename,'sol');

end
%%%%%%%%%%
function initialize
    addpath( ...
        '../scenarii','../simpoints','../simulator','../srv_submissions',...
         genpath('/usr/local/MATLAB/R2011a/toolbox/stats/'));
%         '/opt/ibm/ILOG/CPLEX_Studio1262/cplex/matlab/','/opt/ibm/ILOG/CPLEX_Studio1262/cplex/matlab/x86-64_linux');
end

function [gamma_central,maxpower,maxQoE]=get_gammacentral(topo_traffic_filename,model)
    load(topo_traffic_filename,'topologydata','videodata','infrastructuredata','backgroundTraff');
    maxpower_pernode=infrastructuredata.IPRpower+infrastructuredata.EGSpower+infrastructuredata.SRVpower+infrastructuredata.VMpower*sum(infrastructuredata.G_n*infrastructuredata.K);
    nbof_nodes=size(topologydata.nodeTable,1);
    maxpower=maxpower_pernode*nbof_nodes;
    E_M = topologydata.nbof_mobendnodes; % numMobileEndNodes;
    E_F = topologydata.nbof_fixedendnodes; % numFixEndNodes;
    E = E_M+E_F;  % numEndNodes;
    vems = videodata.vems';% to col
    % We transform all the content-type-dependnt info into individual content-dependant info
    nbof_resol=4;
    vem=sum(reshape(videodata.vems,nbof_resol,length(videodata.vems)/nbof_resol),1);
    vm=sum(reshape(vem,length(vem)/E,E),2);
    maxQoE=sum(videodata.vems.*min(sum(infrastructuredata.nodeStorage)/sum(videodata.mat_content(4,logical(vm>0))),1)); % sum(vems)
    if strcmp(model,'ViRCA3'),
        nbof_mobendnodes=E_M;
        maxQoE=sum(videodata.vems.*min(sum(infrastructuredata.nodeStorage([1 nbof_nodes-E+1:nbof_nodes]))/sum(videodata.mat_content(4,logical(vm>0))),1)); % sum(vems)
    end;
    gamma_central=maxpower/maxQoE;
end
