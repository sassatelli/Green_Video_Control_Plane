function plot_scen1(topology_name,load_vec,model,gamma_factor)

len=length(load_vec);
power_vec=zeros(1,len);
QoE_vec=zeros(1,len);
optgap_vec=zeros(1,len);
cachedm=zeros(1,len);


%--- Figure 3 (Types of activated nodes vs load)

frof_routers_perloc=zeros(3,len); % % 1 for Pop and L1, 2 for L2 and L3, 3 for end nodes
frof_caches_perloc=zeros(3,len);
frof_BBUs_perloc=zeros(3,len);
if strcmp(topology_name,'FMC_tree'),
    ind_PoPaggrNodesL1=1:3; ind_aggrNodesL2=4:7; ind_endnodes=8:22; ind_aggrNodesL3=[];
elseif strcmp(topology_name,'FMC_ringandspur'),
    ind_PoPaggrNodesL1=1:5; ind_endnodes=6:20; ind_aggrNodesL2=[]; ind_aggrNodesL3=[];
elseif strcmp(topology_name,'Mobile_backhaul'), % 2 1
    ind_PoPaggrNodesL1=[1:4,12:14]; ind_aggrNodesL2=[5:7,15:17]; ind_aggrNodesL3=[8:11,18:21]; ind_endnodes=22:31; 
end;
for i=1:len,
    sol_filename=['sols/sol_gamma_',model,'_',topology_name,'_L',num2str(load_vec(i)),'_gammafactor',num2str(gamma_factor),'.mat'];
    %load(sol_filename,'ViRCA_sol');
    %%%%
    load(sol_filename);
%     ViRCA_sol=cell_sol{1,i};
    %%%%
    g_ipr_i=find(sol.g_ipr_i>0);
    frof_routers_perloc(1,i)=sum(ismember(g_ipr_i,ind_PoPaggrNodesL1))/length(ind_PoPaggrNodesL1);
    frof_routers_perloc(2,i)=sum(ismember(g_ipr_i,[ind_aggrNodesL2,ind_aggrNodesL3]))/length([ind_aggrNodesL2,ind_aggrNodesL3]);
    frof_routers_perloc(3,i)=sum(ismember(g_ipr_i,ind_endnodes))/length(ind_endnodes);
    g_cache_i=find(sol.t_vtc_i>0);
    frof_caches_perloc(1,i)=sum(ismember(g_cache_i,ind_PoPaggrNodesL1))/length(ind_PoPaggrNodesL1);
    frof_caches_perloc(2,i)=sum(ismember(g_cache_i,[ind_aggrNodesL2,ind_aggrNodesL3]))/length([ind_aggrNodesL2,ind_aggrNodesL3]);
    frof_caches_perloc(3,i)=sum(ismember(g_cache_i,ind_endnodes))/length(ind_endnodes);
    g_bbu_i=find(sol.t_bbu_i>0);
    frof_BBUs_perloc(1,i)=sum(ismember(g_bbu_i,ind_PoPaggrNodesL1))/length(ind_PoPaggrNodesL1);
    frof_BBUs_perloc(2,i)=sum(ismember(g_bbu_i,[ind_aggrNodesL2,ind_aggrNodesL3]))/length([ind_aggrNodesL2,ind_aggrNodesL3]);
    frof_BBUs_perloc(3,i)=sum(ismember(g_bbu_i,ind_endnodes))/length(ind_endnodes);
end;
frof_routers_perloc=kron(frof_routers_perloc,[1 0 0]);
frof_caches_perloc=kron(frof_caches_perloc,[0 1 0]);
frof_BBUs_perloc=kron(frof_BBUs_perloc,[0 0 1]);
y=frof_routers_perloc+frof_caches_perloc+frof_BBUs_perloc;
Y=y'; %http://stackoverflow.com/questions/6012568/how-can-i-create-a-barseries-plot-using-both-grouped-and-stacked-styles-in-matla
newY = reshape([reshape(Y,3,[]); zeros(1,numel(Y)/3)],[],3);
figure;
set(gca,'FontSize',18);
h=bar(newY,'stacked');
set(h,{'FaceColor'},{'red';'magenta';'blue'});
% load_labels=num2str(load_vec.');
% set(gca,'XLim',[0 4*len],'XTick',2:4:4*len-2,'XTickLabel',load_labels);
load_labels={'IP routers','caches','BBUs'};
set(gca,'XLim',[0 4*len],'XTick',[1:3 5:7 9:11 13:15],'XTickLabel',load_labels);
set(gca,'XTickLabelRotation',45)
xlabel('load factor','FontSize',24);
ylabel('fraction of nodes','FontSize',24);
loc_label={'PoP and agg. level 1','agg. levels 2 and 3','end nodes'};
legend(loc_label,'location','northeast','FontSize',24);

end

function [gamma_central,maxpower,maxQoE]=get_gammacentral(topo_traffic_filename)
    load(topo_traffic_filename,'topologydata','videodata','infrastructuredata','backgroundTraff');
    maxpower_pernode=infrastructuredata.IPRpower+infrastructuredata.EGSpower+infrastructuredata.SRVpower+infrastructuredata.VMpower*sum(infrastructuredata.G_n*infrastructuredata.K);
    nbof_nodes=size(topologydata.nodeTable,1);
    maxpower=maxpower_pernode*nbof_nodes;
    E_M = topologydata.nbof_mobendnodes; % numMobileEndNodes;
    E_F = topologydata.nbof_fixedendnodes; % numFixEndNodes;
    E = E_M+E_F;  % numEndNodes;
    vems = videodata.vems';% to col
    % We transform all the content-type-dependnt info into individual content-dependant info
    nbof_resol=4;
    vem=sum(reshape(videodata.vems,nbof_resol,length(videodata.vems)/nbof_resol),1);
    vm=sum(reshape(vem,length(vem)/E,E),2);
    maxQoE=sum(videodata.vems.*min(sum(infrastructuredata.nodeStorage)/sum(videodata.mat_content(4,logical(vm>0))),1)); % sum(vems)
    gamma_central=maxpower/maxQoE;
end

function vector_col = mat2vct(matrix)
    vector_col = reshape(matrix', [numel(matrix) 1]);
end
function matrix = vct2mat(vector, numRows, numCols)
    matrix = (reshape(vector,[numCols numRows]))';
end
